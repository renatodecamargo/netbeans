#ifndef _MAILBOX_H_
#define _MAILBOX_H_

#include "ist_functions.h"

#define MAILBOX_HEADER_SIGNATURE 0xFCFCFCFC
#define MAILBOX_SIGNATURE        0xFAFAFAFA
#define MAILBOX_BASE_KEY       0x53412222
#define MSGSZ     		       1024

static FILE *mbox_debug_fp = NULL;

typedef struct {
	int     signature;
	int     shmid;
	int     semid;
	int     pid;
    size_t  buff_qty;
	size_t  buff_len;
    int     lastindex;
	time_t  timestamp;
} shm_mbox_system_header;

typedef struct {
	int    signature;
	int    msqid;
    int    mbid;
    char   mbname[MAX_IST_STRING];
    int    maxmsg;
} shm_mbox_header;

shm_mbox_system_header * get_mbox_shm_stat ( void ) ;
int mbox_shm_create_memory( shm_mbox_system_header **shm, int maxmbox );
int mbox_shm_create_semaphore();
int mbox_shm_format_memory( shm_mbox_system_header *shm );
int mbox_shm_init_semaphore( int semid );
int mbox_shm_show_memory();
shm_mbox_header *get_mbox_index_header( unsigned short index, shm_mbox_system_header *ptr );
size_t get_total_shm_len( void );
size_t get_shm_buff_len( void );
size_t get_shm_buff_qty( void );
int mbox_get_active_pid();
key_t get_shm_mbox_key( void );
int mbox_get_shm_id();
int mbox_get_semaphore_id();
int mbox_remove_shm();
int mbox_remove_semaphore();
int  mbox_remove_queues();

/*
IPC_STAT
               key_t           msg_perm.__key; / * Key supplied to msgget(2) * /
               uid_t           msg_perm.uid;   / * Effective UID of owner * /
               gid_t           msg_perm.gid;   / * Effective GID of owner * /
               uid_t           msg_perm.cuid;  / * Effective UID of creator * /
               gid_t           msg_perm.cgid;  / * Effective GID of creator * /
               unsigned short  msg_perm.mode;  / * Permissions * /
               unsigned short  msg_perm.__seq; / * Sequence number * /               
               time_t          msg_stime;      / * Time of last msgsnd(2) * /
               time_t          msg_rtime;      / * Time of last msgrcv(2) * /
               time_t          msg_ctime;      / * Time of last change  * /
               unsigned long   __msg_cbytes;   / * Current number of bytes in queue (nonstandard) * /
               msgqnum_t       msg_qnum;       / * Current number of messages in queue * /
               msglen_t        msg_qbytes;     / * Maximum number of bytes allowed in queue * /
               pid_t           msg_lspid;      / * PID of last msgsnd(2) * /
               pid_t           msg_lrpid;      / * PID of last msgrcv(2) * /
*/
#endif
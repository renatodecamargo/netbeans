#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/stat.h>
#include <assert.h>
#include <signal.h>
#include <errno.h>
#include <string>

#include "syslg.h"
#include "ist_functions.h"
#include "misc_functions.h"

#define MODULE_NAME  "syslgcmd"

enum {
	START_FUNCTION = 0,
	STOP_FUNCTION,
	SEND_FUNCTION,
	MON_FUNCTION,
	KEY_FUNCTION,
	LOG_FUNCTION,
	ALL_FUNCTION,
	RELEASE_FUNCTION 
};

static shm_syslg_header *shm = NULL;
static int syslgfunction = -1;
char *syslgfunction_param = NULL;

void signal_handler(int signo)
{
	int rc;
	char msg[MAX_IST_STRING] = {0};

	/* Send Message do Debug Info */
	sprintf(msg,"Signal Received [%d]",signo );
	debug_log( syslg_debug_fp, "%s\n", msg );

	/* Remove SHM */
	if ((rc = syslg_remove_shm()) < 0)
		debug_log( syslg_debug_fp, "SHM could not be deleted [%d]. Errno [%d]\n", rc, errno );

	/* Remove SHM */
	if ((rc = syslg_remove_semaphore()) < 0)
		debug_log( syslg_debug_fp, "Semaphore could not be deleted [%d]. Errno [%d]\n", rc, errno );

	/* Remove Queue */
	if ((rc = syslg_remove_queue()) < 0)
		debug_log( syslg_debug_fp, "Message queue could not be deleted [%d]. Errno [%d]\n", rc, errno );

	/* Close files */
	fclose(syslg_fp);
	fclose(syslg_debug_fp);

	/* Exit with signal received */
	exit(signo);
}

int syslg_handler( void )
{
    struct message_buf  rbuf;
	char logname[MAX_IST_STRING] = {0};
	char debugname[MAX_IST_STRING] = {0};
    int msqid, semid, shmid;

	syslg_arg0(MODULE_NAME);		

	/* Get SHM Header */
	shm = get_syslg_shm_stat ();

	if( shm != NULL) {
		fprintf(stderr,"E-%s-012 SYSLG already started with PID [%d]\n", PRODUCT_ALIAS, shm->pid );
		exit(1);
	}

	/* Get Parameters */
	cf_locate(PRODUCT_KEY_MASTERLOG,logname);
	cf_locate(PRODUCT_KEY_MASTERDIRDEBUG,debugname);
	sprintf(debugname,"%s/%s.debug",debugname,MODULE_NAME);

	if((shmid = syslg_shm_create_memory( &shm )) < 0 )
	{
		fprintf(stderr,"E-%s-013 Cannot create SHM. Check user permission\n", PRODUCT_ALIAS );
		exit(1);
	}

	if(( semid = syslg_shm_create_semaphore()) < 0 )
	{
		fprintf(stderr,"E-%s-014 Cannot create semaphore. Check user permission\n", PRODUCT_ALIAS );
		exit(1);
	}

    if ((msqid = syslg_create_queue()) < 0) {
		fprintf(stderr,"E-%s-005 syslg_get_queue_id() error [%d]\n", PRODUCT_ALIAS, msqid );
		debug_log(syslg_debug_fp,"E-%s-005 syslg_get_queue_id() error [%d]\n", PRODUCT_ALIAS, msqid );
		exit(1);
    }	

	shm->semid = semid;
	shm->shmid = shmid;
	shm->msqid = msqid;
	strcpy(shm->logname,logname);
	syslg_shm_format_memory(shm);

	if( syslg_shm_init_semaphore( semid ) < 0 ) {
		fprintf(stderr,"E-%s-015 Cannot initialize semaphore. Check user permission\n", PRODUCT_ALIAS );
		exit(1);
	}

	/* Open SYSLG */
	if(( syslg_fp = fopen(logname,"a+t")) == NULL ) {
		fprintf(stderr,"E-%s-011 Unable to open log [%s]\n", PRODUCT_ALIAS, logname );
		exit(1);
	}

	/* Open Debug file */
	if(( syslg_debug_fp = fopen(debugname,"a+t")) == NULL ) {
		fprintf(stderr,"E-%s-012 Unable to open debug [%s]\n", PRODUCT_ALIAS, debugname );
     	exit(1);
	}

	/* Send Some Messages do Debug and Log */
	debug_log(syslg_debug_fp,"Current %s Syslg Key: [0x%x]\n", PRODUCT_ALIAS, get_shm_syslg_key());
	fprintf(stdout,"Current %s Syslg Key: [0x%x]\n", PRODUCT_ALIAS, get_shm_syslg_key());
	debug_log(syslg_debug_fp,"catch_all_signals[%d]\n", catch_all_signals(&signal_handler));
	debug_log( syslg_debug_fp, "Syslg Started\n");
	syslg("Syslg Started\n");

	/* Catch all messages to write in log */
	for( ;; )
	{
		if (syslg_get_queue_message(msqid, &rbuf, MSGSZ, 1, 0) < 0) {
		} else {
			fprintf(syslg_fp,"%s",rbuf.mtext);
			fflush(syslg_fp);
		}
	}
}

int usage( char *progname )
{
	char msg[]= { "usage: %s [-s <message>] [-v <key|log|mon|all>] [-r] [-i] [-f]\n-s   Send syslg message\n-v   View Information of key,log,mon\n-i   Initialize syslg process\n-f   Finish syslg process\n-r   Release Resources" };
	fprintf( stderr, msg, progname );
	return(1);
}

int parse_options( int argc, char *argv[] )
{
	int opt;
	char *msg;
	opterr = 0;

	if( argc == 1 ) return -1;

	while ( (opt = getopt(argc, argv, "a:rifs:v:")) != -1 )
	{
		/*printf("[%d=>%c:%s:%c]\n",optind,opt,optarg,optopt);*/
		switch ( opt )
		{
			case 'r':
				syslgfunction = RELEASE_FUNCTION;
				break;

			case 'a':
				if( optarg == NULL ) return -1;
				syslgfunction_param = optarg;
				if (!strcmp(syslgfunction_param,"start"))
					syslgfunction = START_FUNCTION;
				if (!strcmp(syslgfunction_param,"stop"))
					syslgfunction = STOP_FUNCTION;
				if (!strcmp(syslgfunction_param,"release"))
					syslgfunction = RELEASE_FUNCTION;
				if( syslgfunction == -1 ) return(-1);
				break;

			case 'i':
				syslgfunction = START_FUNCTION;
				break;

			case 'f':
				syslgfunction = STOP_FUNCTION;
				break;

			case 's':
				syslgfunction = SEND_FUNCTION;
				syslgfunction_param = optarg;
				if( !syslgfunction_param )
					return(-1);
				break;

			case 'v':
				if( optarg == NULL ) return -1;
				syslgfunction_param = optarg;
				if (!strcmp(syslgfunction_param,"key"))
					syslgfunction = KEY_FUNCTION;
				if (!strcmp(syslgfunction_param,"log"))
					syslgfunction = LOG_FUNCTION;
				if (!strcmp(syslgfunction_param,"mon"))
					syslgfunction = MON_FUNCTION;
				if (!strcmp(syslgfunction_param,"all"))
					syslgfunction = ALL_FUNCTION;
				if( syslgfunction == -1 ) return(-1);
				break;
			case '?':
				return(-2);
		}
	}
	return(0);
}

int syslg_start( void )
{
	pid_t syslg_handle = fork();

	if( syslg_handle == 0 )
		syslg_handler();
	else
	{
		fprintf(stdout,"Current %s Syslg Handler : [%d]\n", PRODUCT_ALIAS, syslg_handle );
	}
	return(0);
}

int syslg_stop( void )
{
	kill(syslg_get_active_pid(),SIGTERM);
}

int syslg_release()
{
	int rc;

	/* Send Message do Debug Info */
	debug_log( syslg_debug_fp, "Releasing Resources... Need to restart SYSLG again\n" );

	/* Remove SHM */
	if ((rc = syslg_remove_shm()) < 0)
		debug_log( syslg_debug_fp, "SHM could not be deleted [%d]. Errno [%d]\n", rc, errno );

	/* Remove SHM */
	if ((rc = syslg_remove_semaphore()) < 0)
		debug_log( syslg_debug_fp, "Semaphore could not be deleted [%d]. Errno [%d]\n", rc, errno );

	/* Remove Queue */
	if ((rc = syslg_remove_queue()) < 0)
		debug_log( syslg_debug_fp, "Message queue could not be deleted [%d]. Errno [%d]\n", rc, errno );

	return(0);
}

int syslg_send()
{
	int  syslgsend_rc = 0;

	syslg_arg0(MODULE_NAME);

	if(( syslgsend_rc = syslgsend(syslgfunction_param)) < 0)
	{
		fprintf(stderr,"E-%s-006 syslg_send error [%d]\n", PRODUCT_ALIAS, syslgsend_rc );
		debug_log(syslg_debug_fp,"E-%s-006 syslg_send error [%d]\n", PRODUCT_ALIAS, syslgsend_rc );
		return(-2);
    }
 	return (0);
}

int syslg_view_mon() {
	syslg_shm_show_memory();
}

int syslg_view_key() {
	fprintf(stdout,"Current %s Syslg Key: [0x%x]\n", PRODUCT_ALIAS, get_shm_syslg_key());
	return(0);
}

int syslg_view_log() {
	char logname[MAX_IST_STRING] = {0};
	cf_locate(PRODUCT_KEY_MASTERLOG,logname);
	fprintf(stdout,"Current %s Log: [%s]\n", PRODUCT_ALIAS, logname);
	return(0);
}

int main(int argc, char *argv[])
{
	char* shmid;
	char* cfgname;
	char *progname;

	progname = basename( argv[0] );

	if( parse_options( argc, argv ) < 0)
		return usage(progname);

	shmid = getenv (PRODUCT_SHM_VAR);

	if (shmid == NULL) {
		fprintf(stderr,"E-%s-001 Variable %s not setted\n", PRODUCT_ALIAS, PRODUCT_SHM_VAR );
		exit(1);
	}

	cfgname = getenv (PRODUCT_CFG_VAR);

	if (cfgname == NULL) {
		fprintf(stderr,"E-%s-002 Variable %s not setted\n", PRODUCT_ALIAS, PRODUCT_CFG_VAR );
		exit(1);
	}

	if( cf_open( cfgname ) < 0 )
	{
		fprintf(stderr,"E-%s-003 Error to open Configuration File [%s]\n", PRODUCT_ALIAS, PRODUCT_CFG_VAR );
		exit(1);
	}

	switch ( syslgfunction )
	{
		case START_FUNCTION :
			syslg_start();
			fprintf(stdout,"Current %s Region : [%s]\n",PRODUCT_ALIAS, shmid);
			fprintf(stdout,"Current %s Configuration : [%s]\n",PRODUCT_ALIAS, cfgname);
			syslg_view_key();
			syslg_view_log();
			break;
			
		case STOP_FUNCTION :
			syslg_stop();
			break;

		case RELEASE_FUNCTION :
			syslg_release();
			break;
			
		case SEND_FUNCTION :
			syslg_send();
			break;
			
		case MON_FUNCTION :
			syslg_view_mon();
			break;
			
		case KEY_FUNCTION :
			syslg_view_key();
			break;
			
		case LOG_FUNCTION :
			syslg_view_log();
			break;
			
		case ALL_FUNCTION :
			syslg_view_key();
			syslg_view_log();
			syslg_view_mon();
			break;
	}
	exit(0);
}
#ifndef _PORTS_H_
#define _PORTS_H_
#include "ist_functions.h"
#include <sys/socket.h>
#include <sys/types.h>

enum { 
	LEN_TYPE_NONE = 0,
	LEN_TYPE_2BIN,
	LEN_TYPE_4ASC,
	LEN_TYPE_4BIN
};

enum {
	DISCONNECTED_STATUS = 0,
	CONNECTED_STATUS = 1
};

enum {
	CLOSED_LOG = 0,
	OPENED_LOG = 1
};

struct ports_records
{
	/* ISTPARAM Parameters */
	char port_name[MAX_IST_STRING];
	char port_label[MAX_IST_STRING];
	char port_type[MAX_IST_STRING];
	char port_ip[MAX_IST_STRING];
	int port_number;
	char port_format[MAX_IST_STRING];
	int port_headerlen;
	int port_headertype;
	int port_tpdu;
	int port_multi;
	char port_method[MAX_IST_STRING];
	char port_methodparam[MAX_IST_STRING];
	char port_log[MAX_IST_STRING];
	/* Control Parameters */
	int  port_log_fp;
	int  port_server_sockfd;
	struct sockaddr_in port_serv_addr;
	int  port_client_sockfd;
	struct sockaddr_in port_client_addr;
	socklen_t port_addrlen;
	pid_t  port_pid;
	int  port_status_log;	
};

struct ports_records PORTS[MAX_PORTS] = {0};

static int PORT_ID = 0;
#endif
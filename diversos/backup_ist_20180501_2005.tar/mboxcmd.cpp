#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/stat.h>
#include <assert.h>
#include <signal.h>
#include <errno.h>
#include <string>

#include "syslg.h"
#include "mailbox.h"
#include "ist_functions.h"
#include "misc_functions.h"

#define MODULE_NAME  "mboxcmd"

enum {
	/* Stop Start */
	START_FUNCTION = 0,
	STOP_FUNCTION,
	RELEASE_FUNCTION,
	
	/* Monitor Functions */
	MON_FUNCTION,
    DEEP_FUNCTION,
	KEY_FUNCTION,
	ALL_FUNCTION,

	/* Action Functions */
    CREATE_FUNCTION,
    DUPLICATE_FUNCTION,
    DESTROY_FUNCTION,
    SEND_MSG_FUNCTION,
    READ_MSG_FUNCTION,
    CLEAR_QUEUE_FUNCTION,
    CLEAR_STAT_FUNCTION
};

static shm_mbox_system_header *shm = NULL;
static int mboxfunction = -1;
char *mboxfunction_param = NULL;

void signal_handler(int signo)
{
	int rc;
	char msg[MAX_IST_STRING] = {0};

	/* Send Message do Debug Info */
	sprintf(msg,"Signal Received [%d]",signo );
	debug_log( mbox_debug_fp, "%s\n", msg );
	syslg("%s\n",msg);

	/* Remove Queue */
	if ((rc = mbox_remove_queues()) < 0)
		debug_log( mbox_debug_fp, "Message queues could not be deleted [%d]. Errno [%d]\n", rc, errno );	

	/* Remove SHM */
	if ((rc = mbox_remove_shm()) < 0)
		debug_log( mbox_debug_fp, "SHM could not be deleted [%d]. Errno [%d]\n", rc, errno );

	/* Remove SHM */
	if ((rc = mbox_remove_semaphore()) < 0)
		debug_log( mbox_debug_fp, "Semaphore could not be deleted [%d]. Errno [%d]\n", rc, errno );

	/* Close files */
	fclose(mbox_debug_fp);

	/* Exit with signal received */
	exit(signo);
}

int mbox_handler( void )
{
	char debugname[MAX_IST_STRING] = {0};
    int msqid, semid, shmid;
    int maxmbox = 0;

	syslg_arg0(MODULE_NAME);

	/* Get SHM Header */
	shm = get_mbox_shm_stat ();
	if( shm != NULL ) {
		fprintf(stderr,"E-%s-012 Mbox already started with PID [%d]\n", PRODUCT_ALIAS, shm->pid );
		exit(1);
	}

	/* Get Parameters */
	cf_locate(PRODUCT_KEY_MASTERDIRDEBUG,debugname);
	sprintf(debugname,"%s/%s.debug",debugname,MODULE_NAME);
	/*fprintf(stdout,"==>[%s]",PRODUCT_KEY_MAX_MB);*/
    cf_locatenum(PRODUCT_KEY_MAX_MB,&maxmbox);
	debug_log(mbox_debug_fp,"Current %s Max Number of Mbox : [%d]\n", PRODUCT_ALIAS, maxmbox);
	fprintf(stdout,"Current %s Max Number of Mbox : [%d]\n", PRODUCT_ALIAS, maxmbox);

	if((shmid = mbox_shm_create_memory( &shm, maxmbox )) < 0 )
	{
		fprintf(stderr,"E-%s-013 Cannot create SHM. Check user permission\n", PRODUCT_ALIAS );
		exit(1);
	}

	if(( semid = mbox_shm_create_semaphore()) < 0 )
	{
		fprintf(stderr,"E-%s-014 Cannot create semaphore. Check user permission\n", PRODUCT_ALIAS );
		exit(1);
	}

	shm->semid = semid;
	shm->shmid = shmid;

	mbox_shm_format_memory(shm);

	if( mbox_shm_init_semaphore( semid ) < 0 ) {
		fprintf(stderr,"E-%s-015 Cannot initialize semaphore. Check user permission\n", PRODUCT_ALIAS );
		exit(1);
	}

	/* Open Debug file */
	if(( mbox_debug_fp = fopen(debugname,"a+t")) == NULL ) {
		fprintf(stderr,"E-%s-012 Unable to open debug [%s]\n", PRODUCT_ALIAS, debugname );
     	exit(1);
	}

	/* Send Some Messages do Debug and Log */
	debug_log(mbox_debug_fp,"Current %s Mbox Key: [0x%x]\n", PRODUCT_ALIAS, get_shm_mbox_key());
	fprintf(stdout,"Current %s Mbox Key: [0x%x]\n", PRODUCT_ALIAS, get_shm_mbox_key());
	debug_log(mbox_debug_fp,"catch_all_signals[%d]\n", catch_all_signals(&signal_handler));
    syslg("Mbox System Started\n");
	debug_log(mbox_debug_fp, "Mbox System Started\n");

	for( ;; )
	{
        sleep(5);
        debug_log(mbox_debug_fp,"Mbox System alive\n");
	}
}

int usage( char *progname )
{
	char msg[]= { "usage: %s [-s <message>] [-v <key|log|mon|all>] [-i] [-f]\n-s   Send mbox message\n-v   View Information of key,mon\n-a   <start,init,stop,finish,release,deep,clearq,clears>\n-i   Initialize Mbox process\n-f   Finish Mbox process\n-r   Release Resources" };
	fprintf( stderr, msg, progname );
	return(1);
}

int parse_options( int argc, char *argv[] )
{
	int opt;
	char *msg;
	opterr = 0;

	if( argc == 1 ) return -1;

	while ( (opt = getopt(argc, argv, "ra:ifs:v:")) != -1 )
	{
		/*printf("[%d=>%c:%s:%c]\n",optind,opt,optarg,optopt);*/
		switch ( opt )
		{
			case 'r':
				mboxfunction = RELEASE_FUNCTION;
				break;

            case 'a':
            	if( optarg == NULL ) return -1;
				mboxfunction_param = optarg;

				if (!strcmp(mboxfunction_param,"start"))
					mboxfunction = START_FUNCTION;

				if (!strcmp(mboxfunction_param,"init"))
					mboxfunction = START_FUNCTION;                    

				if (!strcmp(mboxfunction_param,"stop"))
					mboxfunction = STOP_FUNCTION;

				if (!strcmp(mboxfunction_param,"release"))
					mboxfunction = RELEASE_FUNCTION;					

				if (!strcmp(mboxfunction_param,"finish"))
					mboxfunction = STOP_FUNCTION;

				if (!strcmp(mboxfunction_param,"clearq"))
					mboxfunction = CLEAR_QUEUE_FUNCTION;

				if (!strcmp(mboxfunction_param,"clears"))
					mboxfunction = CLEAR_STAT_FUNCTION;

				if (!strcmp(mboxfunction_param,"send"))
					mboxfunction = SEND_MSG_FUNCTION;

				if (!strcmp(mboxfunction_param,"delete"))
					mboxfunction = DESTROY_FUNCTION;

				if (!strcmp(mboxfunction_param,"duplicate"))
					mboxfunction = DUPLICATE_FUNCTION; 
                                     
				if (!strcmp(mboxfunction_param,"create"))
					mboxfunction = CREATE_FUNCTION;

				if (!strcmp(mboxfunction_param,"read"))
					mboxfunction = CREATE_FUNCTION;                    

				if( mboxfunction == -1 ) return(-1);
                break;

			case 'i':
				mboxfunction = START_FUNCTION;
				break;

			case 'f':
				mboxfunction = STOP_FUNCTION;
				break;

			case 's':
				mboxfunction = SEND_MSG_FUNCTION;
				mboxfunction_param = optarg;

				if( !mboxfunction_param )
					return(-1);
				break;

			case 'v':
				if( optarg == NULL ) return -1;
				mboxfunction_param = optarg;

				if (!strcmp(mboxfunction_param,"key"))
					mboxfunction = KEY_FUNCTION;

				if (!strcmp(mboxfunction_param,"mon"))
					mboxfunction = MON_FUNCTION;

				if (!strcmp(mboxfunction_param,"deep"))
					mboxfunction = DEEP_FUNCTION;

				if (!strcmp(mboxfunction_param,"all"))
					mboxfunction = ALL_FUNCTION;

				if( mboxfunction == -1 ) return(-1);
				break;

			case '?':
				return(-2);
		}
	}
	return(0);
}

int mbox_start( void )
{
	pid_t mbox_handle = fork();

	if( mbox_handle == 0 )
		mbox_handler();
	else
	{
		fprintf(stdout,"Current %s MBOX Handler : [%d]\n", PRODUCT_ALIAS, mbox_handle );
	}
	return(0);
}

int mbox_stop( void )
{
	kill(mbox_get_active_pid(),SIGTERM);
}

int mbox_release()
{
	int rc;

	/* Send Message do Debug Info */
	debug_log( syslg_debug_fp, "Releasing Resources... Need to restart Mbox again\n" );

	/* Remove Queue */
	if ((rc = mbox_remove_queues()) < 0)
		debug_log( mbox_debug_fp, "Message queues could not be deleted [%d]. Errno [%d]\n", rc, errno );	

	/* Remove SHM */
	if ((rc = mbox_remove_shm()) < 0)
		debug_log( mbox_debug_fp, "SHM could not be deleted [%d]. Errno [%d]\n", rc, errno );

	/* Remove SHM */
	if ((rc = mbox_remove_semaphore()) < 0)
		debug_log( mbox_debug_fp, "Semaphore could not be deleted [%d]. Errno [%d]\n", rc, errno );

	/* Close files */
	fclose(mbox_debug_fp);

	return(0);
}

int mbox_view_mon() {
	mbox_shm_show_memory();
}

int mbox_view_key() {
	fprintf(stdout,"Current %s Mbox Key: [0x%x]\n", PRODUCT_ALIAS, get_shm_mbox_key());
	return(0);
}

int mbox_deep_mon() 
{
}

int mbox_create()
{
}

int mbox_duplicate()
{
}

int mbox_destroy()
{
}

int mbox_send_msg()
{
    /*
	int rc = 0;
	syslg_arg0(MODULE_NAME);
	if(( rc = mboxsend(mboxfunction_param)) < 0)
	{
		fprintf(stderr,"E-%s-006 mbox_send error [%d]\n", PRODUCT_ALIAS, rc );
		debug_log(syslg_debug_fp,"E-%s-006 mbox_send error [%d]\n", PRODUCT_ALIAS, rc );
		return(-2);
    }
 	return (0);
    */
}

int mbox_clear_queue_msg()
{
}

int mbox_clear_stat_msg()
{
    
}

int main(int argc, char *argv[])
{
	char* shmid;
	char* cfgname;
	char *progname;

	progname = basename( argv[0] );

	if( parse_options( argc, argv ) < 0)
		return usage(progname);

	shmid = getenv (PRODUCT_SHM_VAR);

	if (shmid == NULL) {
		fprintf(stderr,"E-%s-001 Variable %s not setted\n", PRODUCT_ALIAS, PRODUCT_SHM_VAR );
		exit(1);
	}

	cfgname = getenv (PRODUCT_CFG_VAR);

	if (cfgname == NULL) {
		fprintf(stderr,"E-%s-002 Variable %s not setted\n", PRODUCT_ALIAS, PRODUCT_CFG_VAR );
		exit(1);
	}

	if( cf_open( cfgname ) < 0 )
	{
		fprintf(stderr,"E-%s-003 Error to open Configuration File [%s]\n", PRODUCT_ALIAS, PRODUCT_CFG_VAR );
		exit(1);
	}

	switch ( mboxfunction )
	{
		case START_FUNCTION :
			mbox_start();
			fprintf(stdout,"Current %s Region : [%s]\n",PRODUCT_ALIAS, shmid);
			fprintf(stdout,"Current %s Configuration : [%s]\n",PRODUCT_ALIAS, cfgname);
			mbox_view_key();
			break;
			
		case STOP_FUNCTION :
			mbox_stop();
			break;

		case RELEASE_FUNCTION :
			mbox_release();
			break;			
			
		case MON_FUNCTION :
			mbox_view_mon();
			break;
			
		case KEY_FUNCTION :
			mbox_view_key();
			break;
			
		case ALL_FUNCTION :
			mbox_view_key();
			mbox_view_mon();
			break;

        case DEEP_FUNCTION :
            mbox_deep_mon();
            break;

    	case CREATE_FUNCTION :
            mbox_create();
            break;

    	case DUPLICATE_FUNCTION :
            mbox_duplicate();
            break;

    	case DESTROY_FUNCTION :
            mbox_destroy();
            break;

    	case SEND_MSG_FUNCTION :
            mbox_send_msg();
            break;

    	case READ_MSG_FUNCTION :
            mbox_send_msg();
            break;
    
    	case CLEAR_QUEUE_FUNCTION :
            mbox_clear_queue_msg();
            break;

    	case CLEAR_STAT_FUNCTION :
            mbox_clear_stat_msg();
            break;
    }

	exit(0);
}
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/errno.h>
#include <sys/errno.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/stat.h>
#include <assert.h>
#include <string>

using namespace std;

#include "mailbox.h"
#include "ist_functions.h"
#include "misc_functions.h"
#include "gen_functions.h"

shm_mbox_system_header * get_mbox_shm_stat ( void ) 
{
	int shmid = shmget( get_shm_mbox_key(), 0, S_IWUSR|S_IRUSR );
	if( shmid == -1 )
		return NULL;		/* Nao foi possivel localizar a shared memory */
	return (shm_mbox_system_header *)shmat( shmid, NULL, 0 );
}

int mbox_shm_create_memory( shm_mbox_system_header **shm, int maxmbox )
{
	/* Create Shared Memory */
	register key_t key = get_shm_mbox_key();

	int shmid = shmget( key, sizeof(shm_mbox_system_header), IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR );
	
	if( shmid == -1 )
	{
		if( errno == EEXIST )
		{
			/* A shared memory ja existe, deve ser eliminada */
			shmid = shmget( key, 1, S_IRUSR | S_IWUSR );
			if( shmid == -1 )
				return -1;
			if( shmctl(shmid, IPC_RMID, 0) == -1 )
				return -2;
			else
				return mbox_shm_create_memory( shm, maxmbox ); /* tentar cria-la novamente */
		}
		return -3;
	}
	
	/* A shared memory foi criada */
	*shm = (shm_mbox_system_header *) shmat( shmid, NULL, 0 );
	
	memset( *shm, 0, sizeof(shm_mbox_system_header));
    
	(*shm)->buff_qty = maxmbox;

	return shmid;
}

int mbox_shm_create_semaphore()
{
	int retcode;
    register key_t key = get_shm_mbox_key();
	int semid = semget( key, 1, IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR );
	if( semid == -1 )
	{
		if( errno == EEXIST )
		{
			/* O semaforo ja existe, deve ser eliminado */
			semid = semget( key, 1, S_IRUSR | S_IWUSR );
			if( semid == -1 )
				return -1;
			retcode = semctl( semid, 0, IPC_RMID, NULL );
			if( retcode != 0 )
				return -4;
			else
				return mbox_shm_create_semaphore(); /* tentar cria-lo novamente */
		}
		return -2;
	}
	return semid;
}

int mbox_shm_format_memory( shm_mbox_system_header *shm )
{
	assert( shm != NULL );

	int    semid;
	int    pid;

	time_t timestamp;
	shm->signature = MAILBOX_HEADER_SIGNATURE;
	shm->pid = getpid();
	shm->timestamp = get_timestamp();
    shm->buff_qty = get_shm_buff_qty();
    shm->buff_len = get_shm_buff_len();
    shm->lastindex = 0;

	for( int idx = 0; idx < shm->buff_qty; idx ++ )
	{
		shm_mbox_header *mb = get_mbox_index_header( idx, shm );
		mb->signature = MAILBOX_SIGNATURE;
        mb->msqid = -1;
        mb->mbid = -1;
	}
	return (0);
}

int mbox_shm_init_semaphore( int semid )
{
	int retcode;
	static struct sembuf operations[1];
	/* Inicializar semaforo */
    operations[0].sem_num = 0;
    operations[0].sem_op = 1;
    operations[0].sem_flg = 0;
    retcode = semop( semid, operations, 1 );

	if( retcode != 0 )
		return -1;		/* Erro ao tentar liberar o semaforo */

	return 0;
}

int mbox_shm_show_memory()
{
	struct shmid_ds stat_buf ;
	
	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();
	
	if( mem_ptr == NULL )
		return -5;
		
	if( mem_ptr == (void*)-1 )
		return -4;		/* Nao foi possivel anexar a shared memory */

	if( mem_ptr->signature != MAILBOX_HEADER_SIGNATURE )
		return -2;		/* A assinatura da shared memory e invalida */

	if ( shmctl(mem_ptr->shmid,IPC_STAT, &stat_buf) == -1)
		return -3;

	fprintf(stdout,"================ SHM INFORMATION ========================\n");
	fprintf(stdout,"Signature    : 0x%x\n", mem_ptr->signature);
	fprintf(stdout,"SHM ID       : %d\n",   mem_ptr->shmid);
	fprintf(stdout,"Semaphore ID : %d\n",   mem_ptr->semid);
	fprintf(stdout,"PID          : %d\n",   mem_ptr->pid);
    fprintf(stdout,"MBox in Use  : %d\n",   mem_ptr->lastindex);
    fprintf(stdout,"Max MBox     : %d\n",   mem_ptr->buff_qty);
    fprintf(stdout,"Owner ID     : %d\n",   stat_buf.shm_perm.uid);
	fprintf(stdout,"Owner Group  : %d\n",   stat_buf.shm_perm.gid);
	fprintf(stdout,"Creator ID   : %d\n",   stat_buf.shm_perm.cuid);
	fprintf(stdout,"Creator Group: %d\n",   stat_buf.shm_perm.cgid);
	fprintf(stdout,"Access Mode  : %d\n",   stat_buf.shm_perm.mode);
	fprintf(stdout,"Size         : %d\n",   stat_buf.shm_segsz);
	fprintf(stdout,"Creator PID  : %d\n",   stat_buf.shm_cpid);
	fprintf(stdout,"Last PID     : %d\n",   stat_buf.shm_lpid);
	fprintf(stdout,"Uptime       : %s\n",   get_formatted_timestamp(mem_ptr->timestamp).c_str());
	fprintf(stdout,"=========================================================\n");
	
	return(0);
}

shm_mbox_header *get_mbox_index_header( unsigned short index, shm_mbox_system_header *ptr )
{
	shm_mbox_header *ptr_to_first_header;
	size_t total_buff_len;

	assert( ptr != NULL );
	ptr_to_first_header = (shm_mbox_header *) ((char*)ptr + sizeof(shm_mbox_system_header));
	total_buff_len =  ptr->buff_len + sizeof(shm_mbox_header);

	assert( total_buff_len != 0 );

	shm_mbox_header *ret = (shm_mbox_header *) ((char*)ptr_to_first_header + total_buff_len * index);

	assert( ret >= ptr_to_first_header );
	assert( ret <  (shm_mbox_header *) ((char*)ptr_to_first_header + total_buff_len * ptr->buff_qty) );

	return ret;
}

size_t get_total_shm_len( void )
{
	size_t len = sizeof( shm_mbox_system_header );
	len += sizeof( shm_mbox_header ) * get_shm_buff_qty();

	return len;
}

size_t get_shm_buff_len( void )
{
    return sizeof(shm_mbox_header);
}

size_t get_shm_buff_qty( void )
{
    int buff_qty;
    cf_locatenum(PRODUCT_KEY_MAX_MB,&buff_qty);
	return (size_t)buff_qty;
}

int mbox_get_shm_id()
{
	return(shmget(get_shm_mbox_key(),sizeof( shm_mbox_system_header ), 0 ));
}

int mbox_get_semaphore_id()
{
	return semget( get_shm_mbox_key(), 1, S_IRUSR | S_IWUSR );
}

int mbox_remove_shm()
{
	return(shmctl(mbox_get_shm_id(),IPC_RMID, NULL));
}

int mbox_remove_semaphore()
{
	return(semctl(mbox_get_semaphore_id(),0,IPC_RMID,0));
}

int  mbox_remove_queues()
{
	struct shmid_ds stat_buf ;
	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();
	
	if( mem_ptr == (void*)-1 )
		return -4;		/* Nao foi possivel anexar a shared memory */

	if( mem_ptr->signature != MAILBOX_HEADER_SIGNATURE )
		return -2;		/* A assinatura da shared memory e invalida */

	if ( shmctl(mem_ptr->shmid,IPC_STAT, &stat_buf) == -1)
		return -3;

	for( int idx = 0; idx < mem_ptr->lastindex; idx ++ )
	{
		shm_mbox_header *mb = get_mbox_index_header( idx, mem_ptr );
		msgctl(mb->msqid,IPC_RMID, NULL);
		debug_log(mbox_debug_fp,"Queue Remove[%d:%s] => Status [%d]\n",mb->msqid,mb->mbname,errno);
	}
	return(0);
}


int mbox_get_active_pid()
{
	struct shmid_ds stat_buf ;
	
	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();

	if( mem_ptr == (void*)-1 )
		return -4;		/* Nao foi possivel anexar a shared memory */

	if( mem_ptr->signature != MAILBOX_HEADER_SIGNATURE )
		return -2;		/* A assinatura da shared memory e invalida */

	return(mem_ptr->pid);
}

key_t get_shm_mbox_key( void )
{
	register key_t key = MAILBOX_BASE_KEY;

	if (!getenv(PRODUCT_SHM_VAR))
		return 0;

	register int region = atoi(getenv(PRODUCT_SHM_VAR)) % 256;
	key += region;
	key += region << 8;
	key += region << 16;
	key += region << 24;

	return key;
}
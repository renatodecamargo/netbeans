#ifndef _SYSLG_H_
#define _SYSLG_H_

#include "ist_functions.h"

#define SYSLG_HEADER_SIGNATURE 0xFEFEFEFE
#define SYSLG_BASE_KEY         0x53414444
#define MSGSZ     		       1024

typedef struct {
	int    signature;
	char   logname[MAX_IST_STRING];
	int    shmid;
	int    semid;
	int    msqid;
	int    pid;
	time_t timestamp;
} shm_syslg_header;

static char syslg_log[MAX_IST_STRING] = {0};
static FILE *syslg_fp = NULL;
static FILE *syslg_debug_fp = NULL;
static char syslg_arg0_module_name[MAX_IST_STRING] = "???";

int syslg_arg0( const char *module_name );
int syslg( const char * format, ... );
int syslgsend( const char *data_buffer );
int syslg_get_queue_id();
int syslg_get_queue_message(int msqid, void *msgp, size_t msgsz, long msgtyp, int msgflg);
int syslg_create_queue();
int syslg_remove_queue();
int syslg_remove_shm();
int syslg_remove_semaphore();
key_t get_shm_syslg_key();
int syslg_shm_create_memory( shm_syslg_header **shm );
int syslg_shm_create_semaphore();
int syslg_shm_format_memory( shm_syslg_header *shm );
int syslg_shm_show_memory();
int syslg_shm_init_semaphore( int semid );
int syslg_get_active_pid();
shm_syslg_header * get_syslg_shm_stat () ;

struct message_buf {
	long    mtype;
	char    mtext[MSGSZ];
};

#endif
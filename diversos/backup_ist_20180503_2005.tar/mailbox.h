#ifndef _MAILBOX_H_
#define _MAILBOX_H_

#include "ist_functions.h"

#define MAILBOX_HEADER_SIGNATURE 0xFCFCFCFC
#define MAILBOX_SIGNATURE        0xFAFAFAFA
#define MAILBOX_BASE_KEY       0x53412222
#define MSGSZ     		       1024

static FILE *mbox_debug_fp = NULL;

typedef struct {
	int     signature;
	int     shmid;
	int     semid;
	int     pid;
    size_t  buff_qty;
	size_t  buff_len;
    int     lastindex;
	time_t  timestamp;
} shm_mbox_system_header;

typedef struct {
	int    signature;
	int    msqid;
    int    mbid;
    char   mbname[MAX_IST_STRING];
    int    maxmsg;
} shm_mbox_header;

shm_mbox_system_header * get_mbox_shm_stat ( void ) ;
int mbox_shm_create_memory( shm_mbox_system_header **shm );
int mbox_shm_create_semaphore();
int mbox_shm_format_memory( shm_mbox_system_header *shm );
int mbox_shm_init_semaphore( int semid );
int mbox_shm_show_memory();
shm_mbox_header *get_mbox_index_header( unsigned short index, shm_mbox_system_header *ptr );
size_t get_total_shm_len( void );
size_t get_shm_buff_len( void );
size_t get_shm_buff_qty( void );
int mbox_get_active_pid();
key_t get_shm_private_mbox_key( int idx );
key_t get_shm_mbox_key( void );
int mbox_get_shm_id();
int mbox_get_semaphore_id();
int mbox_remove_shm();
int mbox_remove_semaphore();
int  mbox_remove_queues();
int mbox_create( char *mboxname );
int mbox_shm_show_depth();

#endif
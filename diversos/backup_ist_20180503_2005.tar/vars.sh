export LSWID=101
export LSWCFG=/home4/renatod1/src/c/ist/cfg/lswparam.cfg

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/errno.h>
#include <sys/errno.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/stat.h>
#include <assert.h>
#include <string>

using namespace std;

#include "mailbox.h"
#include "ist_functions.h"
#include "misc_functions.h"
#include "gen_functions.h"

shm_mbox_system_header * get_mbox_shm_stat ( void ) 
{
	int shmid = shmget( get_shm_mbox_key(), 0, S_IWUSR|S_IRUSR );
	if( shmid == -1 )
		return NULL;		/* Nao foi possivel localizar a shared memory */
	return (shm_mbox_system_header *)shmat( shmid, NULL, 0 );
}

int mbox_shm_create_memory( shm_mbox_system_header **shm )
{
	/* Create Shared Memory */
	register key_t key = get_shm_mbox_key();
	size_t shmsize = get_total_shm_len();

	int shmid = shmget( key, shmsize, IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR );
	
	if( shmid == -1 )
	{
		if( errno == EEXIST )
		{
			/* A shared memory ja existe, deve ser eliminada */
			shmid = shmget( key, 1, S_IRUSR | S_IWUSR );
			if( shmid == -1 )
				return -1;
			if( shmctl(shmid, IPC_RMID, 0) == -1 )
				return -2;
			else
				return mbox_shm_create_memory( shm ); /* tentar cria-la novamente */
		}
		return -3;
	}
	
	/* A shared memory foi criada */
	*shm = (shm_mbox_system_header *) shmat( shmid, NULL, 0 );
	
	memset( *shm, 0, sizeof(shm_mbox_system_header));
    
	(*shm)->buff_qty = get_shm_buff_qty();

	return shmid;
}

int mbox_shm_create_semaphore()
{
	int retcode;
    register key_t key = get_shm_mbox_key();
	int semid = semget( key, 1, IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR );
	if( semid == -1 )
	{
		if( errno == EEXIST )
		{
			/* O semaforo ja existe, deve ser eliminado */
			semid = semget( key, 1, S_IRUSR | S_IWUSR );
			if( semid == -1 )
				return -1;
			retcode = semctl( semid, 0, IPC_RMID, NULL );
			if( retcode != 0 )
				return -4;
			else
				return mbox_shm_create_semaphore(); /* tentar cria-lo novamente */
		}
		return -2;
	}
	return semid;
}

int mbox_shm_format_memory( shm_mbox_system_header *shm )
{
	assert( shm != NULL );

	int    semid;
	int    pid;

	time_t timestamp;
	shm->signature = MAILBOX_HEADER_SIGNATURE;
	shm->pid = getpid();
	shm->timestamp = get_timestamp();
    shm->buff_qty = get_shm_buff_qty();
    shm->buff_len = get_shm_buff_len();
    shm->lastindex = 0;

	for( int idx = 0; idx < shm->buff_qty; idx ++ )
	{
		shm_mbox_header *mb = get_mbox_index_header( idx, shm );
		mb->signature = MAILBOX_SIGNATURE;
        mb->msqid = -1;
        mb->mbid = -1;
		mb->maxmsg = 0;
	}
	return (0);
}

int mbox_shm_init_semaphore( int semid )
{
	int retcode;
	static struct sembuf operations[1];

	/* Inicializar semaforo */
    operations[0].sem_num = 0;
    operations[0].sem_op = 1;
    operations[0].sem_flg = 0;
    retcode = semop( semid, operations, 1 );

	if( retcode != 0 )
		return -1;		/* Erro ao tentar liberar o semaforo */

	return 0;
}

int mbox_shm_show_memory()
{
	struct shmid_ds stat_buf ;
	
	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();
	
	if( mem_ptr == NULL )
		return -5;
		
	if( mem_ptr == (void*)-1 )
		return -4;		/* Nao foi possivel anexar a shared memory */

	if( mem_ptr->signature != MAILBOX_HEADER_SIGNATURE )
		return -2;		/* A assinatura da shared memory e invalida */

	if ( shmctl(mem_ptr->shmid,IPC_STAT, &stat_buf) == -1)
		return -3;

	fprintf(stdout,"================ SHM INFORMATION ========================\n");
	fprintf(stdout,"Signature    : 0x%x\n", mem_ptr->signature);
	fprintf(stdout,"SHM ID       : %d\n",   mem_ptr->shmid);
	fprintf(stdout,"Semaphore ID : %d\n",   mem_ptr->semid);
	fprintf(stdout,"PID          : %d\n",   mem_ptr->pid);
    fprintf(stdout,"MBox in Use  : %d\n",   mem_ptr->lastindex);
    fprintf(stdout,"Max MBox     : %d\n",   mem_ptr->buff_qty);
    fprintf(stdout,"Owner ID     : %d\n",   stat_buf.shm_perm.uid);
	fprintf(stdout,"Owner Group  : %d\n",   stat_buf.shm_perm.gid);
	fprintf(stdout,"Creator ID   : %d\n",   stat_buf.shm_perm.cuid);
	fprintf(stdout,"Creator Group: %d\n",   stat_buf.shm_perm.cgid);
	fprintf(stdout,"Access Mode  : %d\n",   stat_buf.shm_perm.mode);
	fprintf(stdout,"Size         : %d\n",   stat_buf.shm_segsz);
	fprintf(stdout,"Creator PID  : %d\n",   stat_buf.shm_cpid);
	fprintf(stdout,"Last PID     : %d\n",   stat_buf.shm_lpid);
	fprintf(stdout,"Uptime       : %s\n",   get_formatted_timestamp(mem_ptr->timestamp).c_str());
	fprintf(stdout,"=========================================================\n");
	
	return(0);
}

int mbox_shm_show_depth()
{
	struct msqid_ds buf;

	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();
	
	if( mem_ptr == NULL )
		return -5;
		
	if( mem_ptr == (void*)-1 )
		return -4;		/* Nao foi possivel anexar a shared memory */

	if( mem_ptr->signature != MAILBOX_HEADER_SIGNATURE )
		return -2;		/* A assinatura da shared memory e invalida */

	for( int idx = 0; idx < mem_ptr->lastindex; idx ++ )
	{
		shm_mbox_header *mb = get_mbox_index_header( idx, mem_ptr );

		if ( mb->msqid >= 0 )
		{		
			if( mb->signature != MAILBOX_SIGNATURE )
				return -3;

			if ( msgctl(mb->msqid,IPC_STAT,&buf) == -1 )
				return -1;
			
			fprintf(stdout,"msqid[%d] mbid[%04d] %s %d bytes in %d messages. Last Access => Read [%d:%s] Write [%d:%s]\n",
					mb->msqid, mb->mbid, mb->mbname, buf.msg_cbytes, buf.msg_qnum,
					buf.msg_lrpid, ctime(&buf.msg_rtime), buf.msg_lspid, ctime(&buf.msg_stime));
		}
		
	}
	return (0);
/*
	printf("id da fila de mensagens     : %d\n",msqid) ;
    printf("id do proprietario          : %d\n",buf.msg_perm.uid) ;
    printf("id do grupo do proprietario : %d\n",buf.msg_perm.gid) ;
    printf("id do criador               : %d\n",buf.msg_perm.cuid) ;
    printf("id do grupo do criador      : %d\n",buf.msg_perm.cgid) ;
    printf("direitos de acesso          : %d\n",buf.msg_perm.mode) ;
    printf("nb atual de bytes na fila   : %d\n",buf.msg_cbytes) ;
    printf("nb de mensagens na fila     : %d\n",buf.msg_qnum) ;
    printf("nb maximal de bytes na fila : %d\n",buf.msg_qbytes) ;
    printf("pid do ultimo escritor      : %d\n",buf.msg_lspid) ;
    printf("pid do ultimo leitor        : %d\n",buf.msg_lrpid) ;
    printf("data da ultima escrita      : %s\n",ctime(&buf.msg_stime)) ;
    printf("data da ultima leitura      : %s\n",ctime(&buf.msg_rtime)) ;
    printf("data da ultima modificacao  : %s\n",ctime(&buf.msg_ctime)) ;
*/
}

shm_mbox_header *get_mbox_index_header( unsigned short index, shm_mbox_system_header *ptr )
{
	shm_mbox_header *ptr_to_first_header;

	assert( ptr != NULL );

	ptr_to_first_header = (shm_mbox_header *) ((char*)ptr + sizeof(shm_mbox_system_header));
	shm_mbox_header *ret = (shm_mbox_header *) ((char*)ptr_to_first_header + ptr->buff_len * index);

	/* fprintf(stdout,"%d.%d=> %ld\n", index, ptr->buff_len, (int) ((char *)ret - (char *)ptr)); */

	return ret;
}

size_t get_total_shm_len( void )
{
	size_t len = sizeof( shm_mbox_system_header );
	len += sizeof( shm_mbox_header ) * get_shm_buff_qty();

	return len;
}

size_t get_shm_buff_len( void )
{
    return sizeof(shm_mbox_header);
}

size_t get_shm_buff_qty( void )
{
    int buff_qty;
    cf_locatenum(PRODUCT_KEY_MAX_MB,&buff_qty);
	return (size_t)buff_qty;
}

int mbox_get_shm_id()
{
	return(shmget(get_shm_mbox_key(),sizeof( shm_mbox_system_header ), 0 ));
}

int mbox_get_semaphore_id()
{
	return semget( get_shm_mbox_key(), 1, S_IRUSR | S_IWUSR );
}

int mbox_remove_shm()
{
	return(shmctl(mbox_get_shm_id(),IPC_RMID, NULL));
}

int mbox_remove_semaphore()
{
	return(semctl(mbox_get_semaphore_id(),0,IPC_RMID,0));
}

int  mbox_remove_queues()
{
	struct shmid_ds stat_buf ;
	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();
	
	if( mem_ptr == (void*)-1 )
		return -4;		/* Nao foi possivel anexar a shared memory */

	if( mem_ptr->signature != MAILBOX_HEADER_SIGNATURE )
		return -2;		/* A assinatura da shared memory e invalida */

	for( int idx = 0; idx < mem_ptr->lastindex; idx ++ )
	{
		shm_mbox_header *mb = get_mbox_index_header( idx, mem_ptr );

		if( mb->msqid >= 0 ) /* Remove only Active Queues */
		{
			msgctl(mb->msqid,IPC_RMID, NULL);
			debug_log(mbox_debug_fp,"Queue Remove[%d:%s] => Status [%d]\n",mb->msqid,mb->mbname,errno);
		}
	}
	return(0);
}

int mbox_create( char *mboxname )
{
	int mqsid = -1;
	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();

	if ( mem_ptr->lastindex >= mem_ptr->buff_qty )
	{
		debug_log(mbox_debug_fp,"Too many mailboxes. Mailbox %s not created\n",mboxname);
		return -1;
	}

	/* Create Queue */
	int msgflg = IPC_CREAT | 0666;
	register key_t key = get_shm_private_mbox_key( mem_ptr->lastindex );

	/* fprintf(stderr,"Private Key 0x%x\n", key); */

	if(( mqsid = msgget(key, msgflg )) < 0)
	{
		debug_log(mbox_debug_fp,"Queue Name [%s] could not be created => Status [%d]\n",mboxname,errno);
		return -1;
	}
	/* fprintf(stderr,"mqsid=[%d],lastindex[%d] semaphore[%d] shmid[%d]\n",mqsid,mem_ptr->lastindex,mem_ptr->semid,mem_ptr->shmid); */
	
	if( sem_P(mem_ptr->semid) != 0 )  /* P Operation */
	{ 
		debug_log(mbox_debug_fp,"Mbox [%s] will be deleted. Semaphore error => Status [%d]\n",mboxname,errno);
		if( msgctl(mqsid,IPC_RMID, NULL) < 0);
			debug_log(mbox_debug_fp,"Queue Name [%s] could not be deleted => Status [%d]\n",mboxname,errno);
		return -2; 		
	}

	/* Update SHM */
	shm_mbox_header *mb = get_mbox_index_header( mem_ptr->lastindex, mem_ptr );
	mb->msqid = mqsid;
    mb->mbid = mem_ptr->lastindex;
	strcpy(mb->mbname,mboxname);
	mem_ptr->lastindex++;

	/* fprintf(stderr,"%d %s %d %d\n",mb->msqid,mb->mbname,mb->mbid,mem_ptr->lastindex); */

	if( sem_V(mem_ptr->semid) != 0 )	/* V Operation */
	{
		return -5;
	}
	return( mb->mbid );   /* Return MB ID */
}


int mbox_write( int mbid, char *msg, size_t msglen )
{
	int mqsid = -1;
	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();

	shm_mbox_header *mb = get_mbox_index_header( mbid, mem_ptr );

	if(mb->mqsid < 0)
		return -1;

	sbuf.text = msg;

	if ((msgsnd_rc = msgsnd(mb->mqsid, &sbuf, msglen, IPC_NOWAIT)) < 0)
	{
		fprintf(stderr,"E-%s-006 msgsnd error [%d]\n", PRODUCT_ALIAS, msgsnd_rc );
		return(-2);
    }
	return (0);
}

int mbox_get_active_pid()
{
	struct shmid_ds stat_buf ;
	
	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();

	if( mem_ptr == (void*)-1 )
		return -4;		/* Nao foi possivel anexar a shared memory */

	if( mem_ptr->signature != MAILBOX_HEADER_SIGNATURE )
		return -2;		/* A assinatura da shared memory e invalida */

	return(mem_ptr->pid);
}

key_t get_shm_mbox_key( void )
{
	register key_t key = MAILBOX_BASE_KEY;

	if (!getenv(PRODUCT_SHM_VAR))
		return 0;

	register int region = atoi(getenv(PRODUCT_SHM_VAR)) % 256;
	key += region;
	key += region << 8;
	key += region << 16;
	key += region << 24;

	return key;
}

key_t get_shm_private_mbox_key( int idx )
{
	register key_t key = MAILBOX_BASE_KEY;

	if (!getenv(PRODUCT_SHM_VAR))
		return 0;

	register int region = atoi(getenv(PRODUCT_SHM_VAR)) % 256;
	key += region;
	key += region << 8;
	key += region << 16;
	key += region << 24;
	key += idx;

	return key;
}
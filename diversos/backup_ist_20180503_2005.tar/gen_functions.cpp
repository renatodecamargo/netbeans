#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/errno.h>
#include <sys/errno.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/stat.h>
#include <assert.h>
#include <string>

std::string DumpHex(const char *title, const void* data, size_t size)
{
	char line[1024] = {0};
	std::string result;
	char ascii[17];
	size_t i, j;
	ascii[16] = '\0';
	sprintf(line,"%s (%d bytes) :\n", title, size);
	result = line;
	for (i = 0; i < size; ++i) {
		sprintf(line,"%02X ", ((unsigned char*)data)[i]);
		result += line;
		if (((unsigned char*)data)[i] >= ' ' && ((unsigned char*)data)[i] <= '~') {
			ascii[i % 16] = ((unsigned char*)data)[i];
		} else {
			ascii[i % 16] = '.';
		}
		if ((i+1) % 8 == 0 || i+1 == size) {
			sprintf(line, " ");
			result += line;
			if ((i+1) % 16 == 0) {
				sprintf(line,"|  %s \n", ascii);
				result += line;
			} else if (i+1 == size) {
				ascii[(i+1) % 16] = '\0';
				if ((i+1) % 16 <= 8) {
					sprintf(line," ");
					result += line;
				}
				for (j = (i+1) % 16; j < 16; ++j) {
					sprintf(line,"   ");
					result += line;
				}
				sprintf(line,"|  %s \n", ascii);
				result += line;
			}
		}
	}
	return result;
}

std::string get_formatted_timestamp(time_t rawtime)
{
	char timestamp[32] = {0};
	struct tm * timeinfo;
	std::string result;

  	timeinfo = localtime (&rawtime);
  	strftime(timestamp,sizeof(timestamp),"%Y-%m-%d %H:%M:%S", timeinfo);
	result = timestamp;
	
  	return( result );
}


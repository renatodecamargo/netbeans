#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdarg.h>
#include <string>

#include "ist_functions.h"
#include "gen_functions.h"
#include "ports.h"
#include "win32.h"

static char module_name[MAX_IST_STRING] = "portmngr";

using namespace std;

int log_port( int portid, const char * format, ... )
{
	char buffer[MAX_IST_STRING] = {0};
	char timestamp[32] = {0};
	time_t rawtime;
	struct tm * timeinfo;
	
	time (&rawtime);
	timeinfo = localtime (&rawtime);
	strftime(timestamp,sizeof(timestamp),"%Y-%m-%d %H:%M:%S", timeinfo);
		
	if( PORTS[portid].port_status_log == OPENED_LOG ) {
		va_list args;
		va_start (args, format);
		vsprintf(buffer, format, args);
		fprintf(PORTS[portid].port_log_fp,"%s [%d] %s", timestamp, PORTS[portid].pid, buffer);
		fflush(PORTS[portid].port_log_fp);
		return 0;
	}
	return -1;
}

int port_init( void )
{
	char cfg_key[MAX_IST_STRING] = {0};
	int  maxports;
	
	cf_open("istparam.cfg");
	cf_locatenum("config.maxports", &maxports);
	cf_locate("config.masterlog",syslg_log);
	
	/* Try to Connect on SYSLG */
	if(( syslg_fp = fopen(syslg_log,"a+t")) == NULL ) {
		fprintf(stderr,"Unable to open log %s\n",syslg_log);
		return(-1);
	}	
	
	/* Reading Port Configurations */
	for ( int port_index = 1; port_index <= maxports; port_index++) {
		/* ISTPARAM Parameters */
		
		sprintf(cfg_key,"port_%d.name",port_index);
		get_char_param(cfg_key,PORTS[PORT_ID].port_name);

		sprintf(cfg_key,"port_%d.label",port_index);
		get_char_param(cfg_key,PORTS[PORT_ID].port_label);
		
		sprintf(cfg_key,"port_%d.type",port_index);
		get_char_param(cfg_key,PORTS[PORT_ID].port_type);
		
		sprintf(cfg_key,"port_%d.ip",port_index);
		get_char_param(cfg_key,PORTS[PORT_ID].port_ip);
		
		sprintf(cfg_key,"port_%d.number",port_index);
		get_int_param( cfg_key, &PORTS[PORT_ID].port_number );

		sprintf(cfg_key,"port_%d.format",port_index);
		get_char_param(cfg_key,PORTS[PORT_ID].port_format);

		sprintf(cfg_key,"port_%d.headerlen",port_index);
		get_int_param( cfg_key, &PORTS[PORT_ID].port_headerlen );

		sprintf(cfg_key,"port_%d.headertype",port_index);
		get_int_param( cfg_key, &PORTS[PORT_ID].port_headertype );
		
		sprintf(cfg_key,"port_%d.tpdu",port_index);
		get_int_param( cfg_key, &PORTS[PORT_ID].port_tpdu );

		sprintf(cfg_key,"port_%d.multi",port_index);
		get_int_param( cfg_key, &PORTS[PORT_ID].port_multi );

		sprintf(cfg_key,"port_%d.method",port_index);
		get_char_param(cfg_key,PORTS[PORT_ID].port_method);

		sprintf(cfg_key,"port_%d.methodparam",port_index);
		get_char_param(cfg_key,PORTS[PORT_ID].port_methodparam);

		sprintf(cfg_key,"port_%d.log",port_index);
		get_char_param(cfg_key,PORTS[PORT_ID].port_log);
		
		if(( PORTS[PORT_ID].port_log_fp = fopen(PORTS[PORT_ID].port_log,"a+t")) == NULL ) {
			fprintf(stderr,"Unable to open log %s\n",PORTS[PORT_ID].port_log);
			PORTS[PORT_ID].port_status_log = CLOSED_LOG;
		} else
		{
			PORTS[PORT_ID].port_status_log = OPENED_LOG;
		}
		
		PORT_ID++;
	}
	
	cf_close();
	
	return(0);
}

int handle_message( int portid, char *message_req, size_t size_req, char *message_resp, size_t * size_resp  )
{
	int iPacketSize;
	
    switch ( PORTS[portid].len_type ) 
	{
        case LEN_TYPE_NONE:
            iPacketSize = (WORD)size_req;
            break;
        case LEN_TYPE_4BIN:
        case LEN_TYPE_2BIN:
            iPacketSize = (WORD)(((BYTE)message_req[0] * 256) + (BYTE)message_req[1]);
            break;
        case LEN_TYPE_4ASC: {
				char szAux[5] = {0};
				CopyMemory ( szAux, message_req, 4 );
				iPacketSize = strtoul ( szAux, NULL, 10 );
			}
			break;
    }
	
	//int msgtype = get_msgtype( portid, message_req, iPacketSize );
			   
	strcpy( message_resp, message_req );
	*size_resp = size_req; 
}

int handle_connection( int portid )
{
	char tcp_data_req[MAX_IST_STRING*8] = {0};
	char tcp_data_resp[MAX_IST_STRING*8] = {0};
	size_t read_len = 0, resp_len = 0;
	fd_set read_sd;
	
	PORTS[portid].pid = getpid();
	
	log_port( portid, "PID[%d] Name[%s] Port[%d] ...\n", getpid(), PORTS[portid].issuer_name, PORTS[portid].port_number );
	getsockname( PORTS[portid].server_sockfd, (struct sockaddr *)&PORTS[portid].serv_addr, &PORTS[portid].addrlen);
	log_port( portid, "Local IP address is: %s\n", inet_ntoa(PORTS[portid].serv_addr.sin_addr));
	log_port( portid, "Local port is: %d\n", (int) ntohs(PORTS[portid].serv_addr.sin_port));
		
	for(;;) {
		log_port( portid, "Waiting for new connection [%s:%d]...\n",PORTS[portid].issuer_name,ntohs(PORTS[portid].serv_addr.sin_port));
		PORTS[portid].client_sockfd = accept(PORTS[portid].server_sockfd,(struct sockaddr*)&PORTS[portid].client_addr, &PORTS[portid].addrlen);
		
		getsockname( PORTS[portid].client_sockfd, (struct sockaddr *)&PORTS[portid].client_addr, &PORTS[portid].addrlen);
		log_port( portid, "Handling connection from [%s] [%d]\n", inet_ntoa(PORTS[portid].client_addr.sin_addr), PORTS[portid].client_sockfd);
		
		bzero(tcp_data_req,sizeof(tcp_data_req));
		
		while( true )
		{
			FD_ZERO(&read_sd);
			FD_SET(PORTS[portid].client_sockfd, &read_sd);
	
			int sel = select(PORTS[portid].client_sockfd + 1, &read_sd, 0, 0, 0);

			if (sel > 0) {
				PORTS[portid].status = CONNECTED_STATUS;
				read_len = recv(PORTS[portid].client_sockfd, tcp_data_req, sizeof(tcp_data_req), 0);
				if (read_len > 0) {
					log_port( portid, "%s", DumpHex("Received ", tcp_data_req,read_len).c_str());
					
					handle_message( portid, tcp_data_req, read_len, tcp_data_resp, &resp_len );
				
					if (resp_len) {
						log_port( portid, "%s", DumpHex("Sent ", tcp_data_req,read_len).c_str());
						write( PORTS[portid].port_client_sockfd, tcp_data_resp, resp_len );
					}
				
					bzero(tcp_data_req,sizeof(tcp_data_req));
					bzero(tcp_data_resp,sizeof(tcp_data_resp));
					
				} else if ( read_len == 0 ) {
					break;
				} else {
					break;
				}  
			} else if ( sel < 0) {
				break;
			}
		}
		close(PORTS[portid].port_client_sockfd);
		log_port( portid, "Connection Closed\n" );
		PORTS[portid].status = DISCONNECTED_STATUS;
	}
	close(PORTS[portid].server_sockfd);
}

int main(int argc, char *argv[]) 
{
	syslg_arg0(module_name);
	
	if( port_init() < 0 )
	{
		syslg("E-%s-001 *** PORT MANAGER INITIALIZATION ERROR ***", module_name );
		exit(1);
	}
	
	for ( int port_index = 0; port_index < PORT_ID; port_index++ )
	{
		syslg("Trying to estabelish a socket on port [%s:%d]",PORTS[port_index].port_ip, PORTS[port_index].port_number);
		
		if( !strcmp(PORTS[port_index].port_type,"in" ))
		{
			/* Create a port on a Listening Mode */
			PORTS[port_index].port_server_sockfd = socket(AF_INET, SOCK_STREAM, 0);
			if (PORTS[port_index].port_server_sockfd < 0) 
				syslg("E-%s-002 ERROR opening socket", module_name );
			
			bzero((char *) &PORTS[port_index].port_serv_addr, sizeof(PORTS[port_index].port_serv_addr));
			PORTS[port_index].port_serv_addr.sin_family = AF_INET;
			PORTS[port_index].port_serv_addr.sin_addr.s_addr = INADDR_ANY;
			PORTS[port_index].port_serv_addr.sin_port = htons(PORTS[port_index].port_number);
			
			if (bind(PORTS[port_index].port_server_sockfd, (struct sockaddr *) &PORTS[port_index].port_serv_addr, sizeof(PORTS[port_index].port_serv_addr)) < 0) 
				syslg("E-%s-003 Failed ERROR on binding", module_name);
			
			listen(PORTS[port_index].port_server_sockfd,1);
			
			pid_t pid = fork();
			
			if ( pid == 0 ) {
				handle_connection( port_index );
			} else if ( pid > 0 ) {
				// Everything Ok
				continue;
			} else {
				syslg("E-%s-003 Failed to fork Port %s on [%s:%d]\n", module_name, PORTS[port_index].port_name,PORTS[port_index].port_ip, PORTS[port_index].port_number);
			}
		}
	}
	
	for (;;) {
		fprintf(stdout,"Port Status\n========================================================================================================================================================\n");
		for ( int port_index = 0; port_index < PORT_ID; port_index++)
		{
			if( PORTS[port_index].port_name[0] )
				fprintf(stdout,"  %s : Port [%s:%d]  Status[%d]  LogStatus [%d] Log [%s]  PID[%d]\n", PORTS[port_index].port_name,PORTS[port_index].port_ip, PORTS[port_index].port_number,PORTS[PORTS[port_index].port_name].port_status,PORTS[port_index].port_status_log, PORTS[port_index].port_log, PORTS[port_index].pid );
		}
		fprintf(stdout,"========================================================================================================================================================\n");
		sleep(5);
	}

	exit(0);
}
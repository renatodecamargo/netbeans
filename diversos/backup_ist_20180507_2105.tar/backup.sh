tar -mpcf "/home4/renatod1/src/backup/backup_ist_`date "+%Y%m%d_%H%M"`.tar" *.cpp *.h cfg/lswparam.cfg makefile *.sh
ls -l /home4/renatod1/src/backup/backup_ist_*

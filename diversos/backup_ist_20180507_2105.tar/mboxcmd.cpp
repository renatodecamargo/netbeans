/* TODO LIST */

/*
[~/src/c/ist]mboxcmd -v delete
mboxcmd r1.0 compiled at May  6 2018 08:48:18
=======================================================================

[~/src/c/ist]mboxcmd -v mbox1
mboxcmd r1.0 compiled at May  6 2018 09:04:14
=======================================================================

%s [-start] [-stop] [-init] [-release] [-list <mbid|mbname>] [-create <mbid|mbname>] [-clear <mbid|mbname>] [-view <info|key|mb|queued|lock|deleted|all>]
[-lock <mbid|mbname>] [-unlock <mbid|mbname>] [-read <mbid|mbname>] [-send <mbid|mbname> <msgdata>]
[-delete <mbid|mbname>] [-detail <mbid|mbname>]
[-addaction <mbid|mbname> <level> <command>] [-removeaction <mbid|mbname>]

[ addaction 

				SetCmdParam( "emoveaction", REMOVE_ACTION);
				SetCmdParam( "ddaction", ADD_ACTION_FUNCTION);
				SetCmdParam( "iewkey", KEY_FUNCTION);
				SetCmdParam( "iewinfo", MON_FUNCTION);
				SetCmdParam( "iewmb", DEEP_FUNCTION);
				SetCmdParam( "iewlock", SEE_LOCK_FUNCTION);
				SetCmdParam( "iewdeleted", SEE_DELETED_FUNCTION);
				SetCmdParam( "iewall", ALL_FUNCTION);
*/


#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/stat.h>
#include <assert.h>
#include <signal.h>
#include <errno.h>
#include <string>
#include <libgen.h>

#include "syslg.h"
#include "mailbox.h"
#include "ist_functions.h"
#include "misc_functions.h"
#include "gen_functions.h"

#define MODULE_VERSION  "r1.0"
#define MODULE_NAME  "mboxcmd"

#define SetCmdParam( command, function )   if(!strcmp(mboxfunction_param,command)) mboxfunction = function;

enum {
	/* Stop Start */
	NONE_FUNCTION = 0,
	START_FUNCTION,
	STOP_FUNCTION,
	RELEASE_FUNCTION,
	
	/* Monitor Functions */
	MON_FUNCTION,
    DEEP_FUNCTION,
	QUEUED_FUNCTION,
	SEE_LOCK_FUNCTION,
	SEE_DELETED_FUNCTION,
	MB_DETAIL_FUNCTION,
	KEY_FUNCTION,
	ALL_FUNCTION,

	/* Action Functions */
    CREATE_FUNCTION,
    DELETE_FUNCTION,
	LOCK_FUNCTION,
	UNLOCK_FUNCTION,
	SEND_MSG_FUNCTION,
    READ_MSG_FUNCTION,
    CLEAR_QUEUE_FUNCTION,
    CLEAR_STAT_FUNCTION,
	ADD_ACTION_FUNCTION,
	REMOVE_ACTION
};

static shm_mbox_system_header *shm = NULL;
static int mboxfunction = NONE_FUNCTION;
char *mboxfunction_param = NULL;
char *mbox_param1 = NULL;
char *mbox_param2 = NULL;
char *mbox_param3 = NULL;

void signal_handler(int signo)
{
	int rc;
	char msg[MAX_IST_STRING] = {0};

	/* Send Message do Debug Info */
	sprintf(msg,"Signal Received [%d]",signo );
	debug_log( mbox_debug_fp, "%s\n", msg );
	syslg("%s\n",msg);

	/* Remove Queue */
	if ((rc = mbox_remove_queues()) < 0)
		debug_log( mbox_debug_fp, "Message queues could not be deleted [%d]. Errno [%d]\n", rc, errno );	

	/* Remove SHM */
	if ((rc = mbox_remove_shm()) < 0)
		debug_log( mbox_debug_fp, "SHM could not be deleted [%d]. Errno [%d]\n", rc, errno );

	/* Remove SHM */
	if ((rc = mbox_remove_semaphore()) < 0)
		debug_log( mbox_debug_fp, "Semaphore could not be deleted [%d]. Errno [%d]\n", rc, errno );

	/* Close files */
	fclose(mbox_debug_fp);

	/* Exit with signal received */
	exit(signo);
}

int mbox_handler( void )
{
	char debugname[MAX_IST_STRING] = {0};
    int msqid, semid, shmid;
    int maxmbox = 0;

	/* Get SHM Header */
	shm = get_mbox_shm_stat ();
	if( shm != NULL ) {
		fprintf(stderr,"E-%s-012 Mbox already started with PID [%d]\n", PRODUCT_ALIAS, shm->pid );
		exit(1);
	}

	/* Get Parameters */
	cf_locate(PRODUCT_KEY_MASTERDIRDEBUG,debugname);
	sprintf(debugname,"%s/%s.debug",debugname,MODULE_NAME);
	/*fprintf(stdout,"==>[%s]",PRODUCT_KEY_MAX_MB);*/
    cf_locatenum(PRODUCT_KEY_MAX_MB,&maxmbox);
	debug_log(mbox_debug_fp,"Current %s Max Number of Mbox : [%d]\n", PRODUCT_ALIAS, maxmbox);
	fprintf(stdout,"Current %s Max Number of Mbox : [%d]\n", PRODUCT_ALIAS, maxmbox);

	if((shmid = mbox_shm_create_memory( &shm )) < 0 )
	{
		fprintf(stderr,"E-%s-013 Cannot create SHM. Check user permission\n", PRODUCT_ALIAS );
		exit(1);
	}

	if(( semid = mbox_shm_create_semaphore()) < 0 )
	{
		fprintf(stderr,"E-%s-014 Cannot create semaphore. Check user permission\n", PRODUCT_ALIAS );
		exit(1);
	}

	shm->semid = semid;
	shm->shmid = shmid;

	mbox_shm_format_memory(shm);

	if( mbox_shm_init_semaphore( semid ) < 0 ) {
		fprintf(stderr,"E-%s-015 Cannot initialize semaphore. Check user permission\n", PRODUCT_ALIAS );
		exit(1);
	}

	/* Open Debug file */
	if(( mbox_debug_fp = fopen(debugname,"a+t")) == NULL ) {
		fprintf(stderr,"E-%s-012 Unable to open debug [%s]\n", PRODUCT_ALIAS, debugname );
     	exit(1);
	}

	/* Send Some Messages do Debug and Log */
	debug_log(mbox_debug_fp,"Current %s Mbox Key: [0x%x]\n", PRODUCT_ALIAS, get_shm_mbox_key());
	fprintf(stdout,"Current %s Mbox Key: [0x%x]\n", PRODUCT_ALIAS, get_shm_mbox_key());
	debug_log(mbox_debug_fp,"catch_all_signals[%d]\n", catch_all_signals(&signal_handler));
    syslg("Mbox System Started\n");
	debug_log(mbox_debug_fp, "Mbox System Started\n");

	for( ;; )
	{
        sleep(5);
        debug_log(mbox_debug_fp,"Mbox System alive\n");
		mbox_shm_get_queue_stat();
	}
}

int usage( char *progname )
{
	char msg[]= { "usage: %s [-s <message>] [-c <mailboxname>] [-d <mailboxname>] [-v <key|info|all>] [-i] [-f]\n-s   Send mbox message\n-v   View => key, info or depth\n-c   Create mox\n-d   Delete mbox\n-a   Action => start, init, stop, finish, release, clearq, clears>\n-i   Initialize Mbox process\n-f   Finish Mbox process\n-r   Release Mbox Resources\n" };
	fprintf( stderr, msg, progname );
	return(1);
}

int parse_options( int argc, char *argv[] )
{
	int opt;
	char *msg;
	opterr = 0;

	if( argc == 1 ) return -1;

	while ( (opt = getopt(argc, argv, "a:l:u:r:s:i:c:v:d:")) != -1 )
	{
		switch ( opt )
		{
			case 'a':
				if( optarg == NULL ) return -1;
				mboxfunction_param = optarg;
				SetCmdParam( "ddaction", ADD_ACTION_FUNCTION);
				if( mboxfunction == -1 ) return(-1);				
				break;

			case 'r':
            	if( optarg == NULL ) return -1;
				mboxfunction_param = optarg;
				SetCmdParam( "ead", READ_MSG_FUNCTION);
				SetCmdParam( "elease", RELEASE_FUNCTION);
				SetCmdParam( "emoveaction", REMOVE_ACTION);
				if( mboxfunction == -1 ) return(-1);				
				break;

			case 's':
            	if( optarg == NULL ) return -1;
				mboxfunction_param = optarg;
				SetCmdParam( "tart", START_FUNCTION);
				SetCmdParam( "top", STOP_FUNCTION);
				SetCmdParam( "end", SEND_MSG_FUNCTION);				
				if( mboxfunction == -1 ) return(-1);				
				break;
			
            case 'i':
            	if( optarg == NULL ) return -1;
				mboxfunction_param = optarg;
				SetCmdParam( "nit", START_FUNCTION);
				if( mboxfunction == -1 ) return(-1);				
				break;

            case 'd':
            	if( optarg == NULL ) return -1;
				mboxfunction_param = optarg;
				SetCmdParam( "etail", MB_DETAIL_FUNCTION);
				SetCmdParam( "elete", DELETE_FUNCTION);
				if( mboxfunction == -1 ) return(-1);				
				break;

            case 'l':
            	if( optarg == NULL ) return -1;
				mboxfunction_param = optarg;
				SetCmdParam( "ock", LOCK_FUNCTION);
				SetCmdParam( "ist", DEEP_FUNCTION);
				if( mboxfunction == -1 ) return(-1);				
				break;

            case 'u':
            	if( optarg == NULL ) return -1;
				mboxfunction_param = optarg;
				SetCmdParam( "nlock", UNLOCK_FUNCTION);
				if( mboxfunction == -1 ) return(-1);				
				break;										

			case 'c':
            	if( optarg == NULL ) return -1;
				mboxfunction_param = optarg;
				SetCmdParam( "reate", CREATE_FUNCTION);
				SetCmdParam( "lear", CLEAR_QUEUE_FUNCTION);
				if( mboxfunction == -1 ) return(-1);				
                break;

			case 'v':
				if( optarg == NULL ) return -1;
				mboxfunction_param = optarg;

				SetCmdParam( "key", KEY_FUNCTION);
				SetCmdParam( "info", MON_FUNCTION);
				SetCmdParam( "mb", DEEP_FUNCTION);
				SetCmdParam( "queued", QUEUED_FUNCTION);
				SetCmdParam( "lock", SEE_LOCK_FUNCTION);
				SetCmdParam( "deleted", SEE_DELETED_FUNCTION);
				
				SetCmdParam( "all", ALL_FUNCTION);

				SetCmdParam( "iewkey", KEY_FUNCTION);
				SetCmdParam( "iewinfo", MON_FUNCTION);
				SetCmdParam( "iewmb", DEEP_FUNCTION);
				SetCmdParam( "iewlock", SEE_LOCK_FUNCTION);
				SetCmdParam( "iewdeleted", SEE_DELETED_FUNCTION);
				SetCmdParam( "iewall", ALL_FUNCTION);

				if( mboxfunction == -1 ) return(-1);
				break;

			case '?':
				return(-2);
		}
	}
	

	int indiceArg = optind;
	mbox_param1 = argv[indiceArg++];
	mbox_param2 = argv[indiceArg++];
	mbox_param3 = argv[indiceArg++];
/*
	if(( mboxfunction == SEND_MSG_FUNCTION || mboxfunction == READ_MSG_FUNCTION ) && ( mboxid_param == NULL))
		return -2;
*/

	return(0);
}

int mbox_start( void )
{
	pid_t mbox_handle = fork();

	if( mbox_handle == 0 )
		mbox_handler();
	else
	{
		fprintf(stdout,"Current %s MBOX Handler : [%d]\n", PRODUCT_ALIAS, mbox_handle );
	}
	return(0);
}

int mbox_stop( void )
{
	int pid = -1;
	
	if(( pid = mbox_get_active_pid()) >= 0 )   /* Try to Kill Process */
		kill(pid,SIGTERM);

	exit(0);
}

int mbox_release()
{
	int releaseRespCode = 0;

	/* Send Message do Debug Info */
	syslg( "Releasing Resources... Need to restart Mbox again\n" );

	/* Remove Queue */
	if ((releaseRespCode = mbox_remove_queues()) < 0)
		syslg( "Message queues could not be deleted [%d]. Errno [%d]\n", releaseRespCode, errno );	

	/* Remove SHM */
	if ((releaseRespCode = mbox_remove_shm()) < 0)
		syslg( "SHM could not be deleted [%d]. Errno [%d]\n", releaseRespCode, errno );

	/* Remove SHM */
	if ((releaseRespCode = mbox_remove_semaphore()) < 0)
		syslg( "Semaphore could not be deleted [%d]. Errno [%d]\n", releaseRespCode, errno );

	exit(0);
}

int mbox_view_mon() {
	mbox_shm_show_memory();
}

int mbox_view_key() {
	fprintf(stdout,"Current %s Mbox Key: [0x%x]\n", PRODUCT_ALIAS, get_shm_mbox_key());
	return(0);
}

int mbox_deleted_mon()
{
	mbox_shm_show_queues(MAILBOX_DELETED);
}

int mbox_lock_mon()
{
	mbox_shm_show_queues(MAILBOX_LOCKED);
}

int mbox_queued_mon()
{
	mbox_shm_show_queues(MAILBOX_QUEUED);
}

int mbox_runtime_create()
{
	int rc;
	syslg_arg0(MODULE_NAME);

	if(( rc = mbox_create(mbox_param1)) < 0 )
	{
		syslg( "Mbox Create Error [%s]. [%d] Errno [%d]\n", mbox_param1, rc, errno );
		fprintf(stderr,"E-%s-012 Mbox Create Error [%s]. [%d] Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, rc, errno );
		exit(1);
	}
	syslg("Mbox [%s] sucessfuly created. MboxID [%d]\n",  mbox_param1, rc );
	fprintf(stderr,"Mbox [%s] sucessfuly created. MboxID [%d]\n",  mbox_param1, rc );
	exit(0);
}

int GetMailBox()
{
	int mailboxID = -1;

	if( mbox_param1 == NULL)
		return (-1);
	if ( isNumeric(mbox_param1))
		mailboxID = atol(mbox_param1);
	else {
		if(( mailboxID = mbox_locate(mbox_param1)) < 0 )
		{
			return(-1);
		}	
	}
}

int mbox_depth_mon()
{
	int detailRespCode = -1;
	int mailboxID = -1;

	if( mbox_param1 != NULL ) {
		if(( mailboxID = GetMailBox()) < 0 )
		{
			fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
			debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
			exit(1);
		}
		fprintf(stdout, "Get Detailed Information about Mbox %d\n", mailboxID);

		if(( detailRespCode = mbox_info( mailboxID )) < 0)
		{
			fprintf(stderr,"E-%s-006 mbox_info error [%d]. Errno [%d]\n", PRODUCT_ALIAS, detailRespCode, errno );
			debug_log(syslg_debug_fp,"E-%s-006 mbox_info error [%d]. Errno [%d]\n", PRODUCT_ALIAS, detailRespCode, errno );
			exit(1);
		}	
	}
	else
	{
		mbox_shm_show_queues(MAILBOX_INUSE);
	}
}

int mbox_send_msg()
{
	int sendRespCode = 0;
	int mailboxID = -1;

	if(( mailboxID = GetMailBox()) < 0 )
	{
		fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		exit(1);
	}

	if ( mbox_param2 == NULL ) {
			fprintf(stderr,"E-%s-008 Message not setted\n", PRODUCT_ALIAS );
			debug_log(syslg_debug_fp,"E-%s-008 Message not setted\n", PRODUCT_ALIAS );
			exit(1);
	}

	fprintf(stdout, "Sending message [%s] to Mbox %d\n", mbox_param2, mailboxID);

	if(( sendRespCode = mbox_write(mailboxID,mbox_param2,strlen(mbox_param2))) < 0)
	{
		fprintf(stderr,"E-%s-006 mbox_write error [%d]. Errno [%d]\n", PRODUCT_ALIAS, sendRespCode, errno );
		debug_log(syslg_debug_fp,"E-%s-006 mbox_write error [%d]. Errno [%d]\n", PRODUCT_ALIAS, sendRespCode, errno );
		exit(1);
    }
	syslg("Message sucessfully sended to Mbox [%s]. MboxID [%d]\n",  mbox_param1, sendRespCode );
	fprintf(stderr,"Message sucessfully sended to Mbox [%s]. MboxID [%d]\n",  mbox_param1, sendRespCode );
 	exit(0);
}

int mbox_read_msg()
{
	int readLength = 0;
	int mailboxID = -1;
	shm_mbox_message mailboxBuffer = {0};

	if(( mailboxID = GetMailBox()) < 0 )
	{
		fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		exit(1);
	}

	if( mbox_has_messages( mailboxID ) == 0 )
	{
		fprintf(stderr,"E-%s-011 Mbox [%s] has no messages. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		debug_log(syslg_debug_fp,"E-%s-011 Mbox [%s] has no messages. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		exit(1);
	}

	fprintf(stdout, "Reading a message from Mbox %d\n", mailboxID);

	if(( readLength = mbox_read( mailboxID, (char *)&mailboxBuffer.messageBuffer, sizeof(mailboxBuffer.messageBuffer) )) < 0)
	{
		fprintf(stderr,"E-%s-006 mbox_read error [%d]. Errno [%d]\n", PRODUCT_ALIAS, readLength, errno );
		debug_log(syslg_debug_fp,"E-%s-006 mbox_read error [%d]. Errno [%d]\n", PRODUCT_ALIAS, readLength, errno );
		exit(1);
    }
	syslg("Message sucessfully readed from Mbox [%s]\n",  mbox_param1 );
	fprintf(stderr,"Message sucessfully readed from Mbox [%s]\n",  mbox_param1 );
	fprintf(stderr,"%s\n",DumpHex("Read Buffer", (void*) &mailboxBuffer.messageBuffer, readLength).c_str());
 	exit(0);
}

int mbox_runtime_lock()
{
	int lockRespCode = 0;
	int mailboxID = -1;
	
	if(( mailboxID = GetMailBox()) < 0 )
	{
		fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		exit(1);
	}

	fprintf(stdout, "Locking Mbox %d\n", mailboxID);

	if(( lockRespCode = mbox_lock( mailboxID )) < 0)
	{
		fprintf(stderr,"E-%s-006 mbox_lock error [%d]. Errno [%d]\n", PRODUCT_ALIAS, lockRespCode, errno );
		debug_log(syslg_debug_fp,"E-%s-006 mbox_lock error [%d]. Errno [%d]\n", PRODUCT_ALIAS, lockRespCode, errno );
		exit(1);
    }
	syslg("Mbox sucessfully locked [%s]\n",  mbox_param1 );
	fprintf(stderr,"Mbox sucessfully locked [%s]\n",  mbox_param1 );
 	exit(0);
}

int mbox_runtime_unlock()
{
	int unlockRespCode = 0;
	int mailboxID = -1;
	
	if(( mailboxID = GetMailBox()) < 0 )
	{
		fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		exit(1);
	}

	fprintf(stdout, "Unlocking Mbox %d\n", mailboxID);

	if(( unlockRespCode = mbox_unlock( mailboxID )) < 0)
	{
		fprintf(stderr,"E-%s-006 mbox_unlock error [%d]. Errno [%d]\n", PRODUCT_ALIAS, unlockRespCode, errno );
		debug_log(syslg_debug_fp,"E-%s-006 mbox_unlock error [%d]. Errno [%d]\n", PRODUCT_ALIAS, unlockRespCode, errno );
		exit(1);
    }
	syslg("Mbox sucessfully unlocked [%s]\n",  mbox_param1 );
	fprintf(stderr,"Mbox sucessfully unlocked [%s]\n",  mbox_param1 );
 	exit(0);
}

int mbox_runtime_delete()
{
	int deleteRespCode = 0;
	int mailboxID = -1;
	
	if(( mailboxID = GetMailBox()) < 0 )
	{
		fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		exit(1);
	}

	fprintf(stdout, "Deleting Mbox %d\n", mailboxID);

	if(( deleteRespCode = mbox_delete( mailboxID )) < 0)
	{
		fprintf(stderr,"E-%s-006 mbox_deleted error [%d]. Errno [%d]\n", PRODUCT_ALIAS, deleteRespCode, errno );
		debug_log(syslg_debug_fp,"E-%s-006 mbox_deleted error [%d]. Errno [%d]\n", PRODUCT_ALIAS, deleteRespCode, errno );
		exit(1);
    }
	syslg("Mbox sucessfully deleted [%s]\n",  mbox_param1 );
	fprintf(stderr,"Mbox sucessfully deleted [%s]\n",  mbox_param1 );
 	exit(0);
}

int mbox_detail()
{
	int detailRespCode = 0;
	int mailboxID = -1;
	
	if(( mailboxID = GetMailBox()) < 0 )
	{
		fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		exit(1);
	}

	fprintf(stdout, "Get Detailed Information about Mbox %d\n", mailboxID);

	if(( detailRespCode = mbox_info( mailboxID )) < 0)
	{
		fprintf(stderr,"E-%s-006 mbox_info error [%d]. Errno [%d]\n", PRODUCT_ALIAS, detailRespCode, errno );
		debug_log(syslg_debug_fp,"E-%s-006 mbox_info error [%d]. Errno [%d]\n", PRODUCT_ALIAS, detailRespCode, errno );
		exit(1);
    }
 	exit(0);
}

int mbox_clear_queue_msg()
{
	int clearRespCode = 0;
	int mailboxID = -1;
	
	if(( mailboxID = GetMailBox()) < 0 )
	{
		fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		exit(1);
	}

	fprintf(stdout, "Clearing Mbox %d\n", mailboxID);

	if(( clearRespCode = mbox_clear_queue( mailboxID, MAILBOX_CLEAR_NO_SILENCE )) < 0)
	{
		fprintf(stderr,"E-%s-006 mbox_clear_queue error [%d]. Errno [%d]\n", PRODUCT_ALIAS, clearRespCode, errno );
		debug_log(syslg_debug_fp,"E-%s-006 mbox_clear_queue error [%d]. Errno [%d]\n", PRODUCT_ALIAS, clearRespCode, errno );
		exit(1);
    }
	syslg("Mbox sucessfully cleared [%s]\n",  mbox_param1 );
	fprintf(stderr,"Mbox sucessfully cleared [%s]\n",  mbox_param1 );
 	exit(0);
}

int mbox_runtime_remove_action()
{
	int removeRespCode = 0;
	int mailboxID = -1;

	if(( mailboxID = GetMailBox()) < 0 )
	{
		fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		exit(1);
	}

	fprintf(stdout, "Remove action from Mbox [%s]\n", mbox_param1);

	if(( removeRespCode = mbox_remove_action(mailboxID)) < 0)
	{
		fprintf(stderr,"E-%s-006 mbox_remove_action error [%d]. Errno [%d]\n", PRODUCT_ALIAS, removeRespCode, errno );
		debug_log(syslg_debug_fp,"E-%s-006 mbox_remove_action error [%d]. Errno [%d]\n", PRODUCT_ALIAS, removeRespCode, errno );
		exit(1);
    }
	syslg("Action removed from Mbox [%s]. MboxID [%d]\n",  mbox_param1, mailboxID );
	fprintf(stderr,"Action removed from Mbox [%s]. MboxID [%d]\n",  mbox_param1, mailboxID );
 	exit(0);
}

int mbox_runtime_add_action()
{
	int addRespCode = 0;
	int mailboxID = -1;
	int level = 0;

	if(( mailboxID = GetMailBox()) < 0 )
	{
		fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, mbox_param1, errno );
		exit(1);
	}

	if ( mbox_param2 == NULL ) {
			fprintf(stderr,"E-%s-008 Level not informed\n", PRODUCT_ALIAS );
			debug_log(syslg_debug_fp,"E-%s-008 Level not informed\n", PRODUCT_ALIAS );
			exit(1);
	} else {
		if ( isNumeric(mbox_param2))
			level = atol(mbox_param2);
		if ( level <= 0 )
		{
			fprintf(stderr,"E-%s-009 Level incorrect\n", PRODUCT_ALIAS );
			debug_log(syslg_debug_fp,"E-%s-00 Level incorrect\n", PRODUCT_ALIAS );
			exit(1);
		}
	}

	if ( mbox_param3 == NULL ) {
			fprintf(stderr,"E-%s-008 CommandLine not informed\n", PRODUCT_ALIAS );
			debug_log(syslg_debug_fp,"E-%s-008 CommandLine not informed\n", PRODUCT_ALIAS );
			exit(1);
	}

	fprintf(stdout, "Adding a action to Mbox [%s]\n", mbox_param2);

	if(( addRespCode = mbox_add_action(mailboxID,level,mbox_param3)) < 0)
	{
		fprintf(stderr,"E-%s-006 mbox_add_action error [%d]. Errno [%d]\n", PRODUCT_ALIAS, addRespCode, errno );
		debug_log(syslg_debug_fp,"E-%s-006 mbox_add_action error [%d]. Errno [%d]\n", PRODUCT_ALIAS, addRespCode, errno );
		exit(1);
    }
	syslg("Action added to Mbox [%s].\n",  mbox_param1 );
	fprintf(stderr,"Action added to Mbox [%s].\n",  mbox_param1 );
 	exit(0);
}

int mbox_clear_stat_msg()
{
    
}

int main(int argc, char *argv[])
{
	char* shmid;
	char* cfgname;
	char *progname;

	fprintf(stderr,"%s %s compiled at %s %s\n=======================================================================\n", MODULE_NAME,MODULE_VERSION,__DATE__,__TIME__);
	progname = basename( argv[0] );

	if( parse_options( argc, argv ) < 0)
		return usage(progname);

	shmid = getenv (PRODUCT_SHM_VAR);

	if (shmid == NULL) {
		fprintf(stderr,"E-%s-001 Variable %s not setted\n", PRODUCT_ALIAS, PRODUCT_SHM_VAR );
		exit(1);
	}

	cfgname = getenv (PRODUCT_CFG_VAR);

	if (cfgname == NULL) {
		fprintf(stderr,"E-%s-002 Variable %s not setted\n", PRODUCT_ALIAS, PRODUCT_CFG_VAR );
		exit(1);
	}

	if( cf_open( cfgname ) < 0 )
	{
		fprintf(stderr,"E-%s-003 Error to open Configuration File [%s]\n", PRODUCT_ALIAS, PRODUCT_CFG_VAR );
		exit(1);
	}

	syslg_arg0(MODULE_NAME);	

	switch ( mboxfunction )
	{
		case START_FUNCTION :
			mbox_start();
			mbox_view_key();
			fprintf(stdout,"Current %s Region : [%s]\n",PRODUCT_ALIAS, shmid);
			fprintf(stdout,"Current %s Configuration : [%s]\n",PRODUCT_ALIAS, cfgname);
			break;
			
		case STOP_FUNCTION :
			mbox_stop();
			break;

		case RELEASE_FUNCTION :
			mbox_release();
			break;			
			
		case MON_FUNCTION :
			mbox_view_mon();
			break;
			
		case KEY_FUNCTION :
			mbox_view_key();
			break;
			
		case ALL_FUNCTION :
			mbox_view_key();
			mbox_view_mon();
			break;

		case SEE_DELETED_FUNCTION :
			mbox_deleted_mon();
			break;

		case SEE_LOCK_FUNCTION :
			mbox_lock_mon();
			break;

		case QUEUED_FUNCTION :
			mbox_queued_mon();
			break;						

        case DEEP_FUNCTION :
            mbox_depth_mon();
            break;

    	case CREATE_FUNCTION :
            mbox_runtime_create();
            break;
		
		case SEND_MSG_FUNCTION :
            mbox_send_msg();
            break;

    	case READ_MSG_FUNCTION :
            mbox_read_msg();
            break;

		case LOCK_FUNCTION :
			mbox_runtime_lock();
			break;
		
		case UNLOCK_FUNCTION :
			mbox_runtime_unlock();
			break;

		case DELETE_FUNCTION :
			mbox_runtime_delete();
			break;

		case MB_DETAIL_FUNCTION :
			mbox_detail();
    
    	case CLEAR_QUEUE_FUNCTION :
            mbox_clear_queue_msg();
            break;

		case REMOVE_ACTION:
			mbox_runtime_remove_action();
			break;

		case ADD_ACTION_FUNCTION:
			mbox_runtime_add_action();
			break;

    	case CLEAR_STAT_FUNCTION :
            mbox_clear_stat_msg();
            break;
    }

	exit(0);
}
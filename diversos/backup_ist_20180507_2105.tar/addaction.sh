mboxcmd -stop
mboxcmd -start
mboxcmd -create actionbox
mboxcmd -create normalmbox
for a in {1..10}; do
    mboxcmd -send 0 "Mensagem 1" 
done
mboxcmd -addaction 0 10 /home4/renatod1/src/c/ist/action.sh

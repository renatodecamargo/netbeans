tail -f logs/syslg.log | awk '{print "SYSLG =>" $0}' &
tail -f debug/syslgcmd.debug | awk '{print "SL DEBUG =>" $0}' &
tail -f debug/mboxcmd.debug | awk '{print "MB DEBUG =>" $0}' &

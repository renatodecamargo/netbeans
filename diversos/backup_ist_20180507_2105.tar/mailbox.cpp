/* Standard Includes */
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/errno.h>
#include <sys/errno.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/stat.h>
#include <assert.h>
#include <string>

/* Product Includes */
#include "mailbox.h"
#include "ist_functions.h"
#include "misc_functions.h"
#include "gen_functions.h"

using namespace std;

shm_mbox_system_header * get_mbox_shm_stat ( void ) 
{
	int shmid = shmget( get_shm_mbox_key(), 0, S_IWUSR|S_IRUSR );

	if( shmid == -1 )
		return NULL;		/* Nao foi possivel localizar a shared memory */

	return (shm_mbox_system_header *)shmat( shmid, NULL, 0 );
}

int mbox_shm_create_memory( shm_mbox_system_header **shm )
{
	/* Create Shared Memory */
	register key_t key = get_shm_mbox_key();
	size_t shmsize = get_total_shm_len();

	int shmid = shmget( key, shmsize, IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR );
	
	if( shmid == -1 )
	{
		if( errno == EEXIST )
		{
			/* A shared memory ja existe, deve ser eliminada */
			shmid = shmget( key, 1, S_IRUSR | S_IWUSR );
			if( shmid == -1 )
				return MB_ERR_GET_SHM_FAILED;

			if( shmctl(shmid, IPC_RMID, 0) == -1 )
				return MB_ERR_CTL_RM_SHM_FAILED;
			else
				return mbox_shm_create_memory( shm ); /* tentar cria-la novamente */
		}
		return MB_ERR_CREATE_SHM_FAILED;
	}
	
	/* A shared memory foi criada */
	*shm = (shm_mbox_system_header *) shmat( shmid, NULL, 0 );
	
	memset( *shm, 0, sizeof(shm_mbox_system_header));
    
	(*shm)->buff_qty = get_shm_buff_qty();

	return shmid;
}

int mbox_shm_create_semaphore()
{
	int retcode;
    register key_t key = get_shm_mbox_key();
	int semid = semget( key, 1, IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR );
	if( semid == -1 )
	{
		if( errno == EEXIST )
		{
			/* O semaforo ja existe, deve ser eliminado */
			semid = semget( key, 1, S_IRUSR | S_IWUSR );
			if( semid == -1 )
				return MB_ERR_GET_SEM_FAILED;
			
			retcode = semctl( semid, 0, IPC_RMID, NULL );
			if( retcode != 0 )
				return MB_ERR_CTL_RM_SEM_FAILED;
			else
				return mbox_shm_create_semaphore(); /* tentar cria-lo novamente */
		}
		return MB_ERR_CREATE_SEM_FAILED;
	}
	return semid;
}

int mbox_shm_format_memory( shm_mbox_system_header *shm )
{
	assert( shm != NULL );

	shm->signature = MAILBOX_HEADER_SIGNATURE;
	shm->pid = getpid();
	shm->timestamp = get_timestamp();
    shm->buff_qty = get_shm_buff_qty();
    shm->buff_len = get_shm_buff_len();
    shm->lastindex = 0;

	for( int indiceMB = 0; indiceMB < shm->buff_qty; indiceMB++ )
	{
		shm_mbox_header *shmMailbox = get_mbox_index_header( indiceMB, shm );
		shmMailbox->signature = MAILBOX_SIGNATURE;
		shmMailbox->status = MAILBOX_FREE;
        shmMailbox->msqid = -1;
        shmMailbox->mbid = -1;
		shmMailbox->maxmsg = 0;
	}
	return (0);
}

int mbox_shm_init_semaphore( int semid )
{
	int retcode = 0;
	static struct sembuf operations[1];

	/* Inicializar semaforo */
    operations[0].sem_num = 0;
    operations[0].sem_op = 1;
    operations[0].sem_flg = 0;
    retcode = semop( semid, operations, 1 );

	if( retcode != 0 )
		return MB_ERR_SEMOP_INIT_FAILED;     /* Erro ao tentar liberar o semaforo */

	return(0);
}

int mbox_shm_show_memory()
{
	struct shmid_ds ipcStat = {0};
	
	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();
	
	if( mem_ptr == NULL )
		return MB_ERR_GET_SHM_FAILED;
		
	if( mem_ptr == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( mem_ptr->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	if ( shmctl(mem_ptr->shmid,IPC_STAT, &ipcStat) == -1)
		return MB_ERR_CTL_STAT_SHM_FAILED;

	fprintf(stdout,"================ SHM INFORMATION ========================\n");
	fprintf(stdout,"Signature    : 0x%x\n", mem_ptr->signature);
	fprintf(stdout,"SHM ID       : %d\n",   mem_ptr->shmid);
	fprintf(stdout,"Semaphore ID : %d\n",   mem_ptr->semid);
	fprintf(stdout,"PID          : %d\n",   mem_ptr->pid);
    fprintf(stdout,"MBox in Use  : %d\n",   mem_ptr->lastindex);
    fprintf(stdout,"Max MBox     : %d\n",   mem_ptr->buff_qty);
    fprintf(stdout,"Owner ID     : %d\n",   ipcStat.shm_perm.uid);
	fprintf(stdout,"Owner Group  : %d\n",   ipcStat.shm_perm.gid);
	fprintf(stdout,"Creator ID   : %d\n",   ipcStat.shm_perm.cuid);
	fprintf(stdout,"Creator Group: %d\n",   ipcStat.shm_perm.cgid);
	fprintf(stdout,"Access Mode  : %d\n",   ipcStat.shm_perm.mode);
	fprintf(stdout,"Size         : %d\n",   ipcStat.shm_segsz);
	fprintf(stdout,"Creator PID  : %d\n",   ipcStat.shm_cpid);
	fprintf(stdout,"Last PID     : %d\n",   ipcStat.shm_lpid);
	fprintf(stdout,"Uptime       : %s\n",   get_formatted_timestamp(mem_ptr->timestamp).c_str());
	fprintf(stdout,"=========================================================\n");
	
	return(0);
}

int mbox_locate( char *nameMailbox )
{
	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();

	if (shmHeader == NULL)
		return MB_ERR_GET_SHM_FAILED;

	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */
	
	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */	

	for( int indiceMB = 0; indiceMB < shmHeader->lastindex; indiceMB ++ )
	{
		shm_mbox_header *mailboxHeader = get_mbox_index_header( indiceMB, shmHeader );

		if( !strcmp(mailboxHeader->mbname,nameMailbox))
			return(mailboxHeader->mbid);
	}
	/* Not Found */
	return MB_ERR_MB_NOT_FOUND;
}

int mbox_has_messages( int mailboxId )
{
	struct msqid_ds buf;

	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();

	if (shmHeader == NULL)
		return MB_ERR_GET_SHM_FAILED;

	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */
	
	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */
	
	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, shmHeader );

	/* Signature Ok ? */
	if( mailboxHeader->signature != MAILBOX_SIGNATURE )
		return MB_ERR_MBSIGNATURE_SHM_FAILED;

	/* Get Information of Mailbox */
	if ( msgctl( mailboxHeader->msqid, IPC_STAT, &buf ) == -1 )
		return MB_ERR_CTL_STAT_MB_FAILED;

	return ( buf.msg_qnum );
}

int mbox_add_action( int mailboxId, int level, char *commandAction )
{
	int actionFound = 0;

	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();
	
	if( mem_ptr == NULL )
		return MB_ERR_GET_SHM_FAILED;
		
	if( mem_ptr == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( mem_ptr->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, mem_ptr );
	
	if( mailboxHeader->signature != MAILBOX_SIGNATURE )
			return MB_ERR_MBSIGNATURE_SHM_FAILED;

	if(mailboxHeader->msqid < 0 || mailboxHeader->mbid < 0)
		return MB_ERR_MBID_INVALID;

	if(mailboxHeader->status & MAILBOX_LOCKED)
		return MB_ERR_MBID_LOCKED;

	if(mailboxHeader->status & MAILBOX_DELETED)
		return MB_ERR_MBID_DELETED;	

	if(mailboxHeader->status & MAILBOX_CRASHED)
		return MB_ERR_MBID_CRASHED;

	if(mailboxHeader->status == MAILBOX_FREE)
		return MB_ERR_MB_NOT_INUSE;

	if( mailboxHeader->action[0].level != MAILBOX_NOLEVEL)
		return MB_ERR_NO_LEVEL_AVALIABLE;				

	if( sem_P(mem_ptr->semid) != 0 )  /* P Operation */
		return MB_ERR_SEMOP_P_FAILED; 		

	mailboxHeader->action[0].level = level;
	strcpy(mailboxHeader->action[0].action, (const char *)commandAction);
	mailboxHeader->action[0].triggerOn = MAILBOX_TRIGGER_OFF;
	mailboxHeader->action[0].execution = 0;

	if( sem_V(mem_ptr->semid) != 0 )	/* V Operation */
		return MB_ERR_SEMOP_V_FAILED;		

	return(0);
}

int mbox_remove_action( int mailboxId )
{
	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();
	
	if( mem_ptr == NULL )
		return MB_ERR_GET_SHM_FAILED;
		
	if( mem_ptr == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( mem_ptr->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, mem_ptr );
	
	if( mailboxHeader->signature != MAILBOX_SIGNATURE )
			return MB_ERR_MBSIGNATURE_SHM_FAILED;

	if(mailboxHeader->msqid < 0 || mailboxHeader->mbid < 0)
		return MB_ERR_MBID_INVALID;

	if(!(mailboxHeader->status & MAILBOX_LOCKED))
		return MB_ERR_MB_NOT_LOCKED;

	if(mailboxHeader->status & MAILBOX_DELETED)
		return MB_ERR_MBID_DELETED;	

	if(mailboxHeader->status & MAILBOX_CRASHED)
		return MB_ERR_MBID_CRASHED;

	if(mailboxHeader->status == MAILBOX_FREE)
		return MB_ERR_MB_NOT_INUSE;

	if ( mailboxHeader->action[0].level == MAILBOX_NOLEVEL)
		return MB_ERR_LEVEL_NOT_SETTED;		

	if( sem_P(mem_ptr->semid) != 0 )  /* P Operation */
		return MB_ERR_SEMOP_P_FAILED; 		

	/* Update SHM */
	mailboxHeader->action[0].level = MAILBOX_NOLEVEL;
	mailboxHeader->action[0].action[0] = 0;
	mailboxHeader->action[0].triggerOn = MAILBOX_TRIGGER_OFF;
	mailboxHeader->action[0].execution = 0;	

	if( sem_V(mem_ptr->semid) != 0 )	/* V Operation */
		return MB_ERR_SEMOP_V_FAILED;		

	return(0);
}

int mbox_unlock( int mailboxId )
{
	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();
	
	if( mem_ptr == NULL )
		return MB_ERR_GET_SHM_FAILED;
		
	if( mem_ptr == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( mem_ptr->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, mem_ptr );
	
	if( mailboxHeader->signature != MAILBOX_SIGNATURE )
			return MB_ERR_MBSIGNATURE_SHM_FAILED;

	if(mailboxHeader->msqid < 0 || mailboxHeader->mbid < 0)
		return MB_ERR_MBID_INVALID;

	if(!(mailboxHeader->status & MAILBOX_LOCKED))
		return MB_ERR_MB_NOT_LOCKED;

	if(mailboxHeader->status & MAILBOX_DELETED)
		return MB_ERR_MBID_DELETED;	

	if(mailboxHeader->status & MAILBOX_CRASHED)
		return MB_ERR_MBID_CRASHED;

	if(mailboxHeader->status == MAILBOX_FREE)
		return MB_ERR_MB_NOT_INUSE;	

	if( sem_P(mem_ptr->semid) != 0 )  /* P Operation */
		return MB_ERR_SEMOP_P_FAILED; 		

	/* Update SHM */
	mailboxHeader->status = mailboxHeader->status ^ MAILBOX_LOCKED;

	if( sem_V(mem_ptr->semid) != 0 )	/* V Operation */
		return MB_ERR_SEMOP_V_FAILED;		

	return(0);
}

int mbox_delete( int mailboxId )
{
	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();
	
	if( mem_ptr == NULL )
		return MB_ERR_GET_SHM_FAILED;
		
	if( mem_ptr == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( mem_ptr->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, mem_ptr );
	
	if( mailboxHeader->signature != MAILBOX_SIGNATURE )
			return MB_ERR_MBSIGNATURE_SHM_FAILED;

	if(mailboxHeader->msqid < 0 || mailboxHeader->mbid < 0)
		return MB_ERR_MBID_INVALID;

	if(mailboxHeader->status & MAILBOX_LOCKED)
		return MB_ERR_MBID_LOCKED;

	if(mailboxHeader->status & MAILBOX_DELETED)
		return MB_ERR_MBID_DELETED;

	if(mailboxHeader->status & MAILBOX_CRASHED)
		return MB_ERR_MBID_CRASHED;

	if(mailboxHeader->status == MAILBOX_FREE)
		return MB_ERR_MB_NOT_INUSE;	

	if( sem_P(mem_ptr->semid) != 0 )  /* P Operation */
		return MB_ERR_SEMOP_P_FAILED; 		

	/* Update SHM */
	mailboxHeader->status = mailboxHeader->status | MAILBOX_DELETED;

	if( sem_V(mem_ptr->semid) != 0 )	/* V Operation */
		return MB_ERR_SEMOP_V_FAILED;
	
	mbox_clear_queue( mailboxId, MAILBOX_CLEAR_SILENCE );

	return(0);
}

int mbox_lock( int mailboxId )
{
	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();
	
	if( mem_ptr == NULL )
		return MB_ERR_GET_SHM_FAILED;
		
	if( mem_ptr == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( mem_ptr->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, mem_ptr );
	
	if( mailboxHeader->signature != MAILBOX_SIGNATURE )
			return MB_ERR_MBSIGNATURE_SHM_FAILED;

	if(mailboxHeader->msqid < 0 || mailboxHeader->mbid < 0)
		return MB_ERR_MBID_INVALID;

	if(mailboxHeader->status & MAILBOX_LOCKED)
		return MB_ERR_MBID_LOCKED;

	if(mailboxHeader->status & MAILBOX_DELETED)
		return MB_ERR_MBID_DELETED;	

	if(mailboxHeader->status & MAILBOX_CRASHED)
		return MB_ERR_MBID_CRASHED;

	if(mailboxHeader->status == MAILBOX_FREE)
		return MB_ERR_MB_NOT_INUSE;	

	if( sem_P(mem_ptr->semid) != 0 )  /* P Operation */
		return MB_ERR_SEMOP_P_FAILED; 		

	/* Update SHM */
	mailboxHeader->status = mailboxHeader->status | MAILBOX_LOCKED;

	if( sem_V(mem_ptr->semid) != 0 )	/* V Operation */
		return MB_ERR_SEMOP_V_FAILED;		

	return(0);
}

int mbox_info ( int mailboxId )
{
	struct msqid_ds buf;
	
	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();
	
	if( mem_ptr == NULL )
		return MB_ERR_GET_SHM_FAILED;
		
	if( mem_ptr == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( mem_ptr->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, mem_ptr );

	/* Signature Ok ? */
	if( mailboxHeader->signature != MAILBOX_SIGNATURE )
		return MB_ERR_MBSIGNATURE_SHM_FAILED;

	/* Get Information of Mailbox */
	if ( msgctl( mailboxHeader->msqid, IPC_STAT, &buf ) == -1 )
		return MB_ERR_CTL_STAT_MB_FAILED;

    fprintf(stdout,"================ MAILBOX INFORMATION ========================\n");
	fprintf(stdout,"MailBox ID                  : %d\n",mailboxHeader->mbid);
	fprintf(stdout,"MSQID                       : %d\n",mailboxHeader->msqid);
	fprintf(stdout,"MailBox Name                : %s\n",mailboxHeader->mbname);
	fprintf(stdout,"MB Signature                : 0x%x\n",mailboxHeader->signature);
	fprintf(stdout,"Status                      : 0x%x\n",mailboxHeader->status);
	fprintf(stdout,"MB In Use                   : %s\n",(mailboxHeader->status & MAILBOX_INUSE ? "Yes" : "No"));
	fprintf(stdout,"MB Locked                   : %s\n",(mailboxHeader->status & MAILBOX_LOCKED ? "Yes" : "No"));
	fprintf(stdout,"MB Deleted                  : %s\n",(mailboxHeader->status & MAILBOX_DELETED ? "Yes" : "No"));
	fprintf(stdout,"MB Crashed                  : %s\n",(mailboxHeader->status & MAILBOX_CRASHED ? "Yes" : "No"));
	fprintf(stdout,"MB Key                      : 0x%x\n",get_shm_private_mbox_key(mailboxId));
    fprintf(stdout,"Owner ID                    : %d\n",buf.msg_perm.uid);
    fprintf(stdout,"Owner Group ID              : %d\n",buf.msg_perm.gid);
    fprintf(stdout,"Creator ID                  : %d\n",buf.msg_perm.cuid);
    fprintf(stdout,"Creator Group ID            : %d\n",buf.msg_perm.cgid);
    fprintf(stdout,"Permission                  : %d\n",buf.msg_perm.mode);
    fprintf(stdout,"Bytes Queued                : %d\n",buf.msg_cbytes);
    fprintf(stdout,"Number of Messages          : %d\n",buf.msg_qnum);
	fprintf(stdout,"Max Messages reached        : %d\n",mailboxHeader->maxmsg);
    fprintf(stdout,"Max bytes                   : %d\n",buf.msg_qbytes);
    fprintf(stdout,"PID Last Writer             : %d\n",buf.msg_lspid);
    fprintf(stdout,"PID Last Reader             : %d\n",buf.msg_lrpid);
    fprintf(stdout,"Last Write Date             : %s\n",get_formatted_timestamp(buf.msg_stime).c_str());
    fprintf(stdout,"Last Read Date              : %s\n",get_formatted_timestamp(buf.msg_rtime).c_str());
    fprintf(stdout,"Last Modification           : %s\n",get_formatted_timestamp(buf.msg_ctime).c_str());
	if( mailboxHeader->action[0].level != MAILBOX_NOLEVEL ) {
		fprintf(stdout,"Trigger Action LEVEL        : %d\n", mailboxHeader->action[0].level);
		fprintf(stdout,"Trigger Action Command      : %s\n", mailboxHeader->action[0].action);
		fprintf(stdout,"Trigger Action ON           : %s\n", ( mailboxHeader->action[0].triggerOn ? "Yes" : "No" ));
		fprintf(stdout,"Trigger Action #Execution   : %d\n", mailboxHeader->action[0].execution);
		fprintf(stdout,"Last Trigger Execution      : %s\n", get_formatted_timestamp(mailboxHeader->action[0].triggerTime).c_str());
	}
	fprintf(stdout,"============================================================\n");
	return (0);
}

int mbox_shm_get_queue_stat()
{
	struct msqid_ds buf;
	char commandLine[MAX_IST_STRING] = {0};
	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();
	
	if( mem_ptr == NULL )
		return MB_ERR_GET_SHM_FAILED;
		
	if( mem_ptr == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( mem_ptr->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	for( int indiceMB = 0; indiceMB < mem_ptr->lastindex; indiceMB++ )
	{
		shm_mbox_header *mb = get_mbox_index_header( indiceMB, mem_ptr );
	
		/* Signature Ok ? */
		if( mb->signature != MAILBOX_SIGNATURE )
			return MB_ERR_MBSIGNATURE_SHM_FAILED;

		/* Get Information of Mailbox */
		if ( msgctl( mb->msqid, IPC_STAT, &buf ) == 0 )
		{
			if ( buf.msg_qnum > mb->maxmsg )
			{
				if( sem_P(mem_ptr->semid) != 0 )    /* P Operation */
				{
					debug_log(mbox_debug_fp,"Mbox [%d]. Semaphore P error => Status [%d]\n",mb->mbid,errno);
					continue;   /* Abort this sample */
				}

				mb->maxmsg = buf.msg_qnum;

				if( sem_V(mem_ptr->semid) != 0 )	/* V Operation */
					debug_log(mbox_debug_fp,"Mbox [%d]. Semaphore V error => Status [%d]\n",mb->mbid,errno);
			}

			/* Trigger for action */
			if( buf.msg_qnum > mb->action[0].level && mb->action[0].triggerOn == MAILBOX_TRIGGER_OFF )
			{
				if( sem_P(mem_ptr->semid) != 0 )    /* P Operation */
				{
					debug_log(mbox_debug_fp,"Mbox [%d]. Semaphore P error => Status [%d]\n",mb->mbid,errno);
					continue;   /* Abort this sample */
				}

				mb->action[0].triggerOn = MAILBOX_TRIGGER_ON;
				mb->action[0].execution++;
				mb->action[0].triggerTime = get_timestamp();

				if( sem_V(mem_ptr->semid) != 0 )	/* V Operation */
					debug_log(mbox_debug_fp,"Mbox [%d]. Semaphore V error => Status [%d]\n",mb->mbid,errno);

				sprintf(commandLine,"%s %d %s %d %d %d", mb->action[0].action, mb->mbid, mb->mbname, buf.msg_qnum, mb->action[0].level, mb->action[0].execution);
				/* fprintf(stdout,"%s\n",commandLine); */
				int cmdlineRespCode = system(commandLine);
				/* fprintf(stdout,"%d\n",cmdlineRespCode); */
				debug_log(mbox_debug_fp,"Action Trigger [%s] executed for Mbox [%d] => RC [%d]\n",commandLine, mb->mbid, cmdlineRespCode);
			}
			else 
			{
				/* Turn Off Trigger */
				if( sem_P(mem_ptr->semid) != 0 )    /* P Operation */
				{
					debug_log(mbox_debug_fp,"Mbox [%d]. Semaphore P error => Status [%d]\n",mb->mbid,errno);
					continue;   /* Abort this sample */
				}

				mb->action[0].triggerOn = MAILBOX_TRIGGER_OFF;

				if( sem_V(mem_ptr->semid) != 0 )	/* V Operation */
					debug_log(mbox_debug_fp,"Mbox [%d]. Semaphore V error => Status [%d]\n",mb->mbid,errno);				
			}
		}
	}
	return (0);
}

int mbox_shm_show_queues( int mailboxStatus )
{
	struct msqid_ds buf;
	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();
	
	if( mem_ptr == NULL )
		return MB_ERR_GET_SHM_FAILED;
		
	if( mem_ptr == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( mem_ptr->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	for( int indiceMB = 0; indiceMB < mem_ptr->lastindex; indiceMB ++ )
	{
		shm_mbox_header *mb = get_mbox_index_header( indiceMB, mem_ptr );
	
		/* Signature Ok ? */
		if( mb->signature != MAILBOX_SIGNATURE )
			return MB_ERR_MBSIGNATURE_SHM_FAILED;

		/* Get Information of Mailbox */
		if ( msgctl( mb->msqid, IPC_STAT, &buf ) == -1 )
			return MB_ERR_CTL_STAT_MB_FAILED;
		
		if(( buf.msg_qnum > 0 && mailboxStatus == MAILBOX_QUEUED) || 
		   ( mb->msqid >= 0 && mb->status & MAILBOX_INUSE && mb->status & mailboxStatus ))
		{
			fprintf(stdout,"%c%c [%04d] %-40.40s %05d (%d bytes) %05d R[%s => %d] W[%s => %d]\n",
					(mb->status & MAILBOX_LOCKED ? 'L' : mb->status & MAILBOX_DELETED ? 'D' : ' ' ),
					(mb->action[0].level > 0 ? 'A' : ' ' ),
					mb->mbid, 
					mb->mbname, 
					buf.msg_qnum,
					buf.msg_cbytes, 
					mb->maxmsg,					
					get_formatted_timestamp(buf.msg_rtime).c_str(), 
					buf.msg_lrpid, 
					get_formatted_timestamp(buf.msg_stime).c_str(),
					buf.msg_lspid );
		}
	}
	return (0);
}

shm_mbox_header *get_mbox_index_header( unsigned short index, shm_mbox_system_header *ptr )
{
	shm_mbox_header *ptr_to_first_header;

	assert( ptr != NULL );

	ptr_to_first_header = (shm_mbox_header *) ((char*)ptr + sizeof(shm_mbox_system_header));
	shm_mbox_header *ret = (shm_mbox_header *) ((char*)ptr_to_first_header + ptr->buff_len * index);
	/* fprintf(stdout,"%d.%d=> %ld\n", index, ptr->buff_len, (int) ((char *)ret - (char *)ptr)); */
	return ret;
}

size_t get_total_shm_len( void )
{
	size_t len = sizeof( shm_mbox_system_header );
	len += sizeof( shm_mbox_header ) * get_shm_buff_qty();

	return len;
}

size_t get_shm_buff_len( void )
{
    return sizeof(shm_mbox_header);
}

size_t get_shm_buff_qty( void )
{
    int buff_qty;
    cf_locatenum(PRODUCT_KEY_MAX_MB,&buff_qty);
	return (size_t)buff_qty;
}

int mbox_get_shm_id()
{
	return(shmget(get_shm_mbox_key(),sizeof( shm_mbox_system_header ), 0 ));
}

int mbox_get_semaphore_id()
{
	return(semget( get_shm_mbox_key(), 1, S_IRUSR | S_IWUSR ));
}

int mbox_remove_shm()
{
	return(shmctl( mbox_get_shm_id(), IPC_RMID, NULL));
}

int mbox_remove_semaphore()
{
	return(semctl (mbox_get_semaphore_id(), 0, IPC_RMID, 0));
}

int  mbox_remove_queues()
{
	struct shmid_ds stat_buf ;
	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();
	
	if( mem_ptr == NULL )
		return MB_ERR_GET_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( mem_ptr == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */		

	if( mem_ptr->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	for( int idx = 0; idx < mem_ptr->lastindex; idx ++ )
	{
		shm_mbox_header *mb = get_mbox_index_header( idx, mem_ptr );

		if( mb->msqid >= 0 ) /* Remove only Active Queues */
		{
			msgctl(mb->msqid,IPC_RMID, NULL);
			debug_log(mbox_debug_fp,"Queue Remove[%d:%s] => Status [%d]\n",mb->msqid,mb->mbname,errno);
		}
	}
	return(0);
}

int mbox_create( char *mboxname )
{
	int mqsid = -1;
	shm_mbox_system_header *mem_ptr = get_mbox_shm_stat();

	if (mem_ptr == NULL)
		return MB_ERR_GET_SHM_FAILED;

	if( mem_ptr == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */
	
	if( mem_ptr->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */				

	if ( mem_ptr->lastindex >= mem_ptr->buff_qty )
	{
		debug_log(mbox_debug_fp,"Too many mailboxes. Mailbox %s not created\n",mboxname);
		return MB_ERR_TOO_MANY;
	}

	/* Create Queue */
	register key_t key = get_shm_private_mbox_key( mem_ptr->lastindex );

	/* fprintf(stderr,"Private Key 0x%x\n", key); */
	if(( mqsid = msgget(key, IPC_CREAT | 0666 )) < 0)
	{
		debug_log(mbox_debug_fp,"Queue Name [%s] could not be created => Status [%d]\n",mboxname,errno);
		return MB_ERR_CREATE_MB_FAILED;
	}
	/* fprintf(stderr,"mqsid=[%d],lastindex[%d] semaphore[%d] shmid[%d]\n",mqsid,mem_ptr->lastindex,mem_ptr->semid,mem_ptr->shmid); */
	
	if( sem_P(mem_ptr->semid) != 0 )  /* P Operation */
	{ 
		debug_log(mbox_debug_fp,"Mbox [%s] will be deleted. Semaphore error => Status [%d]\n",mboxname,errno);
		if( msgctl(mqsid,IPC_RMID, NULL) < 0);
			debug_log(mbox_debug_fp,"Queue Name [%s] could not be deleted => Status [%d]\n",mboxname,errno);
		return MB_ERR_SEMOP_P_FAILED; 		
	}

	/* Update SHM */
	shm_mbox_header *mailboxHeader = get_mbox_index_header( mem_ptr->lastindex, mem_ptr );
	mailboxHeader->msqid = mqsid;
    mailboxHeader->mbid = mem_ptr->lastindex;
	strcpy(mailboxHeader->mbname,mboxname);
	mailboxHeader->status = MAILBOX_INUSE;
	mailboxHeader->action[0].level = MAILBOX_NOLEVEL;
	mem_ptr->lastindex++;

	if( sem_V(mem_ptr->semid) != 0 )	/* V Operation */
		return MB_ERR_SEMOP_V_FAILED;

	return( mailboxHeader->mbid );   /* Return MB ID */
}

int mbox_write( int mailboxId, char *messageBuffer, size_t messageLen )
{
	int sendRespCode = 0;
	shm_mbox_message mailboxBufferStruct = {0};

	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();

	if (shmHeader == NULL)
		return MB_ERR_GET_SHM_FAILED;

	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */
	
	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */	

	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, shmHeader );

	if(mailboxHeader->signature != MAILBOX_SIGNATURE)
		return MB_ERR_SIGNATURE_MB_FAILED;

	if(mailboxHeader->msqid < 0 || mailboxHeader->mbid < 0)
		return MB_ERR_MBID_INVALID;

	if(mailboxHeader->status & MAILBOX_LOCKED)
		return MB_ERR_MBID_LOCKED;

	if(mailboxHeader->status & MAILBOX_DELETED)
		return MB_ERR_MBID_DELETED;	

	if(mailboxHeader->status & MAILBOX_CRASHED)
		return MB_ERR_MBID_CRASHED;

	if(mailboxHeader->status == MAILBOX_FREE)
		return MB_ERR_MB_NOT_INUSE;			

	mailboxBufferStruct.messageType = 1;
	memcpy(mailboxBufferStruct.messageBuffer, messageBuffer, messageLen);

	/*fprintf(stdout,"Send to [%d] msg of %d bytes [%s]\n",mailboxHeader->msqid, messageLen, messageBuffer);*/
	if ((sendRespCode = msgsnd(mailboxHeader->msqid, &mailboxBufferStruct, messageLen, IPC_NOWAIT)) < 0)
		return MB_ERR_MQSEND_FAILED;

	return (mailboxHeader->mbid);
}

int mbox_read( int mailboxId, char *messageBuffer, size_t bufferLength )
{
	ssize_t readRespCode = 0;
	shm_mbox_message readBuffer = {0};

	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();

	if (shmHeader == NULL)
		return MB_ERR_GET_SHM_FAILED;

	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */
	
	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */	

	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, shmHeader );

	if(mailboxHeader->signature != MAILBOX_SIGNATURE)
		return MB_ERR_SIGNATURE_MB_FAILED;

	if(mailboxHeader->msqid < 0 || mailboxHeader->mbid < 0)
		return MB_ERR_MBID_INVALID;

	if(mailboxHeader->status & MAILBOX_LOCKED)
		return MB_ERR_MBID_LOCKED;

	if(mailboxHeader->status & MAILBOX_DELETED)
		return MB_ERR_MBID_DELETED;	

	if(mailboxHeader->status & MAILBOX_CRASHED)
		return MB_ERR_MBID_CRASHED;

	if(mailboxHeader->status == MAILBOX_FREE)
		return MB_ERR_MB_NOT_INUSE;						

	if ((readRespCode = msgrcv(mailboxHeader->msqid, (void *)&readBuffer, bufferLength, 0, IPC_NOWAIT)) < 0)
		return MB_ERR_MQRCV_FAILED;

	memcpy(messageBuffer,readBuffer.messageBuffer,readRespCode);

	return (int)(readRespCode);
}

int mbox_clear_queue ( int mailboxId, int silenceMode )
{
	ssize_t readRespCode = 0;
	shm_mbox_message readBuffer = {0};

	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();

	if (shmHeader == NULL)
		return MB_ERR_GET_SHM_FAILED;

	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */
	
	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */	

	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, shmHeader );

	if(mailboxHeader->signature != MAILBOX_SIGNATURE)
		return MB_ERR_SIGNATURE_MB_FAILED;

	if(mailboxHeader->msqid < 0 || mailboxHeader->mbid < 0)
		return MB_ERR_MBID_INVALID;

	if(mailboxHeader->status & MAILBOX_LOCKED)
		return MB_ERR_MBID_LOCKED;

	if(mailboxHeader->status & MAILBOX_DELETED)
		return MB_ERR_MBID_DELETED;	

	if(mailboxHeader->status & MAILBOX_CRASHED)
		return MB_ERR_MBID_CRASHED;

	if(mailboxHeader->status == MAILBOX_FREE)
		return MB_ERR_MB_NOT_INUSE;						

	/* fprintf(stdout,"Clearing %d messages from MBox [%d]\n", mbox_has_messages(mailboxId), mailboxId); */
	while ((readRespCode = msgrcv(mailboxHeader->msqid, (void *)&readBuffer, sizeof(shm_mbox_message), 0, IPC_NOWAIT)) > 0)
	{
		if ( silenceMode == MAILBOX_CLEAR_NO_SILENCE )
			fprintf(stdout,"Reading %d bytes from [%d]\n", readRespCode, mailboxId);
	}
	return (0);
}

int mbox_get_active_pid()
{
	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();

	if (shmHeader == NULL)
		return MB_ERR_GET_SHM_FAILED;

	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */
	
	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */	

	return(shmHeader->pid);
}

key_t get_shm_mbox_key( void )
{
	register key_t key = MAILBOX_BASE_KEY;

	if (!getenv(PRODUCT_SHM_VAR))
		return 0;

	register int region = atoi(getenv(PRODUCT_SHM_VAR)) % 256;
	key += region;
	key += region << 8;
	key += region << 16;
	key += region << 24;

	return key;
}

key_t get_shm_private_mbox_key( int idx )
{
	register key_t key = MAILBOX_BASE_KEY;

	if (!getenv(PRODUCT_SHM_VAR))
		return 0;

	register int region = atoi(getenv(PRODUCT_SHM_VAR)) % 256;
	key += region;
	key += region << 8;
	key += region << 16;
	key += region << 24;
	key += idx;

	return key;
}
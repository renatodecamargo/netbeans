#ifndef _GEN_FUNCTIONS_H_
#define _GEN_FUNCTIONS_H_

std::string DumpHex(const char *title, const void* data, size_t size);
std::string get_formatted_timestamp(time_t rawtime);
int isNumeric( char *seqChar );

#endif
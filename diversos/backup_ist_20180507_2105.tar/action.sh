syslgcmd -s "$1 $2 $3 $4 $5"
echo "Mbox " $1
echo "MboxName " $2
echo "Queued " $3
echo "Trigger " $4
echo "Execution " $5

if [ $5 -gt 2 ]; then
    mboxcmd -clear $1
fi
exit 0
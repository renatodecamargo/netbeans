for i in {1..1000}
do
   mboxcmd -create "mbox$i"
   if [ $? -eq 0 ]; then 
      sleep 1
   else
      exit 1   
   fi
done

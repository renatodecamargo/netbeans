#ifndef _IST_FUNCTIONS_H_
#define _IST_FUNCTIONS_H_
#include <stdio.h>

#define MAX_IST_STRING             255
#define MAX_PORTS                  100
#define PRODUCT_ALIAS              "LSW"
#define PRODUCT_SHM_VAR            "LSWID"
#define PRODUCT_CFG_VAR            "LSWCFG"

#define PRODUCT_KEY_SHM            "config.shmid"
#define PRODUCT_KEY_MAX_PORTS      "config.maxports"
#define PRODUCT_KEY_MAX_MB         "config.maxmbox"
#define PRODUCT_KEY_MAX_BUFFERS    "config.maxbuffers"
#define PRODUCT_KEY_MAX_BUFSIZE    "config.maxbufsize"
#define PRODUCT_KEY_MASTERLOG      "config.masterlog"
#define PRODUCT_KEY_MASTERDIRLOG   "config.masterdirlogs"
#define PRODUCT_KEY_MASTERDIRDEBUG "config.masterdebuglogs"

static FILE *cf_param;
static int cf_current_line;
static bool cf_opened;

int cf_open( const char *filename );
int cf_locate( const char *keyentry, char *data );
int cf_locatenum( const char *keyentry, int *data );
int cf_nextparm( const char *keyentry, char *data ); 
int cf_close( void );
int catch_all_signals(  void (*signal_handler )(int) );

#endif
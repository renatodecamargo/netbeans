#ifndef _MAILBOX_H_
#define _MAILBOX_H_

#include "ist_functions.h"

#define MAILBOX_HEADER_SIGNATURE 0xFCFCFCFC
#define MAILBOX_SIGNATURE        0xFAFAFAFA
#define MAILBOX_BASE_KEY         0x53412222
#define MAILBOX_MSG_MAX_SIZE     20000
#define MAILBOX_CLEAR_NO_SILENCE 0
#define MAILBOX_CLEAR_SILENCE    1
#define MAILBOX_NOLEVEL          -1
#define MAILBOX_MAX_ACTION       1
#define MAILBOX_TRIGGER_ON       1
#define MAILBOX_TRIGGER_OFF      1

#define MB_ERR_GET_SHM_FAILED          -1
#define MB_ERR_ATT_SHM_FAILED          -2
#define MB_ERR_CTL_RM_SHM_FAILED       -3
#define MB_ERR_CREATE_SHM_FAILED       -4
#define MB_ERR_SIGNATURE_SHM_FAILED    -5
#define MB_ERR_CTL_STAT_SHM_FAILED     -6
#define MB_ERR_MBSIGNATURE_SHM_FAILED  -7

#define MB_ERR_GET_SEM_FAILED      -101
#define MB_ERR_ATT_SEM_FAILED      -102
#define MB_ERR_CTL_RM_SEM_FAILED   -103
#define MB_ERR_CREATE_SEM_FAILED   -104
#define MB_ERR_SEMOP_INIT_FAILED   -105
#define MB_ERR_SEMOP_P_FAILED      -106
#define MB_ERR_SEMOP_V_FAILED      -106

#define MB_ERR_TOO_MANY            -201
#define MB_ERR_CREATE_MB_FAILED    -202
#define MB_ERR_CTL_RM_MB_FAILED    -203
#define MB_ERR_CTL_STAT_MB_FAILED  -204
#define MB_ERR_SIGNATURE_MB_FAILED -205
#define MB_ERR_MBID_INVALID        -206
#define MB_ERR_MBID_LOCKED         -207
#define MB_ERR_MBID_DELETED        -208
#define MB_ERR_MBID_CRASHED        -209
#define MB_ERR_MQSEND_FAILED       -210
#define MB_ERR_MQRCV_FAILED        -211
#define MB_ERR_MB_NOT_FOUND        -212
#define MB_ERR_MB_NOT_INUSE        -213
#define MB_ERR_MB_NOT_LOCKED       -214
#define MB_ERR_NO_MORE_LEVEL       -215
#define MB_ERR_NO_LEVEL_AVALIABLE  -216
#define MB_ERR_LEVEL_NOT_SETTED    -217

#define MAILBOX_FREE               0x00
#define MAILBOX_INUSE              0x01
#define MAILBOX_QUEUED             0x02
#define MAILBOX_LOCKED             0x04
#define MAILBOX_DELETED            0x08
#define MAILBOX_CRASHED            0x10

#define DEFAULT_SLEEP_TIME         5

static FILE *mbox_debug_fp = NULL;

typedef struct {
	int     signature;
	int     shmid;
	int     semid;
	int     pid;
	int     sleeptime;
    size_t  buff_qty;
	size_t  buff_len;
    int     lastindex;
	time_t  timestamp;
} shm_mbox_system_header;

struct mbox_action{
	int level;
	int triggerOn;
	int execution;
	time_t triggerTime;
	char action[MAX_IST_STRING];
};

typedef struct {
	int    signature;
	int    msqid;
    int    mbid;
	int    status;
    char   mbname[MAX_IST_STRING];
    int    maxmsg;
	mbox_action action[MAILBOX_MAX_ACTION];
} shm_mbox_header;

typedef struct {
	long		messageType;
	char		messageBuffer[MAILBOX_MSG_MAX_SIZE];
} shm_mbox_message;

shm_mbox_system_header * get_mbox_shm_stat ( void ) ;
int mbox_shm_create_memory( shm_mbox_system_header **shm );
int mbox_shm_create_semaphore();
int mbox_shm_format_memory( shm_mbox_system_header *shm );
int mbox_shm_init_semaphore( int semid );
int mbox_shm_show_memory();
shm_mbox_header *get_mbox_index_header( unsigned short index, shm_mbox_system_header *ptr );
size_t get_total_shm_len( void );
size_t get_shm_buff_len( void );
size_t get_shm_buff_qty( void );
int mbox_get_active_pid();
key_t get_shm_private_mbox_key( int idx );
key_t get_shm_mbox_key( void );
int mbox_get_shm_id();
int mbox_get_semaphore_id();
int mbox_remove_shm();
int mbox_remove_semaphore();
int mbox_remove_queues();
int mbox_create( char *mboxname );
int mbox_shm_show_queues( int mailboxStatus );
int mbox_write( int mailboxId, char *messageBuffer, size_t messageLen );
int mbox_locate( char *nameMailbox );
int mbox_has_messages( int mailboxId );
int mbox_read( int mailboxId, char *messageBuffer, size_t bufferLength );
int mbox_info ( int mailboxId );
int mbox_lock( int mailboxId );
int mbox_delete( int mailboxId );
int mbox_unlock( int mailboxId );
int mbox_clear_queue ( int mailboxId, int silenceMode );
int mbox_shm_get_queue_stat();
int mbox_add_action( int mailboxId, int level, char *commandAction );
int mbox_remove_action( int mailboxId );
int mbox_get_sleep_time();

#endif
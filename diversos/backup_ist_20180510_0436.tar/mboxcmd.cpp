/* TODO LIST */
/*

*/
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/stat.h>
#include <assert.h>
#include <signal.h>
#include <errno.h>
#include <string>
#include <libgen.h>

#include "syslg.h"
#include "mailbox.h"
#include "ist_functions.h"
#include "misc_functions.h"
#include "gen_functions.h"

#define MODULE_VERSION  "r1.0"
#define MODULE_NAME     "mboxcmd"
#define SetCmdParam( command, function ) if(!strcmp(mailboxFunctionParameter,command)) mailboxFunction = function;

enum {
	/* Stop Start */
	NONE_FUNCTION = 0,
	START_FUNCTION,
	STOP_FUNCTION,
	RELEASE_FUNCTION,
	
	/* Monitor Functions */
	MON_FUNCTION,
    DEEP_FUNCTION,
	QUEUED_FUNCTION,
	SEE_LOCK_FUNCTION,
	SEE_DELETED_FUNCTION,
	MB_DETAIL_FUNCTION,
	KEY_FUNCTION,

	/* Action Functions */
    CREATE_FUNCTION,
    DELETE_FUNCTION,
	LOCK_FUNCTION,
	UNLOCK_FUNCTION,
	SEND_MSG_FUNCTION,
    READ_MSG_FUNCTION,
    CLEAR_QUEUE_FUNCTION,
    CLEAR_STAT_FUNCTION,
	ADD_ACTION_FUNCTION,
	REMOVE_ACTION,
	SET_SLEEP_FUNCTION,
	DUMP_FUNCTION
};

static shm_mbox_system_header *shmHeader = NULL;
static int mailboxFunction = NONE_FUNCTION;
char *mailboxFunctionParameter = NULL;
char *argvParameter1 = NULL;
char *argvParameter2 = NULL;
char *argvParameter3 = NULL;

/************************************************************************************************************
* Name        : signal_handler
* Description : Deal with Signals from Operation System and exit from MailBox System
* Parameters  : signalNumber
* Return      : None
*************************************************************************************************************/
void signal_handler(int signalNumber)
{
	int returnCode;
	char messageLog[MAX_IST_STRING] = {0};

	/* Send Message do Debug Info */
	sprintf( messageLog,"Signal Received [%d]", signalNumber );
	debug_log( mbox_debug_fp, "%s\n", messageLog );
	syslg("%s\n",messageLog);

	/* Remove Queue */
	if ((returnCode = mbox_remove_queues()) < 0)
		debug_log( mbox_debug_fp, "Message queues could not be deleted [%d]. Errno [%d]\n", returnCode, errno );	

	/* Remove SHM */
	if ((returnCode = mbox_remove_shm()) < 0)
		debug_log( mbox_debug_fp, "SHM could not be deleted [%d]. Errno [%d]\n", returnCode, errno );

	/* Remove SHM */
	if ((returnCode = mbox_remove_semaphore()) < 0)
		debug_log( mbox_debug_fp, "Semaphore could not be deleted [%d]. Errno [%d]\n", returnCode, errno );

	/* Close files */
	fclose(mbox_debug_fp);

	/* Exit with signal received */
	exit(signalNumber);
}

/************************************************************************************************************
* Name        : mbox_handler
* Description : Deal with Mailboxes from MailBox System. In errors situations, exit to OS
* Parameters  : None
* Return      : 1
*************************************************************************************************************/
int mbox_handler( void )
{
	char debugName[MAX_IST_STRING] = {0};
    int msqId, semId, shmId;
    int maxMailboxes = 0;

	/* Get SHM Header */
	shmHeader = get_mbox_shm_stat ();
	if( shmHeader != NULL ) {
		fprintf(stderr,"E-%s-012 Mbox already started with PID [%d]\n", PRODUCT_ALIAS, shmHeader->pid );
		exit(1);
	}

	/* Get Parameters */
	cf_locate(PRODUCT_KEY_MASTERDIRDEBUG,debugName);
	sprintf(debugName,"%s/%s.debug",debugName,MODULE_NAME);
	
	
    cf_locatenum(PRODUCT_KEY_MAX_MB,&maxMailboxes);
	debug_log(mbox_debug_fp,"Current %s Max Number of Mbox : [%d]\n", PRODUCT_ALIAS, maxMailboxes);
	fprintf(stdout,"Current %s Max Number of Mbox : [%d]\n", PRODUCT_ALIAS, maxMailboxes);

	if((shmId = mbox_shm_create_memory( &shmHeader )) < 0 )
	{
		fprintf(stderr,"E-%s-013 Cannot create SHM. Check user permission\n", PRODUCT_ALIAS );
		exit(1);
	}

	if(( semId = mbox_shm_create_semaphore()) < 0 )
	{
		fprintf(stderr,"E-%s-014 Cannot create semaphore. Check user permission\n", PRODUCT_ALIAS );
		exit(1);
	}

	shmHeader->semid = semId;
	shmHeader->shmid = shmId;

	mbox_shm_format_memory(shmHeader);

	if( mbox_shm_init_semaphore( semId ) < 0 ) {
		fprintf(stderr,"E-%s-015 Cannot initialize semaphore. Check user permission\n", PRODUCT_ALIAS );
		exit(1);
	}

	/* Open Debug file */
	if(( mbox_debug_fp = fopen(debugName,"a+t")) == NULL ) {
		fprintf(stderr,"E-%s-012 Unable to open debug [%s]\n", PRODUCT_ALIAS, debugName );
     	exit(1);
	}

	/* Send Some Messages do Debug and Log */
	debug_log(mbox_debug_fp,"Current %s Mbox Key: [0x%x]\n", PRODUCT_ALIAS, get_shm_mbox_key());
	fprintf(stdout,"Current %s Mbox Key: [0x%x]\n", PRODUCT_ALIAS, get_shm_mbox_key());
	debug_log(mbox_debug_fp,"catch_all_signals[%d]\n", catch_all_signals(&signal_handler));
    syslg("Mbox System Started\n");
	debug_log(mbox_debug_fp, "Mbox System Started\n");

	for( ;; )
	{
        debug_log(mbox_debug_fp,"Mbox System alive\n");
		mbox_shm_get_queue_stat();
	}
}

/************************************************************************************************************
* Name        : usage
* Description : See usage or programa
* Parameters  : ProgramName (argv[0])
* Return      : 1
*************************************************************************************************************/
int usage( char *programName )
{
	fprintf(stdout,"Usage : %s [options]\n", programName );
	fprintf(stdout,"Current Options for %s are :\n", programName );
	fprintf(stdout,"-start or -init                                       => Start Mailbox System\n");
	fprintf(stdout,"-stop                                                 => Stop Mailbox System and Remove all Queues\n");
	fprintf(stdout,"-release                                              => Release all Mailbox System Shared Memory and Queues\n");
	fprintf(stdout,"-list <mbid|mbname>                                   => List information of all mailboxes or a specific mailbox\n");
	fprintf(stdout,"-create <mbid|mbname>                                 => Create a New Mailbox\n");
	fprintf(stdout,"-clear <mbid|mbname>                                  => Remove all messages from a Mailbox\n");
	fprintf(stdout,"-read <mbid|mbname>                                   => Read a Single Message from a Mailbox\n");
	fprintf(stdout,"-send <mbid|mbname> <msgdata>                         => Send the Message setted in msgdata to a Mailbox\n");
	fprintf(stdout,"-lock <mbid|mbname>                                   => Lock read/write operations from a Mailbox\n");
	fprintf(stdout,"-unlock <mbid|mbname>                                 => Unlock read/write operations from a Mailbox\n");
	fprintf(stdout,"-delete <mbid|mbname>                                 => Disabled a Mailbox from Mailbox System\n");
	fprintf(stdout,"-addaction <mbid|mbname> <level> <command>            => Add a Action Script (Command) to Mailbox with a Level has been reached\n");
	fprintf(stdout,"-removeaction <mbid|mbname>                           => Remove a Action from a Mailbox\n");
	fprintf(stdout,"-view info or -viewinfo or -v info                    => Show Information about Mailbox System Shared Memory\n");
	fprintf(stdout,"-view key  or -viewkey  or -v key                     => Show Shared Memory Key for Mailbox System\n");
	fprintf(stdout,"-view mb   or -viewmb   or -v mb                      => List information of all mailboxes or about a specific mailbox (same as -list)\n");
	fprintf(stdout,"-view queued or -viewqueued -v queued                 => List information of all mailboxes with messages\n");
	fprintf(stdout,"-view lock or -viewlock or -v lock                    => List information of all mailboxes with Lock Indicator\n");
	fprintf(stdout,"-view deleted or -viewdeleted or -v deleted           => List information of all mailboxes with Deleted Flag\n");
	fprintf(stdout,"-view detail <mbid|mbname> or -v detail <mbid|mbname> => List Full information about a mailbox\n");
	fprintf(stdout,"-settime <timeinseconds>                              => Set Time in Seconds to Check Mailboxes health\n");
	exit(1);
}

/************************************************************************************************************
* Name        : parse_options
* Description : Execute the Parse of Command Line Options
* Parameters  : argc,  *argv[]
* Return      : 0 - Ok or < 0 - Parse Error
*************************************************************************************************************/
int parse_options( int argc, char *argv[] )
{
	int option_parsed;


	opterr = 0;

	if( argc == 1 ) return -1;

	while ( (option_parsed = getopt(argc, argv, "a:l:u:r:s:i:c:v:d:")) != -1 )
	{
		switch ( option_parsed )
		{
			case 'a':
				if( optarg == NULL ) return -1;
				mailboxFunctionParameter = optarg;
				SetCmdParam( "ddaction", ADD_ACTION_FUNCTION);
				if( mailboxFunction == -1 ) return(-1);				
				break;

			case 'r':
            	if( optarg == NULL ) return -1;
				mailboxFunctionParameter = optarg;
				SetCmdParam( "ead", READ_MSG_FUNCTION);
				SetCmdParam( "elease", RELEASE_FUNCTION);
				SetCmdParam( "emoveaction", REMOVE_ACTION);
				if( mailboxFunction == -1 ) return(-1);				
				break;

			case 's':
            	if( optarg == NULL ) return -1;
				mailboxFunctionParameter = optarg;
				SetCmdParam( "tart", START_FUNCTION);
				SetCmdParam( "top", STOP_FUNCTION);
				SetCmdParam( "end", SEND_MSG_FUNCTION);
				SetCmdParam( "etsleeptime", SET_SLEEP_FUNCTION);			
				if( mailboxFunction == -1 ) return(-1);				
				break;
			
            case 'i':
            	if( optarg == NULL ) return -1;
				mailboxFunctionParameter = optarg;
				SetCmdParam( "nit", START_FUNCTION);
				if( mailboxFunction == -1 ) return(-1);				
				break;

            case 'd':
            	if( optarg == NULL ) return -1;
				mailboxFunctionParameter = optarg;
				SetCmdParam( "etail", MB_DETAIL_FUNCTION);
				SetCmdParam( "elete", DELETE_FUNCTION);
				SetCmdParam( "ump", DUMP_FUNCTION);
				if( mailboxFunction == -1 ) return(-1);				
				break;

            case 'l':
            	if( optarg == NULL ) return -1;
				mailboxFunctionParameter = optarg;
				SetCmdParam( "ock", LOCK_FUNCTION);
				SetCmdParam( "ist", DEEP_FUNCTION);
				if( mailboxFunction == -1 ) return(-1);				
				break;

            case 'u':
            	if( optarg == NULL ) return -1;
				mailboxFunctionParameter = optarg;
				SetCmdParam( "nlock", UNLOCK_FUNCTION);
				if( mailboxFunction == -1 ) return(-1);				
				break;										

			case 'c':
            	if( optarg == NULL ) return -1;
				mailboxFunctionParameter = optarg;
				SetCmdParam( "reate", CREATE_FUNCTION);
				SetCmdParam( "lear", CLEAR_QUEUE_FUNCTION);
				if( mailboxFunction == -1 ) return(-1);				
                break;

			case 'v':
				if( optarg == NULL ) return -1;
				mailboxFunctionParameter = optarg;

				SetCmdParam( "key", KEY_FUNCTION);
				SetCmdParam( "info", MON_FUNCTION);
				SetCmdParam( "mb", DEEP_FUNCTION);
				SetCmdParam( "queued", QUEUED_FUNCTION);
				SetCmdParam( "lock", SEE_LOCK_FUNCTION);
				SetCmdParam( "deleted", SEE_DELETED_FUNCTION);
				
				SetCmdParam( "iewkey", KEY_FUNCTION);
				SetCmdParam( "iewinfo", MON_FUNCTION);
				SetCmdParam( "iewmb", DEEP_FUNCTION);
				SetCmdParam( "iewlock", SEE_LOCK_FUNCTION);
				SetCmdParam( "iewdeleted", SEE_DELETED_FUNCTION);

				if( mailboxFunction == -1 ) return(-1);
				break;

			case '?':
				return(-2);
		}
	}
	

	int indiceArg = optind;
	argvParameter1 = argv[indiceArg++];
	argvParameter2 = argv[indiceArg++];
	argvParameter3 = argv[indiceArg++];

	if(( mailboxFunction == SEND_MSG_FUNCTION || 
		 mailboxFunction == READ_MSG_FUNCTION || 
		 mailboxFunction == CREATE_FUNCTION   ||
		 mailboxFunction == DELETE_FUNCTION   ||
		 mailboxFunction == LOCK_FUNCTION     || 
		 mailboxFunction == UNLOCK_FUNCTION   ||
		 mailboxFunction == CLEAR_QUEUE_FUNCTION ||
		 mailboxFunction == ADD_ACTION_FUNCTION ||
		 mailboxFunction == REMOVE_ACTION ||
		 mailboxFunction == MB_DETAIL_FUNCTION ||
		 mailboxFunction == SET_SLEEP_FUNCTION ) && ( argvParameter1 == NULL))
		return -2;

	if(( mailboxFunction == START_FUNCTION  ||
	     mailboxFunction == STOP_FUNCTION ||
		 mailboxFunction == RELEASE_FUNCTION ||
		 mailboxFunction == QUEUED_FUNCTION ||
		 mailboxFunction == SEE_LOCK_FUNCTION || 
		 mailboxFunction == SEE_DELETED_FUNCTION ) && ( argvParameter1 != NULL))
		 return -3;

	if(( mailboxFunction == SEND_MSG_FUNCTION  ||
	     mailboxFunction == ADD_ACTION_FUNCTION ) && ( argvParameter2 == NULL))
		 return -3;

	if(( mailboxFunction == ADD_ACTION_FUNCTION ) && ( argvParameter3 == NULL))
		return -4;

	return(0);
}

/************************************************************************************************************
* Name        : mbox_start
* Description : Start Mailbox System
* Parameters  : None
* Return      : 0
*************************************************************************************************************/
int mbox_start( void )
{
	pid_t mboxHandle = fork();

	if( mboxHandle == 0 )
		mbox_handler();
	else
	{
		fprintf(stdout,"Current %s MBOX Handler : [%d]\n", PRODUCT_ALIAS, mboxHandle );
	}
	return(0);
}

/************************************************************************************************************
* Name        : mbox_stop
* Description : Stop Mailbox System
* Parameters  : None
* Return      : 0
*************************************************************************************************************/
int mbox_stop( void )
{
	int pid = -1;
	
	if(( pid = mbox_get_active_pid()) >= 0 )   /* Try to Kill Process */
		kill(pid,SIGTERM);

	exit(0);
}

/************************************************************************************************************
* Name        : mbox_release
* Description : Release all resource allocated to Mailbox System
* Parameters  : None
* Return      : 0
*************************************************************************************************************/
int mbox_release()
{
	int releaseRespCode = 0;

	/* Send Message do Debug Info */
	syslg( "Releasing Resources... Need to restart Mbox again\n" );

	/* Remove Queue */
	if ((releaseRespCode = mbox_remove_queues()) < 0)
		syslg( "Message queues could not be deleted [%d]. Errno [%d]\n", releaseRespCode, errno );	

	/* Remove SHM */
	if ((releaseRespCode = mbox_remove_shm()) < 0)
		syslg( "SHM could not be deleted [%d]. Errno [%d]\n", releaseRespCode, errno );

	/* Remove SHM */
	if ((releaseRespCode = mbox_remove_semaphore()) < 0)
		syslg( "Semaphore could not be deleted [%d]. Errno [%d]\n", releaseRespCode, errno );

	exit(0);
}

/************************************************************************************************************
* Name        : mbox_view_mon
* Description : Show Information about Main Mailbox System Shared Memory
* Parameters  : None
* Return      : 0
*************************************************************************************************************/
int mbox_view_mon() {
	mbox_shm_show_memory();
}

/************************************************************************************************************
* Name        : mbox_view_key
* Description : Show Key used to Main Mailbox System Shared Memory
* Parameters  : None
* Return      : 0
*************************************************************************************************************/
int mbox_view_key() {
	fprintf(stdout,"Current %s Mbox Key: [0x%x]\n", PRODUCT_ALIAS, get_shm_mbox_key());
	return(0);
}

/************************************************************************************************************
* Name        : mbox_view_key
* Description : List all Mailboxes with Deleted Status
* Parameters  : None
* Return      : 0
*************************************************************************************************************/
int mbox_deleted_mon()
{
	mbox_shm_show_queues(MAILBOX_DELETED);
}

/************************************************************************************************************
* Name        : mbox_lock_mon
* Description : List all Mailboxes with Locked Status
* Parameters  : None
* Return      : 0
*************************************************************************************************************/
int mbox_lock_mon()
{
	mbox_shm_show_queues(MAILBOX_LOCKED);
}

/************************************************************************************************************
* Name        : mbox_queued_mon
* Description : List all Mailboxes with Queued Status
* Parameters  : None
* Return      : 0
*************************************************************************************************************/
int mbox_queued_mon()
{
	mbox_shm_show_queues(MAILBOX_QUEUED);
}

/************************************************************************************************************
* Name        : mbox_runtime_create
* Description : Create a New Mailbox
* Parameters  : None
* Return      : 0
*************************************************************************************************************/
int mbox_runtime_create()
{
	int rc;
	syslg_arg0(MODULE_NAME);

	if(( rc = mbox_create(argvParameter1)) < 0 )
	{
		syslg( "Mbox Create Error [%s]. [%d] Errno [%d]\n", argvParameter1, rc, errno );
		fprintf(stderr,"E-%s-012 Mbox Create Error [%s]. [%d] Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, rc, errno );
		exit(1);
	}
	syslg("Mbox [%s] sucessfuly created. MboxID [%d]\n",  argvParameter1, rc );
	fprintf(stderr,"Mbox [%s] sucessfuly created. MboxID [%d]\n",  argvParameter1, rc );
	exit(0);
}

/************************************************************************************************************
* Name        : GetMailBox
* Description : Get MailBox from MailboxName according with Command Line Parameters
* Parameters  : None
* Return      : Mailbox Id ou < 0 (Error)
*************************************************************************************************************/
int GetMailBox()
{
	int mailboxID = -1;

	if( argvParameter1 == NULL)
		return (-1);
	if ( isNumeric(argvParameter1))
		mailboxID = atol(argvParameter1);
	else {
		if(( mailboxID = mbox_locate(argvParameter1)) < 0 )
		{
			return(-1);
		}	
	}
}


/************************************************************************************************************
* Name        : mbox_depth_mon
* Description : Show Information about Mailboxes according with Command Line Parameters
* Parameters  : None
* Return      : c
*************************************************************************************************************/
int mbox_depth_mon()
{
	int detailRespCode = -1;
	int mailboxID = -1;

	if( argvParameter1 != NULL ) {
		if(( mailboxID = GetMailBox()) < 0 )
		{
			fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
			debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
			exit(1);
		}
		fprintf(stdout, "Get Detailed Information about Mbox %d\n", mailboxID);

		if(( detailRespCode = mbox_info( mailboxID )) < 0)
		{
			fprintf(stderr,"E-%s-006 mbox_info error [%d]. Errno [%d]\n", PRODUCT_ALIAS, detailRespCode, errno );
			debug_log(syslg_debug_fp,"E-%s-006 mbox_info error [%d]. Errno [%d]\n", PRODUCT_ALIAS, detailRespCode, errno );
			exit(1);
		}	
	}
	else
	{
		mbox_shm_show_queues(MAILBOX_INUSE);
	}
	exit(0);
}

/************************************************************************************************************
* Name        : mbox_send_msg
* Description : Send a Message to a Single Mailbox according with Command Line Parameters
* Parameters  : None
* Return      : 0 - Ok or 1 - Error
*************************************************************************************************************/
int mbox_send_msg()
{
	int sendRespCode = 0;
	int mailboxID = -1;

	if(( mailboxID = GetMailBox()) < 0 )
	{
		fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		exit(1);
	}

	if ( argvParameter2 == NULL ) {
			fprintf(stderr,"E-%s-008 Message not setted\n", PRODUCT_ALIAS );
			debug_log(syslg_debug_fp,"E-%s-008 Message not setted\n", PRODUCT_ALIAS );
			exit(1);
	}

	fprintf(stdout, "Sending message [%s] to Mbox %d\n", argvParameter2, mailboxID);

	if(( sendRespCode = mbox_write(mailboxID,argvParameter2,strlen(argvParameter2))) < 0)
	{
		fprintf(stderr,"E-%s-006 mbox_write error [%d]. Errno [%d]\n", PRODUCT_ALIAS, sendRespCode, errno );
		debug_log(syslg_debug_fp,"E-%s-006 mbox_write error [%d]. Errno [%d]\n", PRODUCT_ALIAS, sendRespCode, errno );
		exit(1);
    }
	syslg("Message sucessfully sended to Mbox [%s]. MboxID [%d]\n",  argvParameter1, sendRespCode );
	fprintf(stderr,"Message sucessfully sended to Mbox [%s]. MboxID [%d]\n",  argvParameter1, sendRespCode );
 	exit(0);
}

/************************************************************************************************************
* Name        : mbox_read_msg
* Description : Read a Single Message from a Mailbox according with Command Line Parameters
* Parameters  : None
* Return      : 0 - Ok or 1 - Error
*************************************************************************************************************/
int mbox_read_msg()
{
	int readLength = 0;
	int mailboxID = -1;
	shm_mbox_message mailboxBuffer = {0};

	if(( mailboxID = GetMailBox()) < 0 )
	{
		fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		exit(1);
	}

	if( mbox_has_messages( mailboxID ) == 0 )
	{
		fprintf(stderr,"E-%s-011 Mbox [%s] has no messages. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		debug_log(syslg_debug_fp,"E-%s-011 Mbox [%s] has no messages. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		exit(1);
	}

	fprintf(stdout, "Reading a message from Mbox %d\n", mailboxID);

	if(( readLength = mbox_read( mailboxID, (char *)&mailboxBuffer.messageBuffer, sizeof(mailboxBuffer.messageBuffer) )) < 0)
	{
		fprintf(stderr,"E-%s-006 mbox_read error [%d]. Errno [%d]\n", PRODUCT_ALIAS, readLength, errno );
		debug_log(syslg_debug_fp,"E-%s-006 mbox_read error [%d]. Errno [%d]\n", PRODUCT_ALIAS, readLength, errno );
		exit(1);
    }
	syslg("Message sucessfully readed from Mbox [%s]\n",  argvParameter1 );
	fprintf(stderr,"Message sucessfully readed from Mbox [%s]\n",  argvParameter1 );
	fprintf(stderr,"%s\n",DumpHex("Read Buffer", (void*) &mailboxBuffer.messageBuffer, readLength).c_str());
 	exit(0);
}

/************************************************************************************************************
* Name        : mbox_runtime_lock
* Description : Lock a Single Mailbox according with Command Line Parameters
* Parameters  : None
* Return      : 0 - Ok or 1 - Error
*************************************************************************************************************/
int mbox_runtime_lock()
{
	int lockRespCode = 0;
	int mailboxID = -1;
	
	if(( mailboxID = GetMailBox()) < 0 )
	{
		fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		exit(1);
	}

	fprintf(stdout, "Locking Mbox %d\n", mailboxID);

	if(( lockRespCode = mbox_lock( mailboxID )) < 0)
	{
		fprintf(stderr,"E-%s-006 mbox_lock error [%d]. Errno [%d]\n", PRODUCT_ALIAS, lockRespCode, errno );
		debug_log(syslg_debug_fp,"E-%s-006 mbox_lock error [%d]. Errno [%d]\n", PRODUCT_ALIAS, lockRespCode, errno );
		exit(1);
    }
	syslg("Mbox sucessfully locked [%s]\n",  argvParameter1 );
	fprintf(stderr,"Mbox sucessfully locked [%s]\n",  argvParameter1 );
 	exit(0);
}

/************************************************************************************************************
* Name        : mbox_runtime_lock
* Description : Unlock a Single Mailbox according with Command Line Parameters
* Parameters  : None
* Return      : 0 - Ok or 1 - Error
*************************************************************************************************************/
int mbox_runtime_unlock()
{
	int unlockRespCode = 0;
	int mailboxID = -1;
	
	if(( mailboxID = GetMailBox()) < 0 )
	{
		fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		exit(1);
	}

	fprintf(stdout, "Unlocking Mbox %d\n", mailboxID);

	if(( unlockRespCode = mbox_unlock( mailboxID )) < 0)
	{
		fprintf(stderr,"E-%s-006 mbox_unlock error [%d]. Errno [%d]\n", PRODUCT_ALIAS, unlockRespCode, errno );
		debug_log(syslg_debug_fp,"E-%s-006 mbox_unlock error [%d]. Errno [%d]\n", PRODUCT_ALIAS, unlockRespCode, errno );
		exit(1);
    }
	syslg("Mbox sucessfully unlocked [%s]\n",  argvParameter1 );
	fprintf(stderr,"Mbox sucessfully unlocked [%s]\n",  argvParameter1 );
 	exit(0);
}

/************************************************************************************************************
* Name        : mbox_runtime_delete
* Description : Delete a Single Mailbox according with Command Line Parameters
* Parameters  : None
* Return      : 0 - Ok or 1 - Error
*************************************************************************************************************/
int mbox_runtime_delete()
{
	int deleteRespCode = 0;
	int mailboxID = -1;
	
	if(( mailboxID = GetMailBox()) < 0 )
	{
		fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		exit(1);
	}

	fprintf(stdout, "Deleting Mbox %d\n", mailboxID);

	if(( deleteRespCode = mbox_delete( mailboxID )) < 0)
	{
		fprintf(stderr,"E-%s-006 mbox_deleted error [%d]. Errno [%d]\n", PRODUCT_ALIAS, deleteRespCode, errno );
		debug_log(syslg_debug_fp,"E-%s-006 mbox_deleted error [%d]. Errno [%d]\n", PRODUCT_ALIAS, deleteRespCode, errno );
		exit(1);
    }
	syslg("Mbox sucessfully deleted [%s]\n",  argvParameter1 );
	fprintf(stderr,"Mbox sucessfully deleted [%s]\n",  argvParameter1 );
 	exit(0);
}


/************************************************************************************************************
* Name        : mbox_detail
* Description : Show details of a Single Mailbox according with Command Line Parameters
* Parameters  : None
* Return      : 0 - Ok or 1 - Error
*************************************************************************************************************/
int mbox_detail()
{
	int detailRespCode = 0;
	int mailboxID = -1;
	
	if(( mailboxID = GetMailBox()) < 0 )
	{
		fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		exit(1);
	}

	fprintf(stdout, "Get Detailed Information about Mbox %d\n", mailboxID);

	if(( detailRespCode = mbox_info( mailboxID )) < 0)
	{
		fprintf(stderr,"E-%s-006 mbox_info error [%d]. Errno [%d]\n", PRODUCT_ALIAS, detailRespCode, errno );
		debug_log(syslg_debug_fp,"E-%s-006 mbox_info error [%d]. Errno [%d]\n", PRODUCT_ALIAS, detailRespCode, errno );
		exit(1);
    }
 	exit(0);
}

/************************************************************************************************************
* Name        : mbox_clear_queue_msg
* Description : Clear all messagues of a Single Mailbox according with Command Line Parameters
* Parameters  : None
* Return      : 0 - Ok or 1 - Error
*************************************************************************************************************/
int mbox_clear_queue_msg()
{
	int clearRespCode = 0;
	int mailboxID = -1;
	
	if(( mailboxID = GetMailBox()) < 0 )
	{
		fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		exit(1);
	}

	fprintf(stdout, "Clearing Mbox %d\n", mailboxID);

	if(( clearRespCode = mbox_clear_queue( mailboxID, MAILBOX_CLEAR_NO_SILENCE )) < 0)
	{
		fprintf(stderr,"E-%s-006 mbox_clear_queue error [%d]. Errno [%d]\n", PRODUCT_ALIAS, clearRespCode, errno );
		debug_log(syslg_debug_fp,"E-%s-006 mbox_clear_queue error [%d]. Errno [%d]\n", PRODUCT_ALIAS, clearRespCode, errno );
		exit(1);
    }
	syslg("Mbox sucessfully cleared [%s]\n",  argvParameter1 );
	fprintf(stderr,"Mbox sucessfully cleared [%s]\n",  argvParameter1 );
 	exit(0);
}

/************************************************************************************************************
* Name        : mbox_runtime_remove_action
* Description : Remove a action from a Single Mailbox according with Command Line Parameters
* Parameters  : None
* Return      : 0 - Ok or 1 - Error
*************************************************************************************************************/
int mbox_runtime_remove_action()
{
	int removeRespCode = 0;
	int mailboxID = -1;

	if(( mailboxID = GetMailBox()) < 0 )
	{
		fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		exit(1);
	}

	fprintf(stdout, "Remove action from Mbox [%s]\n", argvParameter1);

	if(( removeRespCode = mbox_remove_action(mailboxID)) < 0)
	{
		fprintf(stderr,"E-%s-006 mbox_remove_action error [%d]. Errno [%d]\n", PRODUCT_ALIAS, removeRespCode, errno );
		debug_log(syslg_debug_fp,"E-%s-006 mbox_remove_action error [%d]. Errno [%d]\n", PRODUCT_ALIAS, removeRespCode, errno );
		exit(1);
    }
	syslg("Action removed from Mbox [%s]. MboxID [%d]\n",  argvParameter1, mailboxID );
	fprintf(stderr,"Action removed from Mbox [%s]. MboxID [%d]\n",  argvParameter1, mailboxID );
 	exit(0);
}

/************************************************************************************************************
* Name        : mbox_runtime_add_action
* Description : Add a action from a Single Mailbox according with Command Line Parameters
* Parameters  : None
* Return      : 0 - Ok or 1 - Error
*************************************************************************************************************/
int mbox_runtime_add_action()
{
	int addRespCode = 0;
	int mailboxID = -1;
	int level = 0;

	if(( mailboxID = GetMailBox()) < 0 )
	{
		fprintf(stderr,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		debug_log(syslg_debug_fp,"E-%s-007 Mbox [%s] not located. Errno [%d]\n", PRODUCT_ALIAS, argvParameter1, errno );
		exit(1);
	}

	if ( argvParameter2 == NULL ) {
			fprintf(stderr,"E-%s-008 Level not informed\n", PRODUCT_ALIAS );
			debug_log(syslg_debug_fp,"E-%s-008 Level not informed\n", PRODUCT_ALIAS );
			exit(1);
	} else {
		if ( isNumeric(argvParameter2))
			level = atol(argvParameter2);
		if ( level <= 0 )
		{
			fprintf(stderr,"E-%s-009 Level incorrect\n", PRODUCT_ALIAS );
			debug_log(syslg_debug_fp,"E-%s-00 Level incorrect\n", PRODUCT_ALIAS );
			exit(1);
		}
	}

	if ( argvParameter3 == NULL ) {
			fprintf(stderr,"E-%s-008 CommandLine not informed\n", PRODUCT_ALIAS );
			debug_log(syslg_debug_fp,"E-%s-008 CommandLine not informed\n", PRODUCT_ALIAS );
			exit(1);
	}

	fprintf(stdout, "Adding a action to Mbox [%s]\n", argvParameter2);

	if(( addRespCode = mbox_add_action(mailboxID,level,argvParameter3)) < 0)
	{
		fprintf(stderr,"E-%s-006 mbox_add_action error [%d]. Errno [%d]\n", PRODUCT_ALIAS, addRespCode, errno );
		debug_log(syslg_debug_fp,"E-%s-006 mbox_add_action error [%d]. Errno [%d]\n", PRODUCT_ALIAS, addRespCode, errno );
		exit(1);
    }
	syslg("Action added to Mbox [%s].\n",  argvParameter1 );
	fprintf(stderr,"Action added to Mbox [%s].\n",  argvParameter1 );
 	exit(0);
}

/************************************************************************************************************
* Name        : mbox_clear_stat_msg
* Description : CleanUp the Statistics from a Single Mailbox according with Command Line Parameters
* Parameters  : None
* Return      : 0 - Ok or 1 - Error
*************************************************************************************************************/
int mbox_clear_stat_msg()
{
    
}

/************************************************************************************************************
* Name        : mbox_dump
* Description : Dump all Memory Information
* Parameters  : None
* Return      : 0 - Ok or 1 - Error
*************************************************************************************************************/
int mbox_dump_shm()
{
	shmHeader = get_mbox_shm_stat ();
	fprintf(stdout,DumpHex("Dumping SHM", (void*) shmHeader,get_total_shm_len()).c_str());
    exit(0);
}


/************************************************************************************************************
* Name        : main
* Description : Main Function of mboxcmd 
* Parameters  : argc e *argv[]
* Return      : 0 - Ok or 1 - Error
*************************************************************************************************************/
int main(int argc, char *argv[])
{
	char* shmid;
	char* cfgName;
	char *progName;

	fprintf(stderr,"%s %s compiled at %s %s\n=======================================================================\n", MODULE_NAME,MODULE_VERSION,__DATE__,__TIME__);
	progName = basename( argv[0] );

	if( parse_options( argc, argv ) < 0)
		return usage(progName);

	shmid = getenv (PRODUCT_SHM_VAR);

	if (shmid == NULL) {
		fprintf(stderr,"E-%s-001 Variable %s not setted\n", PRODUCT_ALIAS, PRODUCT_SHM_VAR );
		exit(1);
	}

	cfgName = getenv (PRODUCT_CFG_VAR);

	if (cfgName == NULL) {
		fprintf(stderr,"E-%s-002 Variable %s not setted\n", PRODUCT_ALIAS, PRODUCT_CFG_VAR );
		exit(1);
	}

	if( cf_open( cfgName ) < 0 )
	{
		fprintf(stderr,"E-%s-003 Error to open Configuration File [%s]\n", PRODUCT_ALIAS, PRODUCT_CFG_VAR );
		exit(1);
	}

	syslg_arg0(MODULE_NAME);	

	switch ( mailboxFunction )
	{
		case START_FUNCTION :
			mbox_start();
			mbox_view_key();
			fprintf(stdout,"Current %s Region : [%s]\n",PRODUCT_ALIAS, shmid);
			fprintf(stdout,"Current %s Configuration : [%s]\n",PRODUCT_ALIAS, cfgName);
			break;
			
		case STOP_FUNCTION :
			mbox_stop();
			break;

		case RELEASE_FUNCTION :
			mbox_release();
			break;			
			
		case MON_FUNCTION :
			mbox_view_mon();
			break;
			
		case KEY_FUNCTION :
			mbox_view_key();
			break;
			
		case SEE_DELETED_FUNCTION :
			mbox_deleted_mon();
			break;

		case SEE_LOCK_FUNCTION :
			mbox_lock_mon();
			break;

		case QUEUED_FUNCTION :
			mbox_queued_mon();
			break;						

        case DEEP_FUNCTION :
            mbox_depth_mon();
            break;

    	case CREATE_FUNCTION :
            mbox_runtime_create();
            break;
		
		case SEND_MSG_FUNCTION :
            mbox_send_msg();
            break;

    	case READ_MSG_FUNCTION :
            mbox_read_msg();
            break;

		case LOCK_FUNCTION :
			mbox_runtime_lock();
			break;
		
		case UNLOCK_FUNCTION :
			mbox_runtime_unlock();
			break;

		case DELETE_FUNCTION :
			mbox_runtime_delete();
			break;

		case MB_DETAIL_FUNCTION :
			mbox_detail();
    
    	case CLEAR_QUEUE_FUNCTION :
            mbox_clear_queue_msg();
            break;

		case REMOVE_ACTION:
			mbox_runtime_remove_action();
			break;

		case ADD_ACTION_FUNCTION:
			mbox_runtime_add_action();
			break;

    	case CLEAR_STAT_FUNCTION :
            mbox_clear_stat_msg();
            break;

   		case DUMP_FUNCTION :
            mbox_dump_shm();
            break;
			
    }

	exit(0);
}
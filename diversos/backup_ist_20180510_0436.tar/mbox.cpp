#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include <string.h>
#include <cstdlib>

#define MSGSZ     128

char msg[MSGSZ] = {0};

/*
 * Declare the message structure.
 */
struct message_buf {
         long    mtype;
         char    mtext[MSGSZ];
}; 

void rcvmsg( void ) {
	int msqid;
    key_t key;
    struct message_buf  rbuf;

    /*
     * Get the message queue id for the
     * "name" 1234, which was created by
     * the server.
     */
    key = 1234;
	
	printf("msqid [%d]\n", msqid );

    if ((msqid = msgget(key, 0666)) < 0) {
        perror("msgget");
        return;
    }
	
	printf("msqid [%d]\n", msqid );

    
    /*
     * Receive an answer of message type 1.
     */
    if (msgrcv(msqid, &rbuf, MSGSZ, 1, 0) < 0) {
        perror("msgrcv");
    }

    /*
     * Print the answer.
     */
    printf("%s\n", rbuf.mtext);
	
}

void sendmsg( void ) {
    int msqid;
    int msgflg = IPC_CREAT | 0666;
	
    key_t key;
    struct message_buf sbuf;
    size_t buf_length;

    /*
     * Get the message queue id for the
     * "name" 1234, which was created by
     * the server.
     */
    key = 1234;

	(void) fprintf(stderr, "\nmsgget: Calling msgget(%#lx,%#o)\n",key, msgflg);

    if ((msqid = msgget(key, msgflg )) < 0) {
        perror("msgget");
    }
    else 
     (void) fprintf(stderr,"msgget: msgget succeeded: msqid = %d\n", msqid);


    /*
     * We'll send message type 1
     */
     
    sbuf.mtype = 1;
    
    (void) fprintf(stderr,"msgget: msgget succeeded: msqid = %d\n", msqid);
    
    (void) strcpy(sbuf.mtext, msg);
    
    (void) fprintf(stderr,"msgget: msgget succeeded: msqid = %d\n", msqid);
    
    buf_length = strlen(sbuf.mtext) + 1 ;
    
    

    /*
     * Send a message.
     */
    if (msgsnd(msqid, &sbuf, buf_length, IPC_NOWAIT) < 0) {
       printf ("%d, %d, %s, %d\n", msqid, sbuf.mtype, sbuf.mtext, buf_length);
        perror("msgsnd");
    }
    else 
      printf("Message: \"%s\" Sent\n", sbuf.mtext);
 	return;
}

int main(int argc, char* argv[])
{
	system("date");
	printf("Compilado em [%s] [%s]\n", __DATE__, __TIME__ );
	if( argc < 2 ) {
		printf("Try to send a message : %s S <msg>\n", argv[0] );
		return(1);
	}
	printf("[%s]\n", argv[1][0] == 'S' ? "Sending" : "Reading" );
	if( argv[1][0] == 'S' )
	{
		strcpy(msg,argv[2]);
		sendmsg();
	}
	else
	{
		rcvmsg();
	}
	return(0);
}
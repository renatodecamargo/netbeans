#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdarg.h>
#include <time.h>
#include <signal.h>

#include "ist_functions.h"
#include "misc_functions.h"
#include "syslg.h"

/* IST Like */

int cf_open( const char *filename ) {
	if( !cf_opened ){
		cf_param = fopen( filename, "r+t");
		if (cf_param == NULL)
			return (-1);
		cf_opened = true;
		cf_current_line = 0;
	}
	return (0);
}

int cf_locate( const char *keyentry, char *data ) {
	char line[MAX_IST_STRING] = {0};
	char *position;

	if( !cf_opened )
		return(-1);
	
	fseek ( cf_param , 0 , SEEK_SET );

	while(fgets(line,sizeof(line),cf_param))
	{
		//printf("[%s]\n",line);
		position = strchr(line,'\n');
		*position = 0;
		cf_current_line++;
		position = strstr(line,keyentry);
		if( position && line[0] != '#')
		{
			while( *(position+strlen(keyentry)) == ' ') position++;
			strcpy( data, position+strlen(keyentry));
			return(cf_current_line);
		}
	}
	return (-1);
}

int cf_locatenum( const char *keyentry, int *data ) {
	char line[MAX_IST_STRING] = {0};
	char *position;

	if( !cf_opened )
		return(-1);
	
	fseek ( cf_param , 0 , SEEK_SET );

	/*fprintf(stdout,"[%s]:%d\n",keyentry,strlen(keyentry));*/
	while(fgets(line,sizeof(line),cf_param))
	{
		position = strchr(line,'\n');
		*position = 0;		
		cf_current_line++;
		position = strstr(line,keyentry);
		if( position && line[0] != '#')
		{
			/*fprintf(stdout,"%s\n",line);*/
			while( *(position+strlen(keyentry)) == ' ') position++;
			/*fprintf(stdout,"%s =%d <=> %d\n",position+strlen(keyentry),position,strlen(keyentry));*/
			sscanf( position+strlen(keyentry), "%d", data);
			/*fprintf(stdout,"%d\n",*data);*/
			return(cf_current_line);
		}
	}
	return (-1);
}

int cf_nextparm( const char *keyentry, char *data ) {
	char line[MAX_IST_STRING] = {0};
	char *position;

	if( !cf_opened )
		return(-1);

	while(fgets(line,sizeof(line),cf_param))
	{
		position = strchr(line,'\n');
		*position = 0;		
		cf_current_line++;
		position = strstr(line,keyentry);
		if( position && line[0] != '#')
		{
			while( *(position+strlen(keyentry)) == ' ') position++;
			strcpy( data, position+strlen(keyentry));
			return(cf_current_line);
		}
	}
	return (-1);
}

int cf_close( void ) {
	
	if( !cf_opened )
		return(-1);

	fclose( cf_param );
	
	cf_opened = false;
}

int catch_all_signals(  void (*signal_handler )(int) )
{
    if (signal(SIGUSR1, signal_handler) == SIG_ERR)
        return(-1);
    if (signal(SIGTERM, signal_handler) == SIG_ERR)
        return(-2);
    if (signal(SIGINT, signal_handler) == SIG_ERR)
        return(-4);
    if (signal(SIGQUIT, signal_handler) == SIG_ERR)
        return(-5);
    if (signal(SIGSEGV, signal_handler) == SIG_ERR)
        return(-6);
    if (signal(SIGTSTP, signal_handler) == SIG_ERR)
        return(-7);			
    if (signal(SIGUSR2, signal_handler) == SIG_ERR)
        return(-8);		
    if (signal(SIGXCPU, signal_handler) == SIG_ERR)
        return(-9);			
    if (signal(SIGXFSZ, signal_handler) == SIG_ERR)
        return(-10);
    if (signal(SIGBUS, signal_handler) == SIG_ERR)
        return(-11);		
    if (signal(SIGALRM, signal_handler) == SIG_ERR)
        return(-12);	
    if (signal(SIGABRT, signal_handler) == SIG_ERR)
        return(-13);			
}
/* Standard Includes */
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/errno.h>
#include <sys/errno.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/stat.h>
#include <assert.h>
#include <string>

/* Product Includes */
#include "mailbox.h"
#include "ist_functions.h"
#include "misc_functions.h"
#include "gen_functions.h"

using namespace std;


/************************************************************************************************************
* Name        : get_mbox_shm_stat
* Description : Attach Mailbox Header System
* Parameters  : None
* Return      : Pointer to shm_mbox_system_header structure
*************************************************************************************************************/
shm_mbox_system_header * get_mbox_shm_stat ( void ) 
{
	int sharedMemoryId = shmget( get_shm_mbox_key(), 0, S_IWUSR|S_IRUSR );

	if( sharedMemoryId == -1 )
		return NULL;		/* Shared memory not Found */

	return (shm_mbox_system_header *)shmat( sharedMemoryId, NULL, 0 );
}

/************************************************************************************************************
* Name        : mbox_shm_create_memory
* Description : Create Main Memory. 
* Parameters  : Pointer to Pointer of shm_mbox_system_header sctructure
* Return      : Shared Memory ID or Mailbox defined error
*************************************************************************************************************/
int mbox_shm_create_memory( shm_mbox_system_header **sharedMemoryPointer )
{
	/* Create Shared Memory */
	register key_t shmKey = get_shm_mbox_key();
	size_t shmSize = get_total_shm_len();

	int sharedMemoryId = shmget( shmKey, shmSize, IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR );
	
	if( sharedMemoryId == -1 )
	{
		if( errno == EEXIST )
		{
			/* A shared memory ja existe, deve ser eliminada */
			sharedMemoryId = shmget( shmKey, 1, S_IRUSR | S_IWUSR );
			if( sharedMemoryId == -1 )
				return MB_ERR_GET_SHM_FAILED;

			if( shmctl(sharedMemoryId, IPC_RMID, 0) == -1 )
				return MB_ERR_CTL_RM_SHM_FAILED;
			else
				return mbox_shm_create_memory( sharedMemoryPointer ); /* try to create again */
		}
		return MB_ERR_CREATE_SHM_FAILED;
	}
	
	/* Attach to Memory */
	*sharedMemoryPointer = (shm_mbox_system_header *) shmat( sharedMemoryId, NULL, 0 );
	
	/* CleanUp Memory */
	memset( *sharedMemoryPointer, 0, sizeof(shm_mbox_system_header));
    
	/* Set Max of Mailbox Buffers */
	(*sharedMemoryPointer)->buff_qty = get_shm_buff_qty();

	return sharedMemoryId;
}

/************************************************************************************************************
* Name        : mbox_shm_create_semaphore
* Description : Create Semaphore to Control Shared Memory Main Struct. 
* Parameters  : None
* Return      : Sempahore ID or Mailbox defined error
*************************************************************************************************************/
int mbox_shm_create_semaphore()
{
	int returnCode;
    register key_t semaphoreKey = get_shm_mbox_key();
	int semaphoreId = semget( semaphoreKey, 1, IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR );
	if( semaphoreId == -1 )
	{
		if( errno == EEXIST )
		{
			/* O semaforo ja existe, deve ser eliminado */
			semaphoreId = semget( semaphoreKey, 1, S_IRUSR | S_IWUSR );
			if( semaphoreId == -1 )
				return MB_ERR_GET_SEM_FAILED;
			
			returnCode = semctl( semaphoreId, 0, IPC_RMID, NULL );
			if( returnCode != 0 )
				return MB_ERR_CTL_RM_SEM_FAILED;
			else
				return mbox_shm_create_semaphore(); /* try to create again */
		}
		return MB_ERR_CREATE_SEM_FAILED;
	}
	return semaphoreId;
}

/************************************************************************************************************
* Name        : mbox_shm_format_memory
* Description : Format the Main Shared Memory with the default data
* Parameters  : None
* Return      : 0
*************************************************************************************************************/
int mbox_shm_format_memory( shm_mbox_system_header *sharedMemory )
{
	assert( sharedMemory != NULL );

	sharedMemory->signature = MAILBOX_HEADER_SIGNATURE;
	sharedMemory->pid = getpid();
	sharedMemory->timestamp = get_timestamp();
    sharedMemory->buff_qty = get_shm_buff_qty();
    sharedMemory->buff_len = get_shm_buff_len();
    sharedMemory->lastindex = 0;
	sharedMemory->sleeptime = DEFAULT_SLEEP_TIME;

	/* For each member, set the default values */
	for( int indiceMB = 0; indiceMB < sharedMemory->buff_qty; indiceMB++ )
	{
		shm_mbox_header *shmMailbox = get_mbox_index_header( indiceMB, sharedMemory );
		shmMailbox->signature = MAILBOX_SIGNATURE;
		shmMailbox->status = MAILBOX_FREE;
        shmMailbox->msqid = -1;
        shmMailbox->mbid = -1;
		shmMailbox->maxmsg = 0;
	}
	return (0);
}

/************************************************************************************************************
* Name        : mbox_shm_init_semaphore
* Description : Initialize the Semaphore Set
* Parameters  : SemaphoreId
* Return      : 0 or Mailbox defined error
*************************************************************************************************************/
int mbox_shm_init_semaphore( int semaphoreId )
{
	int returnCode = 0;
	static struct sembuf semaphoreOperations[1];

	/* Inicializar semaforo */
    semaphoreOperations[0].sem_num = 0;
    semaphoreOperations[0].sem_op = 1;
    semaphoreOperations[0].sem_flg = 0;
    returnCode = semop( semaphoreId, semaphoreOperations, 1 );

	if( returnCode != 0 )
		return MB_ERR_SEMOP_INIT_FAILED;     /* Erro ao tentar liberar o semaforo */

	return(0);
}

/************************************************************************************************************
* Name        : mbox_shm_show_memory
* Description : Show Main Shared Memory Struct
* Parameters  : None
* Return      : 0 or Mailbox defined error
*************************************************************************************************************/
int mbox_shm_show_memory()
{
	struct shmid_ds ipcStat = {0};
	
	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();
	
	if( shmHeader == NULL )
		return MB_ERR_GET_SHM_FAILED;
		
	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	if ( shmctl(shmHeader->shmid,IPC_STAT, &ipcStat) == -1)
		return MB_ERR_CTL_STAT_SHM_FAILED;

	fprintf(stdout,"================ SHM INFORMATION ========================\n");
	fprintf(stdout,"Signature    : 0x%x\n", shmHeader->signature);
	fprintf(stdout,"SHM ID       : %d\n",   shmHeader->shmid);
	fprintf(stdout,"Semaphore ID : %d\n",   shmHeader->semid);
	fprintf(stdout,"PID          : %d\n",   shmHeader->pid);
    fprintf(stdout,"MBox in Use  : %d\n",   shmHeader->lastindex);
    fprintf(stdout,"Max MBox     : %d\n",   shmHeader->buff_qty);
    fprintf(stdout,"Owner ID     : %d\n",   ipcStat.shm_perm.uid);
	fprintf(stdout,"Owner Group  : %d\n",   ipcStat.shm_perm.gid);
	fprintf(stdout,"Creator ID   : %d\n",   ipcStat.shm_perm.cuid);
	fprintf(stdout,"Creator Group: %d\n",   ipcStat.shm_perm.cgid);
	fprintf(stdout,"Access Mode  : %d\n",   ipcStat.shm_perm.mode);
	fprintf(stdout,"Size         : %d\n",   ipcStat.shm_segsz);
	fprintf(stdout,"Creator PID  : %d\n",   ipcStat.shm_cpid);
	fprintf(stdout,"Last PID     : %d\n",   ipcStat.shm_lpid);
	fprintf(stdout,"Uptime       : %s\n",   get_formatted_timestamp(shmHeader->timestamp).c_str());
	fprintf(stdout,"=========================================================\n");
	
	return(0);
}

/************************************************************************************************************
* Name        : mbox_locate
* Description : Locate mailbox according with MailBox Name
* Parameters  : Mailbox Name
* Return      : MailboxId or Mailbox defined error
*************************************************************************************************************/
int mbox_locate( char *nameMailbox )
{
	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();

	if (shmHeader == NULL)
		return MB_ERR_GET_SHM_FAILED;

	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */
	
	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */	

	for( int indiceMB = 0; indiceMB < shmHeader->lastindex; indiceMB ++ )
	{
		shm_mbox_header *mailboxHeader = get_mbox_index_header( indiceMB, shmHeader );

		if( !strcmp(mailboxHeader->mbname,nameMailbox))
			return(mailboxHeader->mbid);
	}
	/* Not Found */
	return MB_ERR_MB_NOT_FOUND;
}

/************************************************************************************************************
* Name        : mbox_has_messages
* Description : Check with Mailbox have same messages
* Parameters  : Mailbox ID
* Return      : Number of Messages or Mailbox defined error
*************************************************************************************************************/
int mbox_has_messages( int mailboxId )
{
	struct msqid_ds ipcStat;

	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();

	if (shmHeader == NULL)
		return MB_ERR_GET_SHM_FAILED;

	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */
	
	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */
	
	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, shmHeader );

	/* Signature Ok ? */
	if( mailboxHeader->signature != MAILBOX_SIGNATURE )
		return MB_ERR_MBSIGNATURE_SHM_FAILED;

	/* Get Information of Mailbox */
	if ( msgctl( mailboxHeader->msqid, IPC_STAT, &ipcStat ) == -1 )
		return MB_ERR_CTL_STAT_MB_FAILED;

	return ( ipcStat.msg_qnum );
}

/************************************************************************************************************
* Name        : mbox_add_action
* Description : Add some Action Script to Mailbox if a certain level has been reached
* Parameters  : Mailbox ID
*               Mailbox Trigger Level
*               Command to Execute
* Return      : 0 or Mailbox defined error
*************************************************************************************************************/
int mbox_add_action( int mailboxId, int level, char *commandAction )
{
	int actionFound = 0;

	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();
	
	if( shmHeader == NULL )
		return MB_ERR_GET_SHM_FAILED;
		
	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, shmHeader );
	
	if( mailboxHeader->signature != MAILBOX_SIGNATURE )
			return MB_ERR_MBSIGNATURE_SHM_FAILED;

	if(mailboxHeader->msqid < 0 || mailboxHeader->mbid < 0)
		return MB_ERR_MBID_INVALID;

	if(mailboxHeader->status & MAILBOX_LOCKED)
		return MB_ERR_MBID_LOCKED;

	if(mailboxHeader->status & MAILBOX_DELETED)
		return MB_ERR_MBID_DELETED;	

	if(mailboxHeader->status & MAILBOX_CRASHED)
		return MB_ERR_MBID_CRASHED;

	if(mailboxHeader->status == MAILBOX_FREE)
		return MB_ERR_MB_NOT_INUSE;

	if( mailboxHeader->action[0].level != MAILBOX_NOLEVEL)
		return MB_ERR_NO_LEVEL_AVALIABLE;				

	if( sem_P(shmHeader->semid) != 0 )  /* P Operation */
		return MB_ERR_SEMOP_P_FAILED; 		

	mailboxHeader->action[0].level = level;
	strcpy(mailboxHeader->action[0].action, (const char *)commandAction);
	mailboxHeader->action[0].triggerOn = MAILBOX_TRIGGER_OFF;
	mailboxHeader->action[0].execution = 0;

	if( sem_V(shmHeader->semid) != 0 )	/* V Operation */
		return MB_ERR_SEMOP_V_FAILED;		

	return(0);
}

/************************************************************************************************************
* Name        : mbox_remove_action
* Description : Remove a Action Script from Mailbox
* Parameters  : Mailbox ID
* Return      : 0 or Mailbox defined error
*************************************************************************************************************/
int mbox_remove_action( int mailboxId )
{
	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();
	
	if( shmHeader == NULL )
		return MB_ERR_GET_SHM_FAILED;
		
	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, shmHeader );
	
	if( mailboxHeader->signature != MAILBOX_SIGNATURE )
			return MB_ERR_MBSIGNATURE_SHM_FAILED;

	if(mailboxHeader->msqid < 0 || mailboxHeader->mbid < 0)
		return MB_ERR_MBID_INVALID;

	if(!(mailboxHeader->status & MAILBOX_LOCKED))
		return MB_ERR_MB_NOT_LOCKED;

	if(mailboxHeader->status & MAILBOX_DELETED)
		return MB_ERR_MBID_DELETED;	

	if(mailboxHeader->status & MAILBOX_CRASHED)
		return MB_ERR_MBID_CRASHED;

	if(mailboxHeader->status == MAILBOX_FREE)
		return MB_ERR_MB_NOT_INUSE;

	if ( mailboxHeader->action[0].level == MAILBOX_NOLEVEL)
		return MB_ERR_LEVEL_NOT_SETTED;		

	if( sem_P(shmHeader->semid) != 0 )  /* P Operation */
		return MB_ERR_SEMOP_P_FAILED; 		

	/* Update SHM */
	mailboxHeader->action[0].level = MAILBOX_NOLEVEL;
	mailboxHeader->action[0].action[0] = 0;
	mailboxHeader->action[0].triggerOn = MAILBOX_TRIGGER_OFF;
	mailboxHeader->action[0].execution = 0;	

	if( sem_V(shmHeader->semid) != 0 )	/* V Operation */
		return MB_ERR_SEMOP_V_FAILED;		

	return(0);
}

/************************************************************************************************************
* Name        : mbox_unlock
* Description : Unlock the mailbox from Read and Write operations
* Parameters  : Mailbox ID
* Return      : 0 or Mailbox defined error
*************************************************************************************************************/
int mbox_unlock( int mailboxId )
{
	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();
	
	if( shmHeader == NULL )
		return MB_ERR_GET_SHM_FAILED;
		
	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, shmHeader );
	
	if( mailboxHeader->signature != MAILBOX_SIGNATURE )
			return MB_ERR_MBSIGNATURE_SHM_FAILED;

	if(mailboxHeader->msqid < 0 || mailboxHeader->mbid < 0)
		return MB_ERR_MBID_INVALID;

	if(!(mailboxHeader->status & MAILBOX_LOCKED))
		return MB_ERR_MB_NOT_LOCKED;

	if(mailboxHeader->status & MAILBOX_DELETED)
		return MB_ERR_MBID_DELETED;	

	if(mailboxHeader->status & MAILBOX_CRASHED)
		return MB_ERR_MBID_CRASHED;

	if(mailboxHeader->status == MAILBOX_FREE)
		return MB_ERR_MB_NOT_INUSE;	

	if( sem_P(shmHeader->semid) != 0 )  /* P Operation */
		return MB_ERR_SEMOP_P_FAILED; 		

	/* Update SHM */
	mailboxHeader->status = mailboxHeader->status ^ MAILBOX_LOCKED;

	if( sem_V(shmHeader->semid) != 0 )	/* V Operation */
		return MB_ERR_SEMOP_V_FAILED;		

	return(0);
}

/************************************************************************************************************
* Name        : mbox_delete
* Description : Delete the mailbox from System Logically (Not Physically)
* Parameters  : Mailbox ID
* Return      : 0 or Mailbox defined error
*************************************************************************************************************/
int mbox_delete( int mailboxId )
{
	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();
	
	if( shmHeader == NULL )
		return MB_ERR_GET_SHM_FAILED;
		
	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, shmHeader );
	
	if( mailboxHeader->signature != MAILBOX_SIGNATURE )
			return MB_ERR_MBSIGNATURE_SHM_FAILED;

	if(mailboxHeader->msqid < 0 || mailboxHeader->mbid < 0)
		return MB_ERR_MBID_INVALID;

	if(mailboxHeader->status & MAILBOX_LOCKED)
		return MB_ERR_MBID_LOCKED;

	if(mailboxHeader->status & MAILBOX_DELETED)
		return MB_ERR_MBID_DELETED;

	if(mailboxHeader->status & MAILBOX_CRASHED)
		return MB_ERR_MBID_CRASHED;

	if(mailboxHeader->status == MAILBOX_FREE)
		return MB_ERR_MB_NOT_INUSE;	

	if( sem_P(shmHeader->semid) != 0 )  /* P Operation */
		return MB_ERR_SEMOP_P_FAILED; 		

	/* Update SHM */
	mailboxHeader->status = mailboxHeader->status | MAILBOX_DELETED;

	if( sem_V(shmHeader->semid) != 0 )	/* V Operation */
		return MB_ERR_SEMOP_V_FAILED;
	
	mbox_clear_queue( mailboxId, MAILBOX_CLEAR_SILENCE );

	return(0);
}

/************************************************************************************************************
* Name        : mbox_lock
* Description : Unlock the mailbox from Read and Write operations
* Parameters  : Mailbox ID
* Return      : 0 or Mailbox defined error
*************************************************************************************************************/
int mbox_lock( int mailboxId )
{
	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();
	
	if( shmHeader == NULL )
		return MB_ERR_GET_SHM_FAILED;
		
	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, shmHeader );
	
	if( mailboxHeader->signature != MAILBOX_SIGNATURE )
			return MB_ERR_MBSIGNATURE_SHM_FAILED;

	if(mailboxHeader->msqid < 0 || mailboxHeader->mbid < 0)
		return MB_ERR_MBID_INVALID;

	if(mailboxHeader->status & MAILBOX_LOCKED)
		return MB_ERR_MBID_LOCKED;

	if(mailboxHeader->status & MAILBOX_DELETED)
		return MB_ERR_MBID_DELETED;	

	if(mailboxHeader->status & MAILBOX_CRASHED)
		return MB_ERR_MBID_CRASHED;

	if(mailboxHeader->status == MAILBOX_FREE)
		return MB_ERR_MB_NOT_INUSE;	

	if( sem_P(shmHeader->semid) != 0 )  /* P Operation */
		return MB_ERR_SEMOP_P_FAILED; 		

	/* Update SHM */
	mailboxHeader->status = mailboxHeader->status | MAILBOX_LOCKED;

	if( sem_V(shmHeader->semid) != 0 )	/* V Operation */
		return MB_ERR_SEMOP_V_FAILED;		

	return(0);
}

/************************************************************************************************************
* Name        : mbox_info
* Description : Show all Mailbox Information
* Parameters  : Mailbox ID
* Return      : 0 or Mailbox defined error
*************************************************************************************************************/
int mbox_info ( int mailboxId )
{
	struct msqid_ds ipcStat;
	
	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();
	
	if( shmHeader == NULL )
		return MB_ERR_GET_SHM_FAILED;
		
	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, shmHeader );

	/* Signature Ok ? */
	if( mailboxHeader->signature != MAILBOX_SIGNATURE )
		return MB_ERR_MBSIGNATURE_SHM_FAILED;

	/* Get Information of Mailbox */
	if ( msgctl( mailboxHeader->msqid, IPC_STAT, &ipcStat ) == -1 )
		return MB_ERR_CTL_STAT_MB_FAILED;

    fprintf(stdout,"================ MAILBOX INFORMATION ========================\n");
	fprintf(stdout,"MailBox ID                  : %d\n",mailboxHeader->mbid);
	fprintf(stdout,"MSQID                       : %d\n",mailboxHeader->msqid);
	fprintf(stdout,"MailBox Name                : %s\n",mailboxHeader->mbname);
	fprintf(stdout,"MB Signature                : 0x%x\n",mailboxHeader->signature);
	fprintf(stdout,"Status                      : 0x%x\n",mailboxHeader->status);
	fprintf(stdout,"MB In Use                   : %s\n",(mailboxHeader->status & MAILBOX_INUSE ? "Yes" : "No"));
	fprintf(stdout,"MB Locked                   : %s\n",(mailboxHeader->status & MAILBOX_LOCKED ? "Yes" : "No"));
	fprintf(stdout,"MB Deleted                  : %s\n",(mailboxHeader->status & MAILBOX_DELETED ? "Yes" : "No"));
	fprintf(stdout,"MB Crashed                  : %s\n",(mailboxHeader->status & MAILBOX_CRASHED ? "Yes" : "No"));
	fprintf(stdout,"MB Key                      : 0x%x\n",get_shm_private_mbox_key(mailboxId));
    fprintf(stdout,"Owner ID                    : %d\n",ipcStat.msg_perm.uid);
    fprintf(stdout,"Owner Group ID              : %d\n",ipcStat.msg_perm.gid);
    fprintf(stdout,"Creator ID                  : %d\n",ipcStat.msg_perm.cuid);
    fprintf(stdout,"Creator Group ID            : %d\n",ipcStat.msg_perm.cgid);
    fprintf(stdout,"Permission                  : %d\n",ipcStat.msg_perm.mode);
    fprintf(stdout,"Bytes Queued                : %d\n",ipcStat.msg_cbytes);
    fprintf(stdout,"Number of Messages          : %d\n",ipcStat.msg_qnum);
	fprintf(stdout,"Max Messages reached        : %d\n",mailboxHeader->maxmsg);
    fprintf(stdout,"Max bytes                   : %d\n",ipcStat.msg_qbytes);
    fprintf(stdout,"PID Last Writer             : %d\n",ipcStat.msg_lspid);
    fprintf(stdout,"PID Last Reader             : %d\n",ipcStat.msg_lrpid);
    fprintf(stdout,"Last Write Date             : %s\n",get_formatted_timestamp(ipcStat.msg_stime).c_str());
    fprintf(stdout,"Last Read Date              : %s\n",get_formatted_timestamp(ipcStat.msg_rtime).c_str());
    fprintf(stdout,"Last Modification           : %s\n",get_formatted_timestamp(ipcStat.msg_ctime).c_str());
	if( mailboxHeader->action[0].level != MAILBOX_NOLEVEL ) {
		fprintf(stdout,"Trigger Action LEVEL        : %d\n", mailboxHeader->action[0].level);
		fprintf(stdout,"Trigger Action Command      : %s\n", mailboxHeader->action[0].action);
		fprintf(stdout,"Trigger Action ON           : %s\n", ( mailboxHeader->action[0].triggerOn ? "Yes" : "No" ));
		fprintf(stdout,"Trigger Action #Execution   : %d\n", mailboxHeader->action[0].execution);
		fprintf(stdout,"Last Trigger Execution      : %s\n", get_formatted_timestamp(mailboxHeader->action[0].triggerTime).c_str());
	}
	fprintf(stdout,"============================================================\n");
	return (0);
}

/************************************************************************************************************
* Name        : mbox_shm_get_queue_stat
* Description : Get all Mailbox Information to Update Main Shared Memory
* Parameters  : None
* Return      : 0 or Mailbox defined error
*************************************************************************************************************/
int mbox_shm_get_queue_stat()
{
	struct msqid_ds ipcStat;
	char commandLine[MAX_IST_STRING] = {0};
	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();
	
	if( shmHeader == NULL )
		return MB_ERR_GET_SHM_FAILED;
		
	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	sleep(shmHeader->sleeptime);

	for( int indiceMB = 0; indiceMB < shmHeader->lastindex; indiceMB++ )
	{
		shm_mbox_header *mailboxHeader = get_mbox_index_header( indiceMB, shmHeader );
	
		/* Signature Ok ? */
		if( mailboxHeader->signature != MAILBOX_SIGNATURE )
			return MB_ERR_MBSIGNATURE_SHM_FAILED;

		/* Get Information of Mailbox */
		if ( msgctl( mailboxHeader->msqid, IPC_STAT, &ipcStat ) == 0 )
		{
			if ( ipcStat.msg_qnum > mailboxHeader->maxmsg )
			{
				if( sem_P(shmHeader->semid) != 0 )    /* P Operation */
				{
					debug_log(mbox_debug_fp,"Mbox [%d]. Semaphore P error => Status [%d]\n",mailboxHeader->mbid,errno);
					continue;   /* Abort this sample */
				}

				mailboxHeader->maxmsg = ipcStat.msg_qnum;

				if( sem_V(shmHeader->semid) != 0 )	/* V Operation */
					debug_log(mbox_debug_fp,"Mbox [%d]. Semaphore V error => Status [%d]\n",mailboxHeader->mbid,errno);
			}

			/* Trigger for action */
			if( ipcStat.msg_qnum > mailboxHeader->action[0].level && mailboxHeader->action[0].triggerOn == MAILBOX_TRIGGER_OFF )
			{
				if( sem_P(shmHeader->semid) != 0 )    /* P Operation */
				{
					debug_log(mbox_debug_fp,"Mbox [%d]. Semaphore P error => Status [%d]\n",mailboxHeader->mbid,errno);
					continue;   /* Abort this sample */
				}

				mailboxHeader->action[0].triggerOn = MAILBOX_TRIGGER_ON;
				mailboxHeader->action[0].execution++;
				mailboxHeader->action[0].triggerTime = get_timestamp();

				if( sem_V(shmHeader->semid) != 0 )	/* V Operation */
					debug_log(mbox_debug_fp,"Mbox [%d]. Semaphore V error => Status [%d]\n",mailboxHeader->mbid,errno);

				sprintf(commandLine,"%s %d %s %d %d %d", mailboxHeader->action[0].action, mailboxHeader->mbid, mailboxHeader->mbname, ipcStat.msg_qnum, mailboxHeader->action[0].level, mailboxHeader->action[0].execution);
				/* fprintf(stdout,"%s\n",commandLine); */
				int cmdlineRespCode = system(commandLine);
				/* fprintf(stdout,"%d\n",cmdlineRespCode); */
				debug_log(mbox_debug_fp,"Action Trigger [%s] executed for Mbox [%d] => RC [%d]\n",commandLine, mailboxHeader->mbid, cmdlineRespCode);
			}
			else 
			{
				/* Turn Off Trigger */
				if( sem_P(shmHeader->semid) != 0 )    /* P Operation */
				{
					debug_log(mbox_debug_fp,"Mbox [%d]. Semaphore P error => Status [%d]\n",mailboxHeader->mbid,errno);
					continue;   /* Abort this sample */
				}

				mailboxHeader->action[0].triggerOn = MAILBOX_TRIGGER_OFF;

				if( sem_V(shmHeader->semid) != 0 )	/* V Operation */
					debug_log(mbox_debug_fp,"Mbox [%d]. Semaphore V error => Status [%d]\n",mailboxHeader->mbid,errno);				
			}
		}
	}
	return (0);
}

/************************************************************************************************************
* Name        : mbox_shm_show_queues
* Description : Show informatio of all Mailbox
* Parameters  : mailboxStatus => Regular, Locked or Deleted
* Return      : 0 or Mailbox defined error
*************************************************************************************************************/
int mbox_shm_show_queues( int mailboxStatus )
{
	struct msqid_ds ipcStat;
	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();
	
	if( shmHeader == NULL )
		return MB_ERR_GET_SHM_FAILED;
		
	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	for( int indiceMB = 0; indiceMB < shmHeader->lastindex; indiceMB ++ )
	{
		shm_mbox_header *mailboxHeader = get_mbox_index_header( indiceMB, shmHeader );
	
		/* Signature Ok ? */
		if( mailboxHeader->signature != MAILBOX_SIGNATURE )
			return MB_ERR_MBSIGNATURE_SHM_FAILED;

		/* Get Information of Mailbox */
		if ( msgctl( mailboxHeader->msqid, IPC_STAT, &ipcStat ) == -1 )
			return MB_ERR_CTL_STAT_MB_FAILED;
		
		if(( ipcStat.msg_qnum > 0 && mailboxStatus == MAILBOX_QUEUED) || 
		   ( mailboxHeader->msqid >= 0 && mailboxHeader->status & MAILBOX_INUSE && mailboxHeader->status & mailboxStatus ))
		{
			fprintf(stdout,"%c%c [%04d] %-40.40s %05d (%d bytes) %05d R[%s => %d] W[%s => %d]\n",
					(mailboxHeader->status & MAILBOX_LOCKED ? 'L' : mailboxHeader->status & MAILBOX_DELETED ? 'D' : ' ' ),
					(mailboxHeader->action[0].level > 0 ? 'A' : ' ' ),
					mailboxHeader->mbid, 
					mailboxHeader->mbname, 
					ipcStat.msg_qnum,
					ipcStat.msg_cbytes, 
					mailboxHeader->maxmsg,					
					get_formatted_timestamp(ipcStat.msg_rtime).c_str(), 
					ipcStat.msg_lrpid, 
					get_formatted_timestamp(ipcStat.msg_stime).c_str(),
					ipcStat.msg_lspid );
		}
	}
	return (0);
}

/************************************************************************************************************
* Name        : get_mbox_index_header
* Description : Get a Pointer to a Desired Mailbox Header
* Parameters  : Index - Mailboxid
*               Main Shared Memory Struct Pointer
* Return      : Pointer to Mailbox Header
*************************************************************************************************************/
shm_mbox_header *get_mbox_index_header( unsigned short mailboxIndex, shm_mbox_system_header *shmHeader )
{
	shm_mbox_header *pointerFirstHeader;

	assert( shmHeader != NULL );

	pointerFirstHeader = (shm_mbox_header *) ((char*)shmHeader + sizeof(shm_mbox_system_header));
	shm_mbox_header *returnMailboxPointer = (shm_mbox_header *) ((char*)pointerFirstHeader + shmHeader->buff_len * mailboxIndex);
	/* fprintf(stdout,"%d.%d=> %ld\n", mailboxIndex, shmHeader->buff_len, (int) ((char *)ret - (char *)shmHeader)); */
	return returnMailboxPointer;
}

/************************************************************************************************************
* Name        : get_total_shm_len
* Description : Get Total of Shared Memory Needed
* Parameters  : None
* Return      : Size of Shared Memory Needed
*************************************************************************************************************/
size_t get_total_shm_len( void )
{
	size_t shmLen = sizeof( shm_mbox_system_header );
	shmLen += sizeof( shm_mbox_header ) * get_shm_buff_qty();

	return shmLen;
}

/************************************************************************************************************
* Name        : get_shm_buff_len
* Description : Get Size of Shared Memory Basic Header
* Parameters  : None
* Return      : Size of Shared Memory Basic Header
*************************************************************************************************************/
size_t get_shm_buff_len( void )
{
    return sizeof(shm_mbox_header);
}

/************************************************************************************************************
* Name        : get_shm_buff_qty
* Description : Get Parameter of Buffers in Configuration MainFile
* Parameters  : None
* Return      : Size of Shared Memory Basic Header
*************************************************************************************************************/
size_t get_shm_buff_qty( void )
{
    int buffQty;
    cf_locatenum(PRODUCT_KEY_MAX_MB,&buffQty);
	return (size_t)buffQty;
}

/************************************************************************************************************
* Name        : mbox_get_shm_id
* Description : Get Main Shared Memory ID
* Parameters  : None
* Return      : Shared Memory ID
*************************************************************************************************************/
int mbox_get_shm_id()
{
	return(shmget(get_shm_mbox_key(),sizeof( shm_mbox_system_header ), 0 ));
}

/************************************************************************************************************
* Name        : mbox_get_semaphore_id
* Description : Get Main Semaphore ID
* Parameters  : None
* Return      : Semaphore ID
*************************************************************************************************************/
int mbox_get_semaphore_id()
{
	return(semget( get_shm_mbox_key(), 1, S_IRUSR | S_IWUSR ));
}

/************************************************************************************************************
* Name        : mbox_remove_shm
* Description : Remove Main Shared Memory
* Parameters  : None
* Return      : Mailbox defined error
*************************************************************************************************************/
int mbox_remove_shm()
{
	return(shmctl( mbox_get_shm_id(), IPC_RMID, NULL));
}

/************************************************************************************************************
* Name        : mbox_remove_semaphore
* Description : Remove Main Semaphore
* Parameters  : None
* Return      : Mailbox defined error
*************************************************************************************************************/
int mbox_remove_semaphore()
{
	return(semctl (mbox_get_semaphore_id(), 0, IPC_RMID, 0));
}

/************************************************************************************************************
* Name        : mbox_remove_queues
* Description : Remove All Mailboxes/Queues
* Parameters  : None
* Return      : Mailbox defined error
*************************************************************************************************************/
int  mbox_remove_queues()
{
	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();
	
	if( shmHeader == NULL )
		return MB_ERR_GET_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */

	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */		

	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */

	for( int idx = 0; idx < shmHeader->lastindex; idx ++ )
	{
		shm_mbox_header *mailboxHeader = get_mbox_index_header( idx, shmHeader );

		if( mailboxHeader->msqid >= 0 ) /* Remove only Active Queues */
		{
			msgctl(mailboxHeader->msqid,IPC_RMID, NULL);
			debug_log(mbox_debug_fp,"Queue Remove[%d:%s] => Status [%d]\n",mailboxHeader->msqid,mailboxHeader->mbname,errno);
		}
	}
	return(0);
}

/************************************************************************************************************
* Name        : mbox_create
* Description : Create a New Mailboxes/Queues
* Parameters  : MailboxName
* Return      : MailboxID or Mailbox defined error
*************************************************************************************************************/
int mbox_create( char *mailboxName )
{
	int mqsId = -1;
	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();

	if (shmHeader == NULL)
		return MB_ERR_GET_SHM_FAILED;

	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */
	
	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */				

	if ( shmHeader->lastindex >= shmHeader->buff_qty )
	{
		debug_log(mbox_debug_fp,"Too many mailboxes. Mailbox %s not created\n",mailboxName);
		return MB_ERR_TOO_MANY;
	}

	/* Create Queue */
	register key_t key = get_shm_private_mbox_key( shmHeader->lastindex );

	/* fprintf(stderr,"Private Key 0x%x\n", key); */
	if(( mqsId = msgget(key, IPC_CREAT | 0666 )) < 0)
	{
		debug_log(mbox_debug_fp,"Queue Name [%s] could not be created => Status [%d]\n",mailboxName,errno);
		return MB_ERR_CREATE_MB_FAILED;
	}
	/* fprintf(stderr,"mqsId=[%d],lastindex[%d] semaphore[%d] shmid[%d]\n",mqsId,shmHeader->lastindex,shmHeader->semid,shmHeader->shmid); */
	
	if( sem_P(shmHeader->semid) != 0 )  /* P Operation */
	{ 
		debug_log(mbox_debug_fp,"Mbox [%s] will be deleted. Semaphore error => Status [%d]\n",mailboxName,errno);
		if( msgctl(mqsId,IPC_RMID, NULL) < 0);
			debug_log(mbox_debug_fp,"Queue Name [%s] could not be deleted => Status [%d]\n",mailboxName,errno);
		return MB_ERR_SEMOP_P_FAILED; 		
	}

	/* Update SHM */
	shm_mbox_header *mailboxHeader = get_mbox_index_header( shmHeader->lastindex, shmHeader );
	mailboxHeader->msqid = mqsId;
    mailboxHeader->mbid = shmHeader->lastindex;
	strcpy(mailboxHeader->mbname,mailboxName);
	mailboxHeader->status = MAILBOX_INUSE;
	mailboxHeader->action[0].level = MAILBOX_NOLEVEL;
	shmHeader->lastindex++;

	if( sem_V(shmHeader->semid) != 0 )	/* V Operation */
		return MB_ERR_SEMOP_V_FAILED;

	return( mailboxHeader->mbid );   /* Return MB ID */
}

/************************************************************************************************************
* Name        : mbox_write
* Description : Write into a Mailbox
* Parameters  : MailboxId
*               Pointer to message
*				Length of the message
* Return      : MailboxID or Mailbox defined error
*************************************************************************************************************/
int mbox_write( int mailboxId, char *messageBuffer, size_t messageLen )
{
	int sendRespCode = 0;
	shm_mbox_message mailboxBufferStruct = {0};

	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();

	if (shmHeader == NULL)
		return MB_ERR_GET_SHM_FAILED;

	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */
	
	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */	

	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, shmHeader );

	if(mailboxHeader->signature != MAILBOX_SIGNATURE)
		return MB_ERR_SIGNATURE_MB_FAILED;

	if(mailboxHeader->msqid < 0 || mailboxHeader->mbid < 0)
		return MB_ERR_MBID_INVALID;

	if(mailboxHeader->status & MAILBOX_LOCKED)
		return MB_ERR_MBID_LOCKED;

	if(mailboxHeader->status & MAILBOX_DELETED)
		return MB_ERR_MBID_DELETED;	

	if(mailboxHeader->status & MAILBOX_CRASHED)
		return MB_ERR_MBID_CRASHED;

	if(mailboxHeader->status == MAILBOX_FREE)
		return MB_ERR_MB_NOT_INUSE;			

	mailboxBufferStruct.messageType = 1;
	memcpy(mailboxBufferStruct.messageBuffer, messageBuffer, messageLen);

	/*fprintf(stdout,"Send to [%d] msg of %d bytes [%s]\n",mailboxHeader->msqid, messageLen, messageBuffer);*/
	if ((sendRespCode = msgsnd(mailboxHeader->msqid, &mailboxBufferStruct, messageLen, IPC_NOWAIT)) < 0)
		return MB_ERR_MQSEND_FAILED;

	return (mailboxHeader->mbid);
}

/************************************************************************************************************
* Name        : mbox_read
* Description : Read a message from Mailbox
* Parameters  : MailboxId
*               Pointer to message
*				Length of the message
* Return      : Number of Bytes or Mailbox defined error
*************************************************************************************************************/
int mbox_read( int mailboxId, char *messageBuffer, size_t bufferLength )
{
	ssize_t readRespCode = 0;
	shm_mbox_message readBuffer = {0};

	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();

	if (shmHeader == NULL)
		return MB_ERR_GET_SHM_FAILED;

	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */
	
	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */	

	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, shmHeader );

	if(mailboxHeader->signature != MAILBOX_SIGNATURE)
		return MB_ERR_SIGNATURE_MB_FAILED;

	if(mailboxHeader->msqid < 0 || mailboxHeader->mbid < 0)
		return MB_ERR_MBID_INVALID;

	if(mailboxHeader->status & MAILBOX_LOCKED)
		return MB_ERR_MBID_LOCKED;

	if(mailboxHeader->status & MAILBOX_DELETED)
		return MB_ERR_MBID_DELETED;	

	if(mailboxHeader->status & MAILBOX_CRASHED)
		return MB_ERR_MBID_CRASHED;

	if(mailboxHeader->status == MAILBOX_FREE)
		return MB_ERR_MB_NOT_INUSE;						

	if ((readRespCode = msgrcv(mailboxHeader->msqid, (void *)&readBuffer, bufferLength, 0, IPC_NOWAIT)) < 0)
		return MB_ERR_MQRCV_FAILED;

	memcpy(messageBuffer,readBuffer.messageBuffer,readRespCode);

	return (int)(readRespCode);
}

/************************************************************************************************************
* Name        : mbox_clear_queue
* Description : Clear all messagers from Mailbox
* Parameters  : MailboxId
*               silenceMode
* Return      : MailboxID or Mailbox defined error
*************************************************************************************************************/
int mbox_clear_queue ( int mailboxId, int silenceMode )
{
	ssize_t readRespCode = 0;
	shm_mbox_message readBuffer = {0};

	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();

	if (shmHeader == NULL)
		return MB_ERR_GET_SHM_FAILED;

	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */
	
	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */	

	shm_mbox_header *mailboxHeader = get_mbox_index_header( mailboxId, shmHeader );

	if(mailboxHeader->signature != MAILBOX_SIGNATURE)
		return MB_ERR_SIGNATURE_MB_FAILED;

	if(mailboxHeader->msqid < 0 || mailboxHeader->mbid < 0)
		return MB_ERR_MBID_INVALID;

	if(mailboxHeader->status & MAILBOX_LOCKED)
		return MB_ERR_MBID_LOCKED;

	if(mailboxHeader->status & MAILBOX_DELETED)
		return MB_ERR_MBID_DELETED;	

	if(mailboxHeader->status & MAILBOX_CRASHED)
		return MB_ERR_MBID_CRASHED;

	if(mailboxHeader->status == MAILBOX_FREE)
		return MB_ERR_MB_NOT_INUSE;						

	/* fprintf(stdout,"Clearing %d messages from MBox [%d]\n", mbox_has_messages(mailboxId), mailboxId); */
	while ((readRespCode = msgrcv(mailboxHeader->msqid, (void *)&readBuffer, sizeof(shm_mbox_message), 0, IPC_NOWAIT)) > 0)
	{
		if ( silenceMode == MAILBOX_CLEAR_NO_SILENCE )
			fprintf(stdout,"Reading %d bytes from [%d]\n", readRespCode, mailboxId);
	}
	return (0);
}

/************************************************************************************************************
* Name        : mbox_get_active_pid
* Description : Get Active PID of Mailbox System
* Parameters  : None
* Return      : PID or Mailbox defined error
*************************************************************************************************************/
int mbox_get_active_pid()
{
	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();

	if (shmHeader == NULL)
		return MB_ERR_GET_SHM_FAILED;

	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */
	
	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */	

	return(shmHeader->pid);
}

/************************************************************************************************************
* Name        : mbox_get_sleep_time
* Description : Get SleepTime for Monitor
* Parameters  : None
* Return      : Sleeptime or Mailbox defined error
*************************************************************************************************************/
int mbox_get_sleep_time()
{
	shm_mbox_system_header *shmHeader = get_mbox_shm_stat();

	if (shmHeader == NULL)
		return MB_ERR_GET_SHM_FAILED;

	if( shmHeader == (void*)-1 )
		return MB_ERR_ATT_SHM_FAILED;		/* Nao foi possivel anexar a shared memory */
	
	if( shmHeader->signature != MAILBOX_HEADER_SIGNATURE )
		return MB_ERR_SIGNATURE_SHM_FAILED;		/* A assinatura da shared memory e invalida */	

	return(shmHeader->sleeptime);
}

/************************************************************************************************************
* Name        : get_shm_mbox_key
* Description : Get Key of Main Shared Memory 
* Parameters  : None
* Return      : MailboxID or Mailbox defined error
*************************************************************************************************************/
key_t get_shm_mbox_key( void )
{
	register key_t shmKey = MAILBOX_BASE_KEY;

	if (!getenv(PRODUCT_SHM_VAR))
		return 0;

	register int region = atoi(getenv(PRODUCT_SHM_VAR)) % 256;
	shmKey += region;
	shmKey += region << 8;
	shmKey += region << 16;
	shmKey += region << 24;

	return shmKey;
}

/************************************************************************************************************
* Name        : get_shm_private_mbox_key
* Description : Get Key of Each Mailbox
* Parameters  : None
* Return      : MailboxID or Mailbox defined error
*************************************************************************************************************/
key_t get_shm_private_mbox_key( int mailboxIndex )
{
	register key_t shmKey = MAILBOX_BASE_KEY;

	if (!getenv(PRODUCT_SHM_VAR))
		return 0;

	register int region = atoi(getenv(PRODUCT_SHM_VAR)) % 256;
	shmKey += region;
	shmKey += region << 8;
	shmKey += region << 16;
	shmKey += region << 24;
	shmKey += mailboxIndex;

	return shmKey;
}
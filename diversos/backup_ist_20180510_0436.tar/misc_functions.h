#ifndef _MISC_FUNCTIONS_H_
#define _MISC_FUNCTIONS_H_

int get_char_param( const char *cfg_key, char *cfg_target );
int get_int_param( const char *cfg_key, int *cfg_target );
int debug_log( FILE *debug_fp, const char * format, ... );
time_t get_timestamp( void );
int compare_timestamp( time_t val1, time_t val2 );

/* Semaphore Acquire */
int sem_P( int semid );

/* Semaphore Release */
int sem_V( int semid );

#endif
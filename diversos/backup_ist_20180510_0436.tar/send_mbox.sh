maxmb=`grep config.maxmbox /home4/renatod1/src/c/ist/cfg/lswparam.cfg | awk "{print $2}"`
maxmb=50

while [ true ]; 
do
   #mboxcmd -send $(( ( RANDOM % 128 ))) "Texto Qualquer"
   randomico=$(( RANDOM % 30))
   if [[ ${randomico} -eq 0 ]]; then
       mboxcmd -send $(( ( RANDOM % ${maxmb} ))) "Texto aleatorio"
   else
       mboxcmd -send $(( ( RANDOM % ${maxmb} ))) "`cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w ${1:-$((RANDOM%100+40))} | head -n 1`"
   fi
   if [ $? -eq 0 ]; then 
      sleep 1
   else
      exit 1   
   fi
done

while [ true ]; do
   syslgcmd -s "Sending Teste `date`"
   sleep `echo $RANDOM % 10 + 1 | bc`
done

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/stat.h>
#include <assert.h>

#include "ist_functions.h"
#include "misc_functions.h"

/* Customized Functions */
int get_char_param( const char *cfg_key, char *cfg_target )
{
	char cfg_data[MAX_IST_STRING] = {0};

	cf_locate(cfg_key, cfg_data);
	strcpy(cfg_target,cfg_data);
	return(0);
}

int get_int_param( const char *cfg_key, int *cfg_target )
{
	int cfg_data = 0;
	cf_locatenum(cfg_key, &cfg_data);
	*cfg_target = cfg_data;
	return(0);
}

int debug_log( FILE *debug_fp, const char * format, ... )
{
	char buffer[MAX_IST_STRING] = {0};
	char timestamp[32] = {0};
	time_t rawtime;
	struct tm * timeinfo;

	if( debug_fp == NULL ) return -1;
	
	time (&rawtime);
	timeinfo = localtime (&rawtime);
	strftime(timestamp,sizeof(timestamp),"%Y-%m-%d %H:%M:%S", timeinfo);	
	
	va_list args;
	va_start (args, format);
	vsprintf(buffer, format, args);
	fprintf(debug_fp,"%s %d %s", timestamp, getpid(),buffer);
	fflush(debug_fp);
	
	return(0);
}

time_t get_timestamp( void )
{
	return time( NULL );
}

int compare_timestamp( time_t val1, time_t val2 )
{
	return abs( val1 - val2 );
}

int sem_P( int semid )
{
	static struct sembuf operations[1];

    operations[0].sem_num = 0;
    operations[0].sem_op = -1; /* P operation */
    operations[0].sem_flg = SEM_UNDO;

    return semop( semid, operations, 1 );
}

int sem_V( int semid )
{
    static struct sembuf operations[1];

    operations[0].sem_num = 0;
    operations[0].sem_op = 1; /* V operation */
    operations[0].sem_flg = SEM_UNDO;

    return semop( semid, operations, 1 );
}
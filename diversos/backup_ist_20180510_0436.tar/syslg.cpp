#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdarg.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/errno.h>
#include <sys/errno.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/stat.h>
#include <assert.h>
#include <string>

using namespace std;

#include "syslg.h"
#include "ist_functions.h"
#include "misc_functions.h"
#include "gen_functions.h"

int syslg_arg0( const char *module_name )
{
	strcpy(syslg_arg0_module_name,module_name);
}

int syslgsend( const char *data_buffer )
{
    int msqid;
	int msgsnd_rc;
    struct message_buf sbuf = {0};
    size_t buf_length;
	char timestamp[32] = {0};
	time_t rawtime;
	struct tm * timeinfo;
	
	time (&rawtime);
	timeinfo = localtime (&rawtime);
	strftime(timestamp,sizeof(timestamp),"%Y-%m-%d %H:%M:%S", timeinfo);
		
    register key_t key = get_shm_syslg_key();

    if ((msqid = msgget(key, 0666 )) < 0)  /* No Shared Memory, No Syslg, No abend */
	{   
		/* fprintf(stderr,"E-%s-005 msgget error [%d]\n", PRODUCT_ALIAS, msqid ); */
		return(-1);
    }
    
    sbuf.mtype = 1;
	sprintf(sbuf.mtext,"%s %s(%d) %s", timestamp, syslg_arg0_module_name, getpid(), data_buffer);
    buf_length = strlen(sbuf.mtext) + 1;

    if ((msgsnd_rc = msgsnd(msqid, &sbuf, buf_length, IPC_NOWAIT)) < 0)
	{
		/* fprintf(stderr,"E-%s-006 msgsnd error [%d]\n", PRODUCT_ALIAS, msgsnd_rc ); */
		return(-2);
    }
 	return (0);
}

int syslg( const char * format, ... )
{
	char buffer[MAX_IST_STRING] = {0};
	
	va_list args;
	va_start (args, format);
	vsprintf(buffer, format, args);
	return(syslgsend(buffer));
}

int syslg_get_queue_id()
{
	return( msgget(get_shm_syslg_key(), 0666 ));
}

int syslg_get_queue_message(int msqid, void *msgp, size_t msgsz, long msgtyp, int msgflg)
{
	return( msgrcv(msqid, msgp, msgsz, msgtyp, msgflg ));
}

int syslg_create_queue()
{
	return( msgget(get_shm_syslg_key(), IPC_CREAT | 0666 ));
}

int syslg_remove_queue()
{
	return( msgctl(syslg_get_queue_id(), IPC_RMID, NULL ));
}

int syslg_get_shm_id()
{
	return( shmget(get_shm_syslg_key(),sizeof( shm_syslg_header ), 0 ));
}

int syslg_get_semaphore_id()
{
	return semget( get_shm_syslg_key(), 1, S_IRUSR | S_IWUSR );
}

int syslg_remove_shm()
{
	return(shmctl(syslg_get_shm_id(),IPC_RMID, NULL));
}

int syslg_remove_semaphore()
{
	return(semctl(syslg_get_semaphore_id(),0,IPC_RMID,0));
}

int syslg_shm_create_memory( shm_syslg_header **shm )
{
	/* Create Shared Memory */
	register key_t key = get_shm_syslg_key();
	int shmid = shmget( key, sizeof(shm_syslg_header), IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR );
	
	if( shmid == -1 )
	{
		if( errno == EEXIST )
		{
			/* A shared memory ja existe, deve ser eliminada */
			shmid = shmget( key, 1, S_IRUSR | S_IWUSR );
			if( shmid == -1 )
				return -1;

			if( shmctl(shmid, IPC_RMID, 0) == -1 )
				return -2;
			else
				return syslg_shm_create_memory( shm ); /* tentar cria-la novamente */
		}
		return -3;
	}

	/* A shared memory foi criada */
	*shm = (shm_syslg_header *) shmat( shmid, NULL, 0 );
	
	memset( *shm, 0, sizeof(shm_syslg_header));

	return shmid;
}

int syslg_shm_create_semaphore()
{
	int retcode;
	register key_t key = get_shm_syslg_key();
	int semid = semget( key, 1, IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR );
	
	if( semid == -1 )
	{
		if( errno == EEXIST )
		{
			/* O semaforo ja existe, deve ser eliminado */
			semid = semget( key, 1, S_IRUSR | S_IWUSR );
			if( semid == -1 )
				return -1;

			retcode = semctl( semid, 0, IPC_RMID, NULL );
			if( retcode != 0 )
				return -4;
			else
				return syslg_shm_create_semaphore(); /* tentar cria-lo novamente */
		}
		return -2;
	}

	return semid;
}

int syslg_shm_format_memory( shm_syslg_header *shm )
{
	assert( shm != NULL );

	int    semid;
	int    pid;
	time_t timestamp;

	shm->signature = SYSLG_HEADER_SIGNATURE;
	shm->pid = getpid();
	shm->timestamp = get_timestamp();

	return (0);
}

int syslg_shm_init_semaphore( int semid )
{
	int retcode;
	static struct sembuf operations[1];

	/* Inicializar semaforo */
    operations[0].sem_num = 0;
    operations[0].sem_op = 1;
    operations[0].sem_flg = 0;

    retcode = semop( semid, operations, 1 );
	
	if( retcode != 0 )
		return -1;		/* Erro ao tentar liberar o semaforo */

	return 0;
}

int syslg_get_active_pid()
{
	struct shmid_ds stat_buf ;
	shm_syslg_header *mem_ptr = get_syslg_shm_stat();
	
	if( mem_ptr == (void*)-1 )
		return -4;		/* Nao foi possivel anexar a shared memory */
	
	if( mem_ptr->signature != SYSLG_HEADER_SIGNATURE )
		return -2;		/* A assinatura da shared memory e invalida */

	return(mem_ptr->pid);
}

int syslg_shm_show_memory()
{
	struct shmid_ds stat_buf ;
	shm_syslg_header *mem_ptr = get_syslg_shm_stat();
	
	if( mem_ptr == NULL )
		return -5;

	if( mem_ptr == (void*)-1 )
		return -4;		/* Nao foi possivel anexar a shared memory */
	
	if( mem_ptr->signature != SYSLG_HEADER_SIGNATURE )
		return -2;		/* A assinatura da shared memory e invalida */

	 if ( shmctl(mem_ptr->shmid,IPC_STAT, &stat_buf) == -1)
		return -3;

	fprintf(stdout,"================ SHM INFORMATION ========================\n");
	fprintf(stdout,"Signature    : 0x%x\n", mem_ptr->signature);
	fprintf(stdout,"LogName      : %s\n",   mem_ptr->logname);
	fprintf(stdout,"SHM ID       : %d\n",   mem_ptr->shmid);
	fprintf(stdout,"Semaphore ID : %d\n",   mem_ptr->semid);
	fprintf(stdout,"Queue ID     : %d\n",   mem_ptr->msqid);
	fprintf(stdout,"PID          : %d\n",   mem_ptr->pid);
	fprintf(stdout,"Owner ID     : %d\n",   stat_buf.shm_perm.uid);
	fprintf(stdout,"Owner Group  : %d\n",   stat_buf.shm_perm.gid);
	fprintf(stdout,"Creator ID   : %d\n",   stat_buf.shm_perm.cuid);
	fprintf(stdout,"Creator Group: %d\n",   stat_buf.shm_perm.cgid);
	fprintf(stdout,"Access Mode  : %d\n",   stat_buf.shm_perm.mode);
	fprintf(stdout,"Size         : %d\n",   stat_buf.shm_segsz);
	fprintf(stdout,"Creator PID  : %d\n",   stat_buf.shm_cpid);
	fprintf(stdout,"Last PID     : %d\n",   stat_buf.shm_lpid);
	fprintf(stdout,"Uptime       : %s\n",   get_formatted_timestamp(mem_ptr->timestamp).c_str());
	fprintf(stdout,"=========================================================\n");
	
	return(0);
}

shm_syslg_header * get_syslg_shm_stat ( void ) 
{
	int shmid = shmget( get_shm_syslg_key(), 0, S_IWUSR|S_IRUSR );

	if( shmid == -1 )
		return NULL;		/* Nao foi possivel localizar a shared memory */

	return (shm_syslg_header *)shmat( shmid, NULL, 0 );
}


key_t get_shm_syslg_key( void )
{
	register key_t key = SYSLG_BASE_KEY;

	if (!getenv(PRODUCT_SHM_VAR))
		return 0;

	register int region = atoi(getenv(PRODUCT_SHM_VAR)) % 256;

	key += region;
	key += region << 8;
	key += region << 16;
	key += region << 24;

	return key;
}
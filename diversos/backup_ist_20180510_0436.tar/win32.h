#ifndef _WIN32_COMPAT_H_
#define _WIN32_COMPAT_H

//
//  Microsoft are crazy
//
#define ZeroMemory 						  		RtlZeroMemory
#define RtlZeroMemory(Destination,Length) 		memset((Destination),0,(Length))
#define CopyMemory(Destination,Source,Length)   memcpy(Destination,Source,Length)
#define WORD                              		unsigned int
#define DWORD                             		unsigned long
#define BYTE                              		unsigned char
#define SOCKET                            		unsigned int

#endif